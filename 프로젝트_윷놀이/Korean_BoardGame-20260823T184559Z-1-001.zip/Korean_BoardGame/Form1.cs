using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Korean_BoardGame
{
    public partial class Form1 : Form
    {
        private const int NODE_SIZE = 50;
        private const int FINISHED = 100;

        private Panel boardPanel;
        private Point[] nodePoints;
        private Label[] nodeLabels;

        private Label lblTurn;
        private Label lblSummary;
        private Label[] yutLabels;
        private Label lblEachResult;
        private Button btnRoll;
        private Button[] pieceButtons;

        private Color centerBackColor = Color.White;
        private string centerExtraText = "";

        private Random rand = new Random();
        private int currentPlayer = 1;
        private int selectedPiece = 0;
        private int lastMoveCount = 0;

        private bool hasRollResult = false;
        private bool canSelectPiece = false;

        private int[,] piecePos = new int[2, 2]
        {
            { 0, 0 },
            { 0, 0 }
        };

        private string[,] pieceRoute = new string[2, 2]
        {
            { "START", "START" },
            { "START", "START" }
        };

        private bool[,] readyToFinish = new bool[2, 2]
        {
            { false, false },
            { false, false }
        };

        private int[] finishCount = new int[2] { 0, 0 };

        public Form1()
        {
            InitializeComponent();

            this.Text = "윷놀이 게임";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ClientSize = new Size(980, 680);
            this.BackColor = Color.WhiteSmoke;

            BuildNodePoints();
            BuildBoardPanel();
            BuildBoardNodes();
            BuildRightUI();
            UpdateBoard();
            UpdateTurnText();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        void BuildNodePoints()
        {
            nodePoints = new Point[29];

            int left = 35;
            int top = 35;
            int gap = 78;

            nodePoints[0] = new Point(left + gap * 5, top + gap * 5);

            nodePoints[1] = new Point(left + gap * 5, top + gap * 4);
            nodePoints[2] = new Point(left + gap * 5, top + gap * 3);
            nodePoints[3] = new Point(left + gap * 5, top + gap * 2);
            nodePoints[4] = new Point(left + gap * 5, top + gap * 1);
            nodePoints[5] = new Point(left + gap * 5, top + gap * 0);

            nodePoints[6] = new Point(left + gap * 4, top + gap * 0);
            nodePoints[7] = new Point(left + gap * 3, top + gap * 0);
            nodePoints[8] = new Point(left + gap * 2, top + gap * 0);
            nodePoints[9] = new Point(left + gap * 1, top + gap * 0);
            nodePoints[10] = new Point(left + gap * 0, top + gap * 0);

            nodePoints[11] = new Point(left + gap * 0, top + gap * 1);
            nodePoints[12] = new Point(left + gap * 0, top + gap * 2);
            nodePoints[13] = new Point(left + gap * 0, top + gap * 3);
            nodePoints[14] = new Point(left + gap * 0, top + gap * 4);
            nodePoints[15] = new Point(left + gap * 0, top + gap * 5);

            nodePoints[16] = new Point(left + gap * 1, top + gap * 5);
            nodePoints[17] = new Point(left + gap * 2, top + gap * 5);
            nodePoints[18] = new Point(left + gap * 3, top + gap * 5);
            nodePoints[19] = new Point(left + gap * 4, top + gap * 5);

            nodePoints[20] = new Point(left + gap * 4, top + gap * 1);
            nodePoints[21] = new Point(left + gap * 3, top + gap * 2);

            nodePoints[22] = new Point(left + gap * 1, top + gap * 1);
            nodePoints[23] = new Point(left + gap * 2, top + gap * 2);

            nodePoints[24] = new Point(left + gap * 2 + gap / 2, top + gap * 2 + gap / 2);

            nodePoints[25] = new Point(left + gap * 1, top + gap * 4);
            nodePoints[26] = new Point(left + gap * 2, top + gap * 3);

            nodePoints[27] = new Point(left + gap * 4, top + gap * 4);
            nodePoints[28] = new Point(left + gap * 3, top + gap * 3);
        }

        void BuildBoardPanel()
        {
            boardPanel = new Panel();
            boardPanel.Location = new Point(20, 20);
            boardPanel.Size = new Size(560, 560);
            boardPanel.BackColor = Color.White;
            boardPanel.BorderStyle = BorderStyle.FixedSingle;
            boardPanel.Paint += BoardPanel_Paint;
            this.Controls.Add(boardPanel);
        }

        void BuildBoardNodes()
        {
            nodeLabels = new Label[29];

            for (int i = 0; i < 29; i++)
            {
                if (i == 24)
                {
                    nodeLabels[i] = null;
                    continue;
                }

                nodeLabels[i] = new Label();
                nodeLabels[i].Size = new Size(NODE_SIZE, NODE_SIZE);
                nodeLabels[i].Location = nodePoints[i];
                nodeLabels[i].BorderStyle = BorderStyle.FixedSingle;
                nodeLabels[i].TextAlign = ContentAlignment.MiddleCenter;
                nodeLabels[i].BackColor = Color.White;
                nodeLabels[i].Font = new Font("맑은 고딕", 8, FontStyle.Bold);
                boardPanel.Controls.Add(nodeLabels[i]);
            }
        }

        void BuildRightUI()
        {
            lblTurn = new Label();
            lblTurn.Location = new Point(620, 40);
            lblTurn.Size = new Size(320, 30);
            lblTurn.Font = new Font("맑은 고딕", 12, FontStyle.Bold);
            this.Controls.Add(lblTurn);

            lblSummary = new Label();
            lblSummary.Location = new Point(620, 90);
            lblSummary.Size = new Size(330, 100);
            lblSummary.Font = new Font("맑은 고딕", 10, FontStyle.Bold);
            lblSummary.Text = "아직 던지지 않음";
            this.Controls.Add(lblSummary);

            pieceButtons = new Button[2];

            for (int i = 0; i < 2; i++)
            {
                pieceButtons[i] = new Button();
                pieceButtons[i].Location = new Point(620 + i * 110, 200);
                pieceButtons[i].Size = new Size(100, 35);
                pieceButtons[i].Text = "말 " + (i + 1);
                pieceButtons[i].Tag = i;
                pieceButtons[i].Click += PieceButton_Click;
                this.Controls.Add(pieceButtons[i]);
            }

            yutLabels = new Label[4];

            int startX = 640;
            int startY = 250;
            int stickGap = 55;

            for (int i = 0; i < 4; i++)
            {
                yutLabels[i] = new Label();
                yutLabels[i].Size = new Size(36, 130);
                yutLabels[i].Location = new Point(startX + i * stickGap, startY);
                yutLabels[i].BorderStyle = BorderStyle.FixedSingle;
                yutLabels[i].TextAlign = ContentAlignment.MiddleCenter;
                yutLabels[i].BackColor = Color.Wheat;
                yutLabels[i].Font = new Font("맑은 고딕", 9, FontStyle.Bold);
                yutLabels[i].Text = (i + 1) + "\n번\n윷";
                this.Controls.Add(yutLabels[i]);
            }

            lblEachResult = new Label();
            lblEachResult.Location = new Point(620, 410);
            lblEachResult.Size = new Size(320, 120);
            lblEachResult.BorderStyle = BorderStyle.FixedSingle;
            lblEachResult.BackColor = Color.White;
            lblEachResult.Font = new Font("맑은 고딕", 10, FontStyle.Regular);
            lblEachResult.Text = "1번 윷 결과:\n2번 윷 결과:\n3번 윷 결과:\n4번 윷 결과:";
            this.Controls.Add(lblEachResult);

            btnRoll = new Button();
            btnRoll.Location = new Point(690, 550);
            btnRoll.Size = new Size(150, 45);
            btnRoll.Text = "윷 던지기";
            btnRoll.Font = new Font("맑은 고딕", 11, FontStyle.Bold);
            btnRoll.Click += BtnRoll_Click;
            this.Controls.Add(btnRoll);
        }

        void PieceButton_Click(object sender, EventArgs e)
        {
            if (canSelectPiece == false)
            {
                MessageBox.Show("먼저 윷을 던져야 합니다.");
                return;
            }

            selectedPiece = (int)((Button)sender).Tag;
            int player = currentPlayer - 1;

            if (IsCarriedPiece(player, selectedPiece) == true)
            {
                MessageBox.Show("2번말은 1번말에 업혀 있습니다. 1번말을 선택해서 움직이세요.");
                return;
            }

            int startPos = piecePos[player, selectedPiece];

            if (startPos == FINISHED)
            {
                MessageBox.Show("이미 완주한 말입니다.");
                return;
            }

            if (startPos == -1)
                startPos = 0;

            bool shortcut = false;

            if (startPos == 5 || startPos == 10 || startPos == 24)
            {
                DialogResult result = MessageBox.Show(
                    "지름길로 이동하시겠습니까?",
                    "지름길 선택",
                    MessageBoxButtons.YesNo
                );

                shortcut = result == DialogResult.Yes;
            }

            MovePiece(player, selectedPiece, lastMoveCount, shortcut);

            bool catchResult = CheckCatch(player);

            bool extraTurn = false;

            if (lastMoveCount == 4 || lastMoveCount == 5)
                extraTurn = true;

            if (catchResult == true)
                extraTurn = true;

            hasRollResult = false;
            canSelectPiece = false;
            selectedPiece = 0;

            UpdateBoard();

            if (finishCount[player] >= 2)
            {
                MessageBox.Show("플레이어 " + currentPlayer + " 승리!");
                btnRoll.Enabled = false;
                pieceButtons[0].Enabled = false;
                pieceButtons[1].Enabled = false;
                return;
            }

            if (extraTurn == true)
            {
                lblSummary.Text += "\n한 번 더 던지세요.";
            }
            else
            {
                currentPlayer = currentPlayer == 1 ? 2 : 1;
            }

            UpdateTurnText();
        }

        bool IsCarriedPiece(int player, int piece)
        {
            if (piece == 0)
                return false;

            if (piecePos[player, 0] == 0)
                return false;

            if (piecePos[player, 0] == -1 || piecePos[player, 0] == FINISHED)
                return false;

            if (piecePos[player, 1] == -1 || piecePos[player, 1] == FINISHED)
                return false;

            if (piecePos[player, 0] == piecePos[player, 1])
                return true;

            return false;
        }

        private void BoardPanel_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            using (Pen pen = new Pen(Color.Black, 2))
            {
                for (int i = 0; i < 19; i++)
                    DrawLineBetween(g, pen, i, i + 1);

                DrawLineBetween(g, pen, 19, 0);

                DrawLineBetween(g, pen, 10, 22);
                DrawLineBetween(g, pen, 22, 23);
                DrawLineBetween(g, pen, 23, 24);

                DrawLineBetween(g, pen, 15, 25);
                DrawLineBetween(g, pen, 25, 26);
                DrawLineBetween(g, pen, 26, 24);

                DrawLineBetween(g, pen, 5, 20);
                DrawLineBetween(g, pen, 20, 21);
                DrawLineBetween(g, pen, 21, 24);

                DrawLineBetween(g, pen, 24, 28);
                DrawLineBetween(g, pen, 28, 27);
                DrawLineBetween(g, pen, 27, 0);
            }

            DrawCenterNode(g);
        }

        void DrawCenterNode(Graphics g)
        {
            Rectangle rect = new Rectangle(nodePoints[24].X, nodePoints[24].Y, NODE_SIZE, NODE_SIZE);

            using (SolidBrush brush = new SolidBrush(centerBackColor))
                g.FillRectangle(brush, rect);

            g.DrawRectangle(Pens.Black, rect);

            string text = "중앙";
            if (centerExtraText != "")
                text += "\n" + centerExtraText;

            using (StringFormat sf = new StringFormat())
            {
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                g.DrawString(text, new Font("맑은 고딕", 8, FontStyle.Bold), Brushes.Black, rect, sf);
            }
        }

        void DrawLineBetween(Graphics g, Pen pen, int a, int b)
        {
            Point p1 = GetCenterPoint(a);
            Point p2 = GetCenterPoint(b);
            g.DrawLine(pen, p1, p2);
        }

        Point GetCenterPoint(int index)
        {
            return new Point(nodePoints[index].X + NODE_SIZE / 2, nodePoints[index].Y + NODE_SIZE / 2);
        }

        string GetBaseNodeText(int index)
        {
            switch (index)
            {
                case 0: return "시작";
                case 20: return "A1";
                case 21: return "A2";
                case 22: return "B1";
                case 23: return "B2";
                case 25: return "C1";
                case 26: return "C2";
                case 27: return "D2";
                case 28: return "D1";
                default: return index.ToString();
            }
        }

        void UpdateBoard()
        {
            for (int i = 0; i < 29; i++)
            {
                if (i == 24 || nodeLabels[i] == null) continue;

                nodeLabels[i].Text = GetBaseNodeText(i);
                nodeLabels[i].BackColor = Color.White;
                nodeLabels[i].ForeColor = Color.Black;
            }

            centerBackColor = Color.White;
            centerExtraText = "";

            for (int p = 0; p < 2; p++)
            {
                for (int m = 0; m < 2; m++)
                {
                    int pos = piecePos[p, m];

                    if (pos == -1 || pos == FINISHED)
                        continue;

                    string pieceName = "P" + (p + 1) + "-" + (m + 1);

                    if (pos == 24)
                    {
                        centerBackColor = p == 0 ? Color.LightSkyBlue : Color.LightPink;
                        centerExtraText += pieceName + " ";
                    }
                    else
                    {
                        nodeLabels[pos].Text += "\n" + pieceName;
                        nodeLabels[pos].BackColor = p == 0 ? Color.LightSkyBlue : Color.LightPink;
                    }
                }
            }

            boardPanel.Invalidate();
        }

        void UpdateTurnText()
        {
            string scoreText = " / 완주 P1:" + finishCount[0] + " P2:" + finishCount[1];

            if (canSelectPiece == true)
                lblTurn.Text = "현재 턴 : 플레이어 " + currentPlayer + " / 이동할 말을 선택하세요" + scoreText;
            else
                lblTurn.Text = "현재 턴 : 플레이어 " + currentPlayer + scoreText;
        }

        private void BtnRoll_Click(object sender, EventArgs e)
        {
            if (hasRollResult == true)
            {
                MessageBox.Show("이미 윷을 던졌습니다. 이동할 말을 선택하세요.");
                return;
            }

            string[] sideText = new string[4];
            int backCount = 0;

            for (int i = 0; i < 4; i++)
            {
                bool isBack = rand.Next(2) == 0;
                sideText[i] = isBack ? "앞면" : "뒷면";

                if (!isBack)
                    backCount++;

                yutLabels[i].Text = (i + 1) + "\n번\n" + sideText[i];
                yutLabels[i].BackColor = isBack ? Color.BurlyWood : Color.SandyBrown;
            }

            string totalResult = GetYutResult(backCount);
            lastMoveCount = GetMoveCount(backCount);

            if (totalResult == "윷")
            {
                for (int i = 0; i < 4; i++)
                    yutLabels[i].BackColor = Color.LightGreen;
            }
            else if (totalResult == "모")
            {
                for (int i = 0; i < 4; i++)
                    yutLabels[i].BackColor = Color.LightBlue;
            }

            lblSummary.Text =
                "던진 결과 : " + totalResult +
                "\n이동 칸 수 : " + lastMoveCount;

            if (lastMoveCount == 4 || lastMoveCount == 5)
                lblSummary.Text += "\n윷/모가 나와 한 번 더 가능";

            lblSummary.Text += "\n이동할 말을 선택하세요.";

            lblEachResult.Text =
                "1번 윷 결과: " + sideText[0] + "\n" +
                "2번 윷 결과: " + sideText[1] + "\n" +
                "3번 윷 결과: " + sideText[2] + "\n" +
                "4번 윷 결과: " + sideText[3];

            hasRollResult = true;
            canSelectPiece = true;

            UpdateTurnText();
        }

        void MovePiece(int player, int piece, int moveCount, bool shortcut)
        {
            int pos = piecePos[player, piece];

            if (pos == -1)
            {
                pos = 0;
                readyToFinish[player, piece] = false;
                pieceRoute[player, piece] = "START";
            }

            bool carryOtherPiece = false;
            int otherPiece = piece == 0 ? 1 : 0;

            if (piece == 0 &&
            piecePos[player, 0] != 0 &&
            piecePos[player, 0] == piecePos[player, 1] &&
            piecePos[player, 1] != -1 &&
            piecePos[player, 1] != FINISHED)
            {
                carryOtherPiece = true;
            }

            if (pos == 0 && readyToFinish[player, piece] == true)
            {
                piecePos[player, piece] = FINISHED;
                readyToFinish[player, piece] = false;
                finishCount[player]++;
                lblSummary.Text += "\n말 " + (piece + 1) + " 완주!";

                if (carryOtherPiece == true)
                {
                    piecePos[player, otherPiece] = FINISHED;
                    readyToFinish[player, otherPiece] = false;
                    finishCount[player]++;
                    lblSummary.Text += "\n업힌 말 " + (otherPiece + 1) + "도 완주!";
                }

                return;
            }

            for (int i = 0; i < moveCount; i++)
            {
                int next = GetNextPosition(player, piece, pos, shortcut);

                if (next == 0 && (pos == 19 || pos == 27))
                {
                    if (i == moveCount - 1)
                    {
                        pos = 0;
                        readyToFinish[player, piece] = true;
                    }
                    else
                    {
                        piecePos[player, piece] = FINISHED;
                        readyToFinish[player, piece] = false;
                        finishCount[player]++;
                        lblSummary.Text += "\n말 " + (piece + 1) + " 완주!";

                        if (carryOtherPiece == true)
                        {
                            piecePos[player, otherPiece] = FINISHED;
                            readyToFinish[player, otherPiece] = false;
                            finishCount[player]++;
                            lblSummary.Text += "\n업힌 말 " + (otherPiece + 1) + "도 완주!";
                        }

                        return;
                    }
                }
                else
                {
                    pos = next;
                    readyToFinish[player, piece] = false;
                }

                shortcut = false;
            }

            piecePos[player, piece] = pos;

            if (carryOtherPiece == true)
            {
                piecePos[player, otherPiece] = pos;
                pieceRoute[player, otherPiece] = pieceRoute[player, piece];
                readyToFinish[player, otherPiece] = readyToFinish[player, piece];
            }
        }

        int GetNextPosition(int player, int piece, int pos, bool shortcut)
        {
            if (pos == 5)
            {
                if (shortcut == true)
                {
                    pieceRoute[player, piece] = "A";
                    return 20;
                }
                else
                {
                    pieceRoute[player, piece] = "OUTER";
                    return 6;
                }
            }

            if (pos == 10)
            {
                if (shortcut == true)
                {
                    pieceRoute[player, piece] = "B";
                    return 22;
                }
                else
                {
                    pieceRoute[player, piece] = "OUTER";
                    return 11;
                }
            }

            if (pos == 24)
            {
                if (pieceRoute[player, piece] == "A")
                {
                    if (shortcut == true)
                    {
                        pieceRoute[player, piece] = "D";
                        return 28;
                    }
                    else
                    {
                        pieceRoute[player, piece] = "C";
                        return 26;
                    }
                }

                if (pieceRoute[player, piece] == "B")
                {
                    pieceRoute[player, piece] = "D";
                    return 28;
                }

                if (pieceRoute[player, piece] == "C")
                {
                    pieceRoute[player, piece] = "C";
                    return 26;
                }

                pieceRoute[player, piece] = "D";
                return 28;
            }

            if (pos == 20) return 21;
            if (pos == 21) return 24;

            if (pos == 22) return 23;
            if (pos == 23) return 24;

            if (pos == 26) return 25;
            if (pos == 25) return 15;

            if (pos == 28) return 27;
            if (pos == 27) return 0;

            if (pos == 19) return 0;

            return pos + 1;
        }

        bool CheckCatch(int player)
        {
            bool caught = false;
            int enemy = player == 0 ? 1 : 0;

            for (int my = 0; my < 2; my++)
            {
                int myPos = piecePos[player, my];

                if (myPos == 0 || myPos == -1 || myPos == FINISHED)
                    continue;

                for (int en = 0; en < 2; en++)
                {
                    if (piecePos[enemy, en] == FINISHED)
                        continue;

                    if (myPos == piecePos[enemy, en])
                    {
                        piecePos[enemy, en] = -1;
                        pieceRoute[enemy, en] = "START";
                        readyToFinish[enemy, en] = false;
                        caught = true;
                    }
                }
            }

            return caught;
        }

        string GetYutResult(int backCount)
        {
            switch (backCount)
            {
                case 0: return "도";
                case 1: return "개";
                case 2: return "걸";
                case 3: return "윷";
                case 4: return "모";
                default: return "";
            }
        }

        int GetMoveCount(int backCount)
        {
            switch (backCount)
            {
                case 0: return 1;
                case 1: return 2;
                case 2: return 3;
                case 3: return 4;
                case 4: return 5;
                default: return 0;
            }
        }
    }
}