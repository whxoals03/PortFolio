using Microsoft.VisualBasic.Devices;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Tetris
{
    public partial class Form1 : Form
    {
        private int TetrisX = 300;
        private int TetrisY = 720;
        private int TileSize = 30;

        private int[] blockX = new int[4];
        private int[] blockY = new int[4];

        private int currentRow;
        private int currentCol;

        private TableLayoutPanel board;
        private Panel previewPanel;
        private Label timeLabel;
        private Label stageLabel;
        private Label clearLineLabel;
        private System.Windows.Forms.Timer gameTimer;

        private System.Windows.Forms.Timer playTimeTimer;
        private int playSeconds = 0;

        private Panel[,] cells;
        private int[,] fixedBlocks;
        private Color[,] fixedColors;

        private Random rnd = new Random();

        private int currentType;
        private Color currentColor;

        private int nextType;

        private int stage = 1;
        private int clearLineCount = 0;

        public Form1()
        {
            InitializeComponent();

            this.Text = "테트리스";
            this.ClientSize = new Size(800, 800);
            this.KeyPreview = true;

            BuildUI();
            UpdateStageText();

            nextType = rnd.Next(0, 7);
            CreateRandomBlock();

            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 500;
            gameTimer.Tick += GameTimer_Tick;
            gameTimer.Start();

            playTimeTimer = new System.Windows.Forms.Timer();
            playTimeTimer.Interval = 1000;
            playTimeTimer.Tick += PlayTimeTimer_Tick;
            playTimeTimer.Start();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BuildUI()
        {
            int cols = TetrisX / TileSize;
            int rows = TetrisY / TileSize;

            cells = new Panel[rows, cols];

            board = new TableLayoutPanel();
            board.Width = TetrisX;
            board.Height = TetrisY;
            board.Left = 150;
            board.Top = 40;
            board.RowCount = rows;
            board.ColumnCount = cols;
            board.Margin = new Padding(0);
            board.Padding = new Padding(0);

            fixedBlocks = new int[rows, cols];
            fixedColors = new Color[rows, cols];

            for (int i = 0; i < cols; i++)
            {
                board.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / cols));
            }

            for (int i = 0; i < rows; i++)
            {
                board.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / rows));
            }

            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                {
                    Panel cell = new Panel();
                    cell.Margin = new Padding(0);
                    cell.Dock = DockStyle.Fill;
                    cell.BackColor = Color.Black;
                    cell.BorderStyle = BorderStyle.FixedSingle;

                    cells[r, c] = cell;
                    board.Controls.Add(cell, c, r);
                }
            }

            previewPanel = new Panel();
            previewPanel.Width = 150;
            previewPanel.Height = 150;
            previewPanel.Left = board.Left + board.Width + 30;
            previewPanel.Top = board.Top;
            previewPanel.BorderStyle = BorderStyle.FixedSingle;
            previewPanel.BackColor = Color.White;

            timeLabel = new Label();
            timeLabel.Width = 150;
            timeLabel.Height = 50;
            timeLabel.Left = previewPanel.Left;
            timeLabel.Top = previewPanel.Bottom + 30;
            timeLabel.Text = "시간 : 00:00";
            timeLabel.Font = new Font("맑은 고딕", 13, FontStyle.Bold);
            timeLabel.TextAlign = ContentAlignment.MiddleCenter;
            timeLabel.BorderStyle = BorderStyle.FixedSingle;

            stageLabel = new Label();
            stageLabel.Width = 150;
            stageLabel.Height = 50;
            stageLabel.Left = previewPanel.Left;
            stageLabel.Top = timeLabel.Bottom + 20;
            stageLabel.Text = "단계 : 1단계";
            stageLabel.Font = new Font("맑은 고딕", 13, FontStyle.Bold);
            stageLabel.TextAlign = ContentAlignment.MiddleCenter;
            stageLabel.BorderStyle = BorderStyle.FixedSingle;

            clearLineLabel = new Label();
            clearLineLabel.Width = 150;
            clearLineLabel.Height = 50;
            clearLineLabel.Left = previewPanel.Left;
            clearLineLabel.Top = stageLabel.Bottom + 20;
            clearLineLabel.Text = "완성 줄 : 0 / 1";
            clearLineLabel.Font = new Font("맑은 고딕", 12, FontStyle.Bold);
            clearLineLabel.TextAlign = ContentAlignment.MiddleCenter;
            clearLineLabel.BorderStyle = BorderStyle.FixedSingle;

            Controls.Add(board);
            Controls.Add(previewPanel);
            Controls.Add(timeLabel);
            Controls.Add(stageLabel);
            Controls.Add(clearLineLabel);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            MoveBlock(1, 0);
        }
        private void PlayTimeTimer_Tick(object sender, EventArgs e)
        {
            playSeconds++;

            int min = playSeconds / 60;
            int sec = playSeconds % 60;

            timeLabel.Text = "시간 : " + min.ToString("00") + ":" + sec.ToString("00");
        }
        private void UpdateStageText()
        {
            stageLabel.Text = "단계 : " + stage + "단계";
            clearLineLabel.Text = "완성 줄 : " + clearLineCount + " / " + stage;
        }

        private void SetPreviewBlockShape(int type, int[] x, int[] y)
        {
            if (type == 0)
            {
                x[0] = -1; y[0] = 0;
                x[1] = 0; y[1] = 0;
                x[2] = 1; y[2] = 0;
                x[3] = 2; y[3] = 0;
            }
            else if (type == 1)
            {
                x[0] = 0; y[0] = 0;
                x[1] = 1; y[1] = 0;
                x[2] = 0; y[2] = 1;
                x[3] = 1; y[3] = 1;
            }
            else if (type == 2)
            {
                x[0] = -1; y[0] = 0;
                x[1] = 0; y[1] = 0;
                x[2] = 1; y[2] = 0;
                x[3] = 0; y[3] = 1;
            }
            else if (type == 3)
            {
                x[0] = 0; y[0] = 0;
                x[1] = 1; y[1] = 0;
                x[2] = -1; y[2] = 1;
                x[3] = 0; y[3] = 1;
            }
            else if (type == 4)
            {
                x[0] = -1; y[0] = 0;
                x[1] = 0; y[1] = 0;
                x[2] = 0; y[2] = 1;
                x[3] = 1; y[3] = 1;
            }
            else if (type == 5)
            {
                x[0] = -1; y[0] = 0;
                x[1] = 0; y[1] = 0;
                x[2] = 1; y[2] = 0;
                x[3] = -1; y[3] = 1;
            }
            else
            {
                x[0] = -1; y[0] = 0;
                x[1] = 0; y[1] = 0;
                x[2] = 1; y[2] = 0;
                x[3] = 1; y[3] = 1;
            }
        }

        private void CreateRandomBlock()
        {
            currentType = nextType;

            SetBlockShape(currentType);

            currentColor = GetBlockColor(currentType);

            nextType = rnd.Next(0, 7);
            DrawPreviewBlock();

            currentRow = 1;
            currentCol = 5;

            if (CanMove(currentRow, currentCol, blockX, blockY) == false)
            {
                gameTimer.Stop();
                playTimeTimer.Stop();

                MessageBox.Show("실패!");
                return;
            }

            DrawBlock();
        }
        private void SetBlockShape(int type)
        {
            SetPreviewBlockShape(type, blockX, blockY);
        }

        private void DrawPreviewBlock()
        {
            previewPanel.Controls.Clear();

            int[] previewX = new int[4];
            int[] previewY = new int[4];

            SetPreviewBlockShape(nextType, previewX, previewY);

            Color previewColor = GetBlockColor(nextType);
            int previewTileSize = 30;

            for (int i = 0; i < 4; i++)
            {
                Panel blockCell = new Panel();
                blockCell.Width = previewTileSize;
                blockCell.Height = previewTileSize;
                blockCell.BackColor = previewColor;
                blockCell.BorderStyle = BorderStyle.FixedSingle;

                blockCell.Left = 55 + previewX[i] * previewTileSize;
                blockCell.Top = 55 + previewY[i] * previewTileSize;

                previewPanel.Controls.Add(blockCell);
            }
        }

        private Color GetBlockColor(int type)
        {
            if (type == 0) return Color.Cyan;
            else if (type == 1) return Color.Yellow;
            else if (type == 2) return Color.Purple;
            else if (type == 3) return Color.Lime;
            else if (type == 4) return Color.Red;
            else if (type == 5) return Color.Blue;
            else return Color.Orange;
        }

        private void DrawBlock()
        {
            for (int i = 0; i < 4; i++)
            {
                int row = currentRow + blockY[i];
                int col = currentCol + blockX[i];

                cells[row, col].BackColor = currentColor;
            }
        }

        private void EraseBlock()
        {
            for (int i = 0; i < 4; i++)
            {
                int row = currentRow + blockY[i];
                int col = currentCol + blockX[i];

                if (row >= 0 && row < cells.GetLength(0) &&
                    col >= 0 && col < cells.GetLength(1))
                {
                    if (fixedBlocks[row, col] == 0)
                    {
                        cells[row, col].BackColor = Color.Black;
                    }
                }
            }
        }

        private bool CanMove(int nextRow, int nextCol, int[] checkX, int[] checkY)
        {
            for (int i = 0; i < 4; i++)
            {
                int row = nextRow + checkY[i];
                int col = nextCol + checkX[i];

                if (row < 0 || row >= cells.GetLength(0))
                {
                    return false;
                }

                if (col < 0 || col >= cells.GetLength(1))
                {
                    return false;
                }

                if (fixedBlocks[row, col] == 1)
                {
                    return false;
                }
            }

            return true;
        }

        private void MoveBlock(int rowMove, int colMove)
        {
            int nextRow = currentRow + rowMove;
            int nextCol = currentCol + colMove;

            if (CanMove(nextRow, nextCol, blockX, blockY) == true)
            {
                EraseBlock();

                currentRow = nextRow;
                currentCol = nextCol;

                DrawBlock();
            }
            else
            {
                if (rowMove == 1 && colMove == 0)
                {
                    FixBlock();

                    int fullLines = CheckFullLines();

                    if (fullLines > 0)
                    {
                        clearLineCount = clearLineCount + fullLines;
                        UpdateStageText();

                        if (clearLineCount >= stage)
                        {
                            if (stage == 5)
                            {
                                gameTimer.Stop();
                                playTimeTimer.Stop();

                                MessageBox.Show("게임 종료 우승!");
                                return;
                            }

                            MessageBox.Show(stage + "단계 성공!");

                            stage++;
                            clearLineCount = 0;

                            ResetBoard();

                            CreateRandomBlock();
                            UpdateStageText();
                            return;
                        }
                    }

                    CreateRandomBlock();
                }
            }
        }
        private void ResetBoard()
        {
            for (int r = 0; r < cells.GetLength(0); r++)
            {
                for (int c = 0; c < cells.GetLength(1); c++)
                {
                    fixedBlocks[r, c] = 0;
                    fixedColors[r, c] = Color.Black;
                    cells[r, c].BackColor = Color.Black;
                }
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Left)
            {
                MoveBlock(0, -1);
                return true;
            }
            else if (keyData == Keys.Right)
            {
                MoveBlock(0, 1);
                return true;
            }
            else if (keyData == Keys.Down)
            {
                MoveBlock(1, 0);
                return true;
            }
            else if (keyData == Keys.Space)
            {
                RotateBlock();
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void RotateBlock()
        {
            if (currentType == 1)
            {
                return;
            }

            int[] nextX = new int[4];
            int[] nextY = new int[4];

            for (int i = 0; i < 4; i++)
            {
                nextX[i] = -blockY[i];
                nextY[i] = blockX[i];
            }

            if (CanMove(currentRow, currentCol, nextX, nextY) == true)
            {
                EraseBlock();

                for (int i = 0; i < 4; i++)
                {
                    blockX[i] = nextX[i];
                    blockY[i] = nextY[i];
                }

                DrawBlock();
            }
        }

        private void FixBlock()
        {
            for (int i = 0; i < 4; i++)
            {
                int row = currentRow + blockY[i];
                int col = currentCol + blockX[i];

                fixedBlocks[row, col] = 1;
                fixedColors[row, col] = currentColor;
            }
        }

        private int CheckFullLines()
        {
            int fullLineCount = 0;

            for (int r = cells.GetLength(0) - 1; r >= 0; r--)
            {
                int full = 1;

                for (int c = 0; c < cells.GetLength(1); c++)
                {
                    if (fixedBlocks[r, c] == 0)
                    {
                        full = 0;
                        break;
                    }
                }

                if (full == 1)
                {
                    RemoveLine(r);
                    fullLineCount++;

                    r++;
                }
            }

            return fullLineCount;
        }

        private void RemoveLine(int line)
        {
            for (int r = line; r > 0; r--)
            {
                for (int c = 0; c < cells.GetLength(1); c++)
                {
                    fixedBlocks[r, c] = fixedBlocks[r - 1, c];
                    fixedColors[r, c] = fixedColors[r - 1, c];

                    if (fixedBlocks[r, c] == 1)
                    {
                        cells[r, c].BackColor = fixedColors[r, c];
                    }
                    else
                    {
                        cells[r, c].BackColor = Color.Black;
                    }
                }
            }

            for (int c = 0; c < cells.GetLength(1); c++)
            {
                fixedBlocks[0, c] = 0;
                fixedColors[0, c] = Color.Black;
                cells[0, c].BackColor = Color.Black;
            }
        }
    }
}