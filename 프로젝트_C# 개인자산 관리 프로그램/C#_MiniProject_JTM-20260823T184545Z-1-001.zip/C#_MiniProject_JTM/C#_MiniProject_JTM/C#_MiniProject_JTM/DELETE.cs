﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;

namespace C__MiniProject_JTM
{
    public partial class DELETE : Form
    {
        public DELETE()
        {
            InitializeComponent();

            tb_DELETE_id.ForeColor = Color.Gray;
            tb_DELETE_pw.ForeColor = Color.Gray;
            tb_DELETE_name.ForeColor = Color.Gray;
            tb_DELETE_phone.ForeColor = Color.Gray;
            tb_DELETE_email.ForeColor = Color.Gray;
            tb_DELETE_birth.ForeColor = Color.Gray;
        }

        private void DELETE_Load(object sender, EventArgs e)
        {

        }

        private void btn_DELETE_Click_1(object sender, EventArgs e)
        {
            if (tb_DELETE_id.Text == "아이디 입력 (6 ~ 20자)" || tb_DELETE_id.Text.Length < 6 || tb_DELETE_id.Text.Length > 20)
            {
                MessageBox.Show("아이디는 6~20자로 입력해야 합니다.");
                return;
            }

            if (tb_DELETE_pw.Text == "비밀번호 입력 (문자, 숫자, 특수문자 포함 8 ~ 20자 )" || tb_DELETE_pw.Text.Length < 8 || tb_DELETE_pw.Text.Length > 20)
            {
                MessageBox.Show("비밀번호는 8~20자로 입력해야 합니다.");
                return;
            }

            if (tb_DELETE_name.Text == "이름을 입력해주세요" || string.IsNullOrWhiteSpace(tb_DELETE_name.Text))
            {
                MessageBox.Show("이름을 입력해주세요.");
                return;
            }

            if (tb_DELETE_phone.Text == "휴대폰 번호 입력 ( '-' 제외 11자리 입력 )" || tb_DELETE_phone.Text.Length != 11)
            {
                MessageBox.Show("전화번호는 '-' 없이 11자리로 입력해야 합니다.");
                return;
            }

            if (!long.TryParse(tb_DELETE_phone.Text, out _))
            {
                MessageBox.Show("전화번호는 숫자만 입력 가능합니다.");
                return;
            }

            if (tb_DELETE_email.Text == "이메일을 입력해주세요" || !tb_DELETE_email.Text.Contains("@") || !tb_DELETE_email.Text.Contains("."))
            {
                MessageBox.Show("올바른 이메일 형식이 아닙니다.");
                return;
            }

            if (tb_DELETE_birth.Text == "8자리를 입력해주세요" || tb_DELETE_birth.Text.Length != 8)
            {
                MessageBox.Show("생년월일은 8자리로 입력해야 합니다.");
                return;
            }

            if (!long.TryParse(tb_DELETE_birth.Text, out _))
            {
                MessageBox.Show("생년월일은 숫자만 입력 가능합니다.");
                return;
            }

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string checkSql = @"
                SELECT COUNT(*)
                FROM Users
                WHERE LoginId = @LoginId
                AND Password = @Password
                AND Name = @Name
                AND Phone = @Phone
                AND Email = @Email
                AND Birth = @Birth";

                using (SqliteCommand checkCmd = new SqliteCommand(checkSql, conn))
                {
                    checkCmd.Parameters.AddWithValue("@LoginId", tb_DELETE_id.Text.Trim());
                    checkCmd.Parameters.AddWithValue("@Password", tb_DELETE_pw.Text.Trim());
                    checkCmd.Parameters.AddWithValue("@Name", tb_DELETE_name.Text.Trim());
                    checkCmd.Parameters.AddWithValue("@Phone", tb_DELETE_phone.Text.Trim());
                    checkCmd.Parameters.AddWithValue("@Email", tb_DELETE_email.Text.Trim());
                    checkCmd.Parameters.AddWithValue("@Birth", tb_DELETE_birth.Text.Trim());

                    long count = (long)checkCmd.ExecuteScalar();

                    if (count == 0)
                    {
                        MessageBox.Show("해당하는 회원은 없습니다.");
                        return;
                    }
                }

                DialogResult result = MessageBox.Show(
                    "정말 탈퇴하시겠습니까?",
                    "회원탈퇴 확인",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning
                );

                if (result != DialogResult.Yes)
                {
                    return;
                }

                string deleteSql = @"
                DELETE FROM Users
                WHERE LoginId = @LoginId
                AND Password = @Password
                AND Name = @Name
                AND Phone = @Phone
                AND Email = @Email
                AND Birth = @Birth";

                using (SqliteCommand deleteCmd = new SqliteCommand(deleteSql, conn))
                {
                    deleteCmd.Parameters.AddWithValue("@LoginId", tb_DELETE_id.Text.Trim());
                    deleteCmd.Parameters.AddWithValue("@Password", tb_DELETE_pw.Text.Trim());
                    deleteCmd.Parameters.AddWithValue("@Name", tb_DELETE_name.Text.Trim());
                    deleteCmd.Parameters.AddWithValue("@Phone", tb_DELETE_phone.Text.Trim());
                    deleteCmd.Parameters.AddWithValue("@Email", tb_DELETE_email.Text.Trim());
                    deleteCmd.Parameters.AddWithValue("@Birth", tb_DELETE_birth.Text.Trim());

                    deleteCmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("회원탈퇴가 완료되었습니다.");

            LoginForm login = new LoginForm();
            login.Show();

            this.Hide();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            LoginForm login = new LoginForm();
            login.Show();

            this.Hide();
        }

        private void tb_DELETE_id_Enter(object sender, EventArgs e)
        {
            if (tb_DELETE_id.Text == "아이디 입력 (6 ~ 20자)")
            {
                tb_DELETE_id.Text = "";
                tb_DELETE_id.ForeColor = Color.Black;
            }
        }

        private void tb_DELETE_id_Leave(object sender, EventArgs e)
        {
            if (tb_DELETE_id.Text == "")
            {
                tb_DELETE_id.Text = "아이디 입력 (6 ~ 20자)";
                tb_DELETE_id.ForeColor = Color.Gray;
            }
        }

        private void tb_DELETE_pw_Enter(object sender, EventArgs e)
        {
            if (tb_DELETE_pw.Text == "비밀번호 입력 (문자, 숫자, 특수문자 포함 8 ~ 20자 )")
            {
                tb_DELETE_pw.Text = "";
                tb_DELETE_pw.ForeColor = Color.Black;
            }
        }

        private void tb_DELETE_pw_Leave(object sender, EventArgs e)
        {
            if (tb_DELETE_pw.Text == "")
            {
                tb_DELETE_pw.Text = "비밀번호 입력 (문자, 숫자, 특수문자 포함 8 ~ 20자 )";
                tb_DELETE_pw.ForeColor = Color.Gray;
            }
        }

        private void tb_DELETE_name_Enter(object sender, EventArgs e)
        {
            if (tb_DELETE_name.Text == "이름을 입력해주세요")
            {
                tb_DELETE_name.Text = "";
                tb_DELETE_name.ForeColor = Color.Black;
            }
        }

        private void tb_DELETE_name_Leave(object sender, EventArgs e)
        {
            if (tb_DELETE_name.Text == "")
            {
                tb_DELETE_name.Text = "이름을 입력해주세요";
                tb_DELETE_name.ForeColor = Color.Gray;
            }
        }

        private void tb_DELETE_phone_Enter(object sender, EventArgs e)
        {
            if (tb_DELETE_phone.Text == "휴대폰 번호 입력 ( '-' 제외 11자리 입력 )")
            {
                tb_DELETE_phone.Text = "";
                tb_DELETE_phone.ForeColor = Color.Black;
            }
        }

        private void tb_DELETE_phone_Leave(object sender, EventArgs e)
        {
            if (tb_DELETE_phone.Text == "")
            {
                tb_DELETE_phone.Text = "휴대폰 번호 입력 ( '-' 제외 11자리 입력 )";
                tb_DELETE_phone.ForeColor = Color.Gray;
            }
        }

        private void tb_DELETE_email_Enter(object sender, EventArgs e)
        {
            if (tb_DELETE_email.Text == "이메일을 입력해주세요")
            {
                tb_DELETE_email.Text = "";
                tb_DELETE_email.ForeColor = Color.Black;
            }
        }

        private void tb_DELETE_email_Leave(object sender, EventArgs e)
        {
            if (tb_DELETE_email.Text == "")
            {
                tb_DELETE_email.Text = "이메일을 입력해주세요";
                tb_DELETE_email.ForeColor = Color.Gray;
            }
        }

        private void tb_DELETE_birth_Enter(object sender, EventArgs e)
        {
            if (tb_DELETE_birth.Text == "8자리를 입력해주세요")
            {
                tb_DELETE_birth.Text = "";
                tb_DELETE_birth.ForeColor = Color.Black;
            }
        }

        private void tb_DELETE_birth_Leave(object sender, EventArgs e)
        {
            if (tb_DELETE_birth.Text == "")
            {
                tb_DELETE_birth.Text = "8자리를 입력해주세요";
                tb_DELETE_birth.ForeColor = Color.Gray;
            }
        }

        private void tb_DELETE_birth_Leave_1(object sender, EventArgs e)
        {
            if (tb_DELETE_birth.Text == "")
            {
                tb_DELETE_birth.Text = "8자리를 입력해주세요";
                tb_DELETE_birth.ForeColor = Color.Gray;
            }
        }

        private void btn_DELETE_back_Click(object sender, EventArgs e)
        {
            Search_Delete form = new Search_Delete();

            form.Show();

            this.Hide();
        }
    }
}