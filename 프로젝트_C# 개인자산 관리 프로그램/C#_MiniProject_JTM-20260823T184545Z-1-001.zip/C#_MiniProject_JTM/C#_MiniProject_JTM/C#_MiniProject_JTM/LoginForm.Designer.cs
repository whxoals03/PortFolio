﻿namespace C__MiniProject_JTM
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            tb_login = new TextBox();
            tb_pass = new TextBox();
            label3 = new Label();
            btn_login = new Button();
            btn_search_delete = new Button();
            btn_membership = new Button();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(121, 133);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(236, 46);
            label1.TabIndex = 0;
            label1.Text = "사용자 로그인";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(174, 16);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(132, 113);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(60, 199);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(72, 28);
            label2.TabIndex = 2;
            label2.Text = "아이디";
            // 
            // tb_login
            // 
            tb_login.BorderStyle = BorderStyle.FixedSingle;
            tb_login.Font = new Font("맑은 고딕 Semilight", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_login.ForeColor = SystemColors.WindowFrame;
            tb_login.Location = new Point(60, 231);
            tb_login.Margin = new Padding(4);
            tb_login.Name = "tb_login";
            tb_login.Size = new Size(350, 34);
            tb_login.TabIndex = 3;
            tb_login.Text = "아이디";
            tb_login.TextChanged += tb_login_TextChanged;
            tb_login.Enter += tb_login_Enter;
            tb_login.Leave += tb_login_Leave;
            // 
            // tb_pass
            // 
            tb_pass.BorderStyle = BorderStyle.FixedSingle;
            tb_pass.Font = new Font("맑은 고딕 Semilight", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_pass.ForeColor = SystemColors.WindowFrame;
            tb_pass.Location = new Point(60, 309);
            tb_pass.Margin = new Padding(4);
            tb_pass.Name = "tb_pass";
            tb_pass.Size = new Size(350, 34);
            tb_pass.TabIndex = 5;
            tb_pass.Text = "비밀번호";
            tb_pass.Enter += tb_pass_Enter;
            tb_pass.Leave += tb_pass_Leave;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(60, 277);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(92, 28);
            label3.TabIndex = 4;
            label3.Text = "비밀번호";
            // 
            // btn_login
            // 
            btn_login.BackColor = Color.FromArgb(192, 192, 255);
            btn_login.BackgroundImageLayout = ImageLayout.None;
            btn_login.Font = new Font("맑은 고딕", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_login.ForeColor = SystemColors.ControlText;
            btn_login.Location = new Point(50, 368);
            btn_login.Margin = new Padding(4);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(372, 60);
            btn_login.TabIndex = 6;
            btn_login.Text = "로그인";
            btn_login.UseVisualStyleBackColor = false;
            btn_login.Click += btn_login_Click;
            // 
            // btn_search_delete
            // 
            btn_search_delete.BackColor = Color.White;
            btn_search_delete.FlatAppearance.BorderSize = 0;
            btn_search_delete.FlatStyle = FlatStyle.Flat;
            btn_search_delete.Font = new Font("맑은 고딕", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            btn_search_delete.Location = new Point(39, 436);
            btn_search_delete.Margin = new Padding(4);
            btn_search_delete.Name = "btn_search_delete";
            btn_search_delete.Size = new Size(179, 31);
            btn_search_delete.TabIndex = 7;
            btn_search_delete.Text = "회원조회 및 회원탈퇴";
            btn_search_delete.UseVisualStyleBackColor = false;
            btn_search_delete.Click += btn_search_delete_Click;
            // 
            // btn_membership
            // 
            btn_membership.BackColor = Color.White;
            btn_membership.FlatAppearance.BorderSize = 0;
            btn_membership.FlatStyle = FlatStyle.Flat;
            btn_membership.Font = new Font("맑은 고딕", 9F, FontStyle.Underline, GraphicsUnit.Point, 0);
            btn_membership.Location = new Point(347, 436);
            btn_membership.Margin = new Padding(4);
            btn_membership.Name = "btn_membership";
            btn_membership.Size = new Size(86, 31);
            btn_membership.TabIndex = 8;
            btn_membership.Text = "회원가입";
            btn_membership.UseVisualStyleBackColor = false;
            btn_membership.Click += btn_membership_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("맑은 고딕", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(39, 503);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(429, 37);
            label4.TabIndex = 9;
            label4.Text = "로그인 시 대시보드로 이동합니다.";
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(491, 600);
            Controls.Add(label4);
            Controls.Add(btn_membership);
            Controls.Add(btn_search_delete);
            Controls.Add(btn_login);
            Controls.Add(tb_pass);
            Controls.Add(label3);
            Controls.Add(tb_login);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Margin = new Padding(4);
            Name = "LoginForm";
            Text = "사용자 로그인";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
        private TextBox tb_login;
        private TextBox tb_pass;
        private Label label3;
        private Button btn_login;
        private Button btn_search_delete;
        private Button btn_membership;
        private Label label4;
    }
}
