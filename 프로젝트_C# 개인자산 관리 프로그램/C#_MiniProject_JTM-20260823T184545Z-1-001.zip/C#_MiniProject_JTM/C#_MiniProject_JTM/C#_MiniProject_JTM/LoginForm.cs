using Microsoft.Data.Sqlite;

namespace C__MiniProject_JTM
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql =
                @"SELECT Name
                FROM Users
                WHERE LoginId=@id
                AND Password=@pw";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", tb_login.Text);
                    cmd.Parameters.AddWithValue("@pw", tb_pass.Text);

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        string userName = result.ToString();

                        HomeForm home = new HomeForm(userName);

                        home.Show();

                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("아이디 또는 비밀번호가 틀렸습니다.");
                    }
                }
            }
        }

        private void btn_membership_Click(object sender, EventArgs e)
        {
            membershipForm form = new membershipForm();

            form.Show();

            this.Hide();
        }

        private void tb_login_Enter(object sender, EventArgs e)
        {
            if (tb_login.Text == "아이디")
            {
                tb_login.Text = "";
                tb_login.ForeColor = Color.Black;
            }
        }
        private void tb_login_Leave(object sender, EventArgs e)
        {
            if (tb_login.Text == "")
            {
                tb_login.Text = "아이디";
                tb_login.ForeColor = Color.Gray;
            }
        }

        private void tb_pass_Enter(object sender, EventArgs e)
        {
            if (tb_pass.Text == "비밀번호")
            {
                tb_pass.Text = "";
                tb_pass.ForeColor = Color.Black;

                tb_pass.UseSystemPasswordChar = true;
            }
        }

        private void tb_pass_Leave(object sender, EventArgs e)
        {
            if (tb_pass.Text == "")
            {
                tb_pass.UseSystemPasswordChar = false;

                tb_pass.Text = "비밀번호";
                tb_pass.ForeColor = Color.Gray;
            }
        }

        private void btn_search_delete_Click(object sender, EventArgs e)
        {
            Search_Delete form = new Search_Delete();

            form.Show();

            this.Hide();
        }

        private void tb_login_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
