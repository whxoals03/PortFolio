﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using Microsoft.VisualBasic;

namespace C__MiniProject_JTM
{
    public partial class HomeForm_management : Form
    {
        public HomeForm_management()
        {
            InitializeComponent();

            pnl_man_home.Click += pnl_man_home_Click;
            pnl_man_income.Click += pnl_man_income_Click;
            pnl_man_expense.Click += pnl_man_expense_Click;
            pnl_man_search.Click += pnl_man_search_Click;
            pnl_man_management.Click += pnl_man_management_Click;

            btn_man_home.Click += pnl_man_home_Click;
            btn_man_income.Click += pnl_man_income_Click;
            btn_man_expense.Click += pnl_man_expense_Click;
            btn_man_search.Click += pnl_man_search_Click;
            btn_man_management.Click += pnl_man_management_Click;

            pic_man_home.Click += pnl_man_home_Click;
            pic_man_income.Click += pnl_man_income_Click;
            pic_man_expense.Click += pnl_man_expense_Click;
            pic_man_search.Click += pnl_man_search_Click;
            pic_man_management.Click += pnl_man_management_Click;

            LoadBudgetInfo();
        }
        private int GetBalance()
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "SELECT IFNULL(Balance, 0) FROM Budget WHERE Id = 1";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    object result = cmd.ExecuteScalar();

                    if (result == null)
                    {
                        return 0;
                    }

                    return Convert.ToInt32(result);
                }
            }
        }

        private int GetTotalIncome()
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "SELECT IFNULL(SUM(Amount), 0) FROM Income";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private int GetTotalExpense()
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "SELECT IFNULL(SUM(Amount), 0) FROM Expense";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private void LoadBudgetInfo()
        {
            int balance = GetBalance();
            int totalIncome = GetTotalIncome();
            int totalExpense = GetTotalExpense();

            int remain = balance + totalIncome - totalExpense;

            tb_man_CurrentMoney.Text = balance.ToString("N0") + "원";
            tb_man_TotalIncome.Text = totalIncome.ToString("N0") + "원";
            tb_man_TotalExpense.Text = totalExpense.ToString("N0") + "원";
            tb_man_RemainMoney.Text = remain.ToString("N0") + "원";
        }

        private void pnl_man_home_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_man_income_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_man_expense_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_man_search_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_man_management_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_man_home_Click(object sender, EventArgs e)
        {
            HomeForm form = new HomeForm("사용자");

            form.Show();

            this.Hide();
        }

        private void pnl_man_income_Click(object sender, EventArgs e)
        {
            HomeForm_income form = new HomeForm_income();

            form.Show();

            this.Hide();
        }

        private void pnl_man_expense_Click(object sender, EventArgs e)
        {
            HomeForm_expense form = new HomeForm_expense();

            form.Show();

            this.Hide();
        }

        private void pnl_man_search_Click(object sender, EventArgs e)
        {
            HomeForm_search form = new HomeForm_search();

            form.Show();

            this.Hide();
        }

        private void pnl_man_management_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_man_SetMoney_Click(object sender, EventArgs e)
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string checkSql = "SELECT COUNT(*) FROM Budget";

                using (SqliteCommand cmd = new SqliteCommand(checkSql, conn))
                {
                    long count = (long)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("보유금이 이미 설정되어 있습니다.\n전체 초기화 후 다시 설정하세요.");
                        return;
                    }
                }

                string input = Interaction.InputBox(
                    "보유금을 입력하세요.",
                    "보유금 설정",
                    ""
                );

                if (input == "")
                {
                    return;
                }

                int money;

                if (!int.TryParse(input, out money))
                {
                    MessageBox.Show("숫자만 입력하세요.");
                    return;
                }

                string insertSql = @"
                INSERT INTO Budget(Id, Balance)
                VALUES(1, @Balance)";

                using (SqliteCommand cmd = new SqliteCommand(insertSql, conn))
                {
                    cmd.Parameters.AddWithValue("@Balance", money);
                    cmd.ExecuteNonQuery();
                }
            }

            LoadBudgetInfo();

            MessageBox.Show("보유금이 설정되었습니다.");
        }

        private void btn_man_AddMoney_Click(object sender, EventArgs e)
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string checkSql = "SELECT COUNT(*) FROM Budget";

                using (SqliteCommand cmd = new SqliteCommand(checkSql, conn))
                {
                    long count = (long)cmd.ExecuteScalar();

                    if (count == 0)
                    {
                        MessageBox.Show("먼저 보유금을 설정하세요.");
                        return;
                    }
                }

                string input = Interaction.InputBox(
                    "추가할 금액을 입력하세요.",
                    "보유금 추가",
                    ""
                );

                if (input == "")
                {
                    return;
                }

                int money;

                if (!int.TryParse(input, out money))
                {
                    MessageBox.Show("숫자만 입력하세요.");
                    return;
                }

                string updateSql = @"
                UPDATE Budget
                SET Balance = Balance + @Money
                WHERE Id = 1";

                using (SqliteCommand cmd = new SqliteCommand(updateSql, conn))
                {
                    cmd.Parameters.AddWithValue("@Money", money);
                    cmd.ExecuteNonQuery();
                }
            }

            LoadBudgetInfo();

            MessageBox.Show("보유금이 추가되었습니다.");
        }

        private void btn_man_ResetMoney_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "보유금을 전체 초기화하시겠습니까?",
                "전체 초기화",
                MessageBoxButtons.YesNo
            );

            if (result == DialogResult.No)
            {
                return;
            }

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "DELETE FROM Budget";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }

            LoadBudgetInfo();

            MessageBox.Show("보유금이 초기화되었습니다.");
        }
    }
}
