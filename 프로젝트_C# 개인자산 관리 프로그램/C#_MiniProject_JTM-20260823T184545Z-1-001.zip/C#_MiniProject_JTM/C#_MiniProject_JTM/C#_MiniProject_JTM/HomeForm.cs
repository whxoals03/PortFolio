﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PdfSharp.Pdf;
using PdfSharp.Drawing;

namespace C__MiniProject_JTM
{
    public partial class HomeForm : Form
    {

        private string loginUserName;

        public HomeForm(string userName)
        {
            InitializeComponent();

            LoadRecentTransactions();

            LoadHomeMoneyInfo();

            LoadExpenseCategory();

            loginUserName = userName;

            pnl_home.Click += pnl_home_Click;
            pnl_income.Click += pnl_income_Click;
            pnl_expense.Click += pnl_expense_Click;
            pnl_search.Click += pnl_search_Click;
            pnl_Management.Click += pnl_Management_Click;

            btn_HomeForm_home.Click += pnl_home_Click;
            btn_HomeForm_income.Click += pnl_income_Click;
            btn_HomeForm_expense.Click += pnl_expense_Click;
            btn_HomeForm_search.Click += pnl_search_Click;
            btn_HomeForm_Management.Click += pnl_Management_Click;

            pic_home_home.Click += pnl_home_Click;
            pic_home_income.Click += pnl_income_Click;
            pic_home_expense.Click += pnl_expense_Click;
            pic_home_search.Click += pnl_search_Click;
            pic_home_management.Click += pnl_Management_Click;

        }

        private void LoadRecentTransactions()
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = @"
                SELECT Date, '수입' AS Type, Amount, Category, Memo
                FROM Income

                UNION ALL

                SELECT Date, '지출' AS Type, Amount, Category, Memo
                FROM Expense

                ORDER BY Date DESC, Amount DESC
                LIMIT 10;
                ";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    using (SqliteDataReader reader = cmd.ExecuteReader())
                    {
                        DataTable dt = new DataTable();
                        dt.Load(reader);

                        DGV_home_search.DataSource = dt;
                        DGV_home_search.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    }
                }
            }
        }

        private int GetTotalIncome()
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "SELECT IFNULL(SUM(Amount), 0) FROM Income";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private int GetTotalExpense()
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "SELECT IFNULL(SUM(Amount), 0) FROM Expense";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        private int GetBalance()
        {
            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "SELECT IFNULL(Balance, 0) FROM Budget WHERE Id = 1";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    object result = cmd.ExecuteScalar();

                    if (result == null)
                    {
                        return 0;
                    }

                    return Convert.ToInt32(result);
                }
            }
        }

        private void LoadHomeMoneyInfo()
        {
            int totalIncome = GetTotalIncome();
            int totalExpense = GetTotalExpense();
            int balance = GetBalance();

            int remainMoney = balance + totalIncome - totalExpense;

            tb_up_income.Text = totalIncome.ToString("N0") + "원";
            tb_up_expense.Text = totalExpense.ToString("N0") + "원";
            tb_up_money.Text = remainMoney.ToString("N0") + "원";

            int totalMoney = balance + totalIncome;

            if (totalMoney <= 0)
            {
                progressBar_bar.Value = 0;
            }
            else
            {
                int percent = (totalExpense * 100) / totalMoney;

                if (percent > 100)
                {
                    percent = 100;
                }

                progressBar_bar.Value = percent;
            }
        }

        private void LoadExpenseCategory()
        {
            list_home_Category.Items.Clear();

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = @"
                SELECT Category, SUM(Amount) AS Total
                FROM Expense
                GROUP BY Category
                ORDER BY Total DESC;
                ";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    using (SqliteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string category = reader["Category"].ToString();
                            int total = Convert.ToInt32(reader["Total"]);

                            list_home_Category.Items.Add(category + " : " + total.ToString("N0") + "원");
                        }
                    }
                }
            }
        }

        private void HomeForm_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(
                pic_user,
                "사용자 : " + loginUserName
            );
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pic_user_Click(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void pnl_main_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_income_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_home_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_expense_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_search_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_Management_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_home_Click(object sender, EventArgs e)
        {
            HomeForm form = new HomeForm("사용자");

            form.Show();

            this.Hide();
        }

        private void pnl_income_Click(object sender, EventArgs e)
        {
            HomeForm_income form = new HomeForm_income();

            form.Show();

            this.Hide();
        }

        private void pnl_expense_Click(object sender, EventArgs e)
        {
            HomeForm_expense form = new HomeForm_expense();

            form.Show();

            this.Hide();
        }

        private void pnl_search_Click(object sender, EventArgs e)
        {
            HomeForm_search form = new HomeForm_search();

            form.Show();

            this.Hide();
        }

        private void pnl_Management_Click(object sender, EventArgs e)
        {
            HomeForm_management form = new HomeForm_management();

            form.Show();

            this.Hide();
        }

        private void progressBar_bar_Click(object sender, EventArgs e)
        {

        }

        private void btn_home_logout_Click(object sender, EventArgs e)
        {
            LoginForm form = new LoginForm();

            form.Show();

            this.Hide();
        }
    }
}
