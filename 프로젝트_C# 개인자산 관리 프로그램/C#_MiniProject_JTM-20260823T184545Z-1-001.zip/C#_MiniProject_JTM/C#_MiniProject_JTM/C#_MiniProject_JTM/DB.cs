﻿using Microsoft.Data.Sqlite;

namespace C__MiniProject_JTM
{
    internal class DB
    {
        public static string ConnStr = "Data Source=users.db";

        public static void Init()
        {
            using (SqliteConnection conn = new SqliteConnection(ConnStr))
            {
                conn.Open();

                string sql = @"
                CREATE TABLE IF NOT EXISTS Users
                (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    LoginId TEXT NOT NULL UNIQUE,
                    Password TEXT NOT NULL,
                    Name TEXT NOT NULL,
                    Phone TEXT,
                    Email TEXT,
                    Birth TEXT
                );";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }

                string incomeSql = @"
                CREATE TABLE IF NOT EXISTS Income
                (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Date TEXT NOT NULL,
                    Amount INTEGER NOT NULL,
                    Category TEXT NOT NULL,
                    Memo TEXT
                );";

                using (SqliteCommand cmd = new SqliteCommand(incomeSql, conn))
                {
                    cmd.ExecuteNonQuery();
                }

                string expenseSql = @"
                CREATE TABLE IF NOT EXISTS Expense
                (
                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                    Date TEXT NOT NULL,
                    Amount INTEGER NOT NULL,
                    Category TEXT NOT NULL,
                    Memo TEXT
                );";

                using (SqliteCommand cmd = new SqliteCommand(expenseSql, conn))
                {
                    cmd.ExecuteNonQuery();
                }

                string budgetSql = @"
                CREATE TABLE IF NOT EXISTS Budget
                (
                    Id INTEGER PRIMARY KEY CHECK (Id = 1),
                    Balance INTEGER NOT NULL
                );";

                using (SqliteCommand cmd = new SqliteCommand(budgetSql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}