﻿namespace C__MiniProject_JTM
{
    partial class Search_Delete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_back = new Button();
            label1 = new Label();
            list_member = new ListView();
            btn_DELETE_move = new Button();
            SuspendLayout();
            // 
            // btn_back
            // 
            btn_back.BackColor = Color.Silver;
            btn_back.BackgroundImageLayout = ImageLayout.None;
            btn_back.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_back.ForeColor = SystemColors.ControlText;
            btn_back.Location = new Point(79, 364);
            btn_back.Margin = new Padding(4);
            btn_back.Name = "btn_back";
            btn_back.Size = new Size(118, 47);
            btn_back.TabIndex = 7;
            btn_back.Text = "이전으로 ";
            btn_back.UseVisualStyleBackColor = false;
            btn_back.Click += btn_back_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(331, 37);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(156, 46);
            label1.TabIndex = 8;
            label1.Text = "회원조회";
            label1.Click += label1_Click;
            // 
            // list_member
            // 
            list_member.BackColor = Color.FromArgb(255, 224, 192);
            list_member.Location = new Point(79, 97);
            list_member.Name = "list_member";
            list_member.Size = new Size(656, 243);
            list_member.TabIndex = 9;
            list_member.UseCompatibleStateImageBehavior = false;
            list_member.SelectedIndexChanged += list_member_SelectedIndexChanged;
            // 
            // btn_DELETE_move
            // 
            btn_DELETE_move.BackColor = Color.Silver;
            btn_DELETE_move.BackgroundImageLayout = ImageLayout.None;
            btn_DELETE_move.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_DELETE_move.ForeColor = SystemColors.ControlText;
            btn_DELETE_move.Location = new Point(611, 364);
            btn_DELETE_move.Margin = new Padding(4);
            btn_DELETE_move.Name = "btn_DELETE_move";
            btn_DELETE_move.Size = new Size(124, 47);
            btn_DELETE_move.TabIndex = 10;
            btn_DELETE_move.Text = "회원삭제 ";
            btn_DELETE_move.UseVisualStyleBackColor = false;
            btn_DELETE_move.Click += btn_DELETE_move_Click;
            // 
            // Search_Delete
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_DELETE_move);
            Controls.Add(list_member);
            Controls.Add(label1);
            Controls.Add(btn_back);
            Name = "Search_Delete";
            Text = "회원조회 및 회원탈퇴";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_back;
        private Label label1;
        private ListView list_member;
        private Button btn_DELETE_move;
    }
}