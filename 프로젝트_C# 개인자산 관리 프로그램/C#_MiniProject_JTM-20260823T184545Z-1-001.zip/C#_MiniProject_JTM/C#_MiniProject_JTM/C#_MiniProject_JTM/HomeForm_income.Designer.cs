﻿namespace C__MiniProject_JTM
{
    partial class HomeForm_income
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeForm_income));
            tb_in_Memo = new TextBox();
            label5 = new Label();
            tb_in_Categori = new TextBox();
            label4 = new Label();
            tb_in_Money = new TextBox();
            label3 = new Label();
            tb_in_Date = new TextBox();
            label1 = new Label();
            panel6 = new Panel();
            btn_in_Registration = new Button();
            label2 = new Label();
            pic_income_management = new PictureBox();
            btn_income_management = new Button();
            pnl_in_management = new Panel();
            pic_income_search = new PictureBox();
            pnl_in_search = new Panel();
            btn_income_search = new Button();
            pic_income_expense = new PictureBox();
            btn_income_expense = new Button();
            pnl_in_expense = new Panel();
            pic_income_income = new PictureBox();
            btn_income_income = new Button();
            pnl_in_income = new Panel();
            pic_income_home = new PictureBox();
            btn_income_home = new Button();
            pnl_in_home = new Panel();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_income_management).BeginInit();
            pnl_in_management.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_income_search).BeginInit();
            pnl_in_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_income_expense).BeginInit();
            pnl_in_expense.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_income_income).BeginInit();
            pnl_in_income.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_income_home).BeginInit();
            pnl_in_home.SuspendLayout();
            SuspendLayout();
            // 
            // tb_in_Memo
            // 
            tb_in_Memo.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_in_Memo.ForeColor = SystemColors.WindowFrame;
            tb_in_Memo.Location = new Point(147, 292);
            tb_in_Memo.Name = "tb_in_Memo";
            tb_in_Memo.Size = new Size(240, 34);
            tb_in_Memo.TabIndex = 10;
            tb_in_Memo.Text = "메모 입력";
            tb_in_Memo.Enter += tb_in_Memo_Enter;
            tb_in_Memo.Leave += tb_in_Memo_Leave;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(63, 295);
            label5.Name = "label5";
            label5.Size = new Size(52, 28);
            label5.TabIndex = 9;
            label5.Text = "메모";
            // 
            // tb_in_Categori
            // 
            tb_in_Categori.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_in_Categori.ForeColor = SystemColors.WindowFrame;
            tb_in_Categori.Location = new Point(147, 230);
            tb_in_Categori.Name = "tb_in_Categori";
            tb_in_Categori.Size = new Size(240, 34);
            tb_in_Categori.TabIndex = 10;
            tb_in_Categori.Text = "용돈, 월급 등";
            tb_in_Categori.Enter += tb_in_Categori_Enter;
            tb_in_Categori.Leave += tb_in_Categori_Leave;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(45, 233);
            label4.Name = "label4";
            label4.Size = new Size(92, 28);
            label4.TabIndex = 9;
            label4.Text = "카테고리";
            // 
            // tb_in_Money
            // 
            tb_in_Money.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_in_Money.ForeColor = SystemColors.WindowFrame;
            tb_in_Money.Location = new Point(147, 168);
            tb_in_Money.Name = "tb_in_Money";
            tb_in_Money.Size = new Size(240, 34);
            tb_in_Money.TabIndex = 10;
            tb_in_Money.Text = "금액만 입력 \"10,000\"";
            tb_in_Money.Enter += tb_in_Money_Enter;
            tb_in_Money.Leave += tb_in_Money_Leave;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(63, 171);
            label3.Name = "label3";
            label3.Size = new Size(52, 28);
            label3.TabIndex = 9;
            label3.Text = "금액";
            // 
            // tb_in_Date
            // 
            tb_in_Date.Font = new Font("맑은 고딕 Semilight", 12F);
            tb_in_Date.ForeColor = SystemColors.WindowFrame;
            tb_in_Date.Location = new Point(147, 106);
            tb_in_Date.Name = "tb_in_Date";
            tb_in_Date.Size = new Size(240, 34);
            tb_in_Date.TabIndex = 10;
            tb_in_Date.Text = "'년월일' 을 숫자 6개 입력";
            tb_in_Date.Enter += tb_in_Date_Enter;
            tb_in_Date.Leave += tb_in_Date_Leave;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("맑은 고딕", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(18, 16);
            label1.Name = "label1";
            label1.Size = new Size(141, 40);
            label1.TabIndex = 8;
            label1.Text = "수입 입력";
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(btn_in_Registration);
            panel6.Controls.Add(tb_in_Memo);
            panel6.Controls.Add(label5);
            panel6.Controls.Add(tb_in_Categori);
            panel6.Controls.Add(label4);
            panel6.Controls.Add(tb_in_Money);
            panel6.Controls.Add(label3);
            panel6.Controls.Add(tb_in_Date);
            panel6.Controls.Add(label2);
            panel6.Controls.Add(label1);
            panel6.Location = new Point(301, 63);
            panel6.Name = "panel6";
            panel6.Size = new Size(500, 600);
            panel6.TabIndex = 13;
            // 
            // btn_in_Registration
            // 
            btn_in_Registration.BackColor = Color.FromArgb(192, 192, 255);
            btn_in_Registration.BackgroundImageLayout = ImageLayout.None;
            btn_in_Registration.Font = new Font("맑은 고딕", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_in_Registration.ForeColor = SystemColors.ControlText;
            btn_in_Registration.Location = new Point(18, 514);
            btn_in_Registration.Margin = new Padding(4);
            btn_in_Registration.Name = "btn_in_Registration";
            btn_in_Registration.Size = new Size(465, 60);
            btn_in_Registration.TabIndex = 19;
            btn_in_Registration.Text = "등록";
            btn_in_Registration.UseVisualStyleBackColor = false;
            btn_in_Registration.Click += btn_in_Registration_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(63, 109);
            label2.Name = "label2";
            label2.Size = new Size(52, 28);
            label2.TabIndex = 9;
            label2.Text = "날짜";
            // 
            // pic_income_management
            // 
            pic_income_management.Image = (Image)resources.GetObject("pic_income_management.Image");
            pic_income_management.Location = new Point(4, 5);
            pic_income_management.Margin = new Padding(4);
            pic_income_management.Name = "pic_income_management";
            pic_income_management.Size = new Size(62, 49);
            pic_income_management.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_income_management.TabIndex = 1;
            pic_income_management.TabStop = false;
            // 
            // btn_income_management
            // 
            btn_income_management.FlatStyle = FlatStyle.Flat;
            btn_income_management.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_income_management.Location = new Point(71, 5);
            btn_income_management.Margin = new Padding(4);
            btn_income_management.Name = "btn_income_management";
            btn_income_management.Size = new Size(193, 51);
            btn_income_management.TabIndex = 0;
            btn_income_management.Text = "예산 관리";
            btn_income_management.TextAlign = ContentAlignment.MiddleLeft;
            btn_income_management.UseVisualStyleBackColor = true;
            // 
            // pnl_in_management
            // 
            pnl_in_management.BackColor = Color.FromArgb(224, 224, 224);
            pnl_in_management.Controls.Add(pic_income_management);
            pnl_in_management.Controls.Add(btn_income_management);
            pnl_in_management.Location = new Point(23, 335);
            pnl_in_management.Margin = new Padding(4);
            pnl_in_management.Name = "pnl_in_management";
            pnl_in_management.Size = new Size(271, 60);
            pnl_in_management.TabIndex = 8;
            pnl_in_management.Click += pnl_in_management_Click;
            pnl_in_management.Paint += pnl_in_management_Paint;
            // 
            // pic_income_search
            // 
            pic_income_search.Image = (Image)resources.GetObject("pic_income_search.Image");
            pic_income_search.Location = new Point(4, 5);
            pic_income_search.Margin = new Padding(4);
            pic_income_search.Name = "pic_income_search";
            pic_income_search.Size = new Size(62, 49);
            pic_income_search.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_income_search.TabIndex = 1;
            pic_income_search.TabStop = false;
            pic_income_search.Click += pictureBox9_Click;
            // 
            // pnl_in_search
            // 
            pnl_in_search.BackColor = Color.FromArgb(224, 224, 224);
            pnl_in_search.Controls.Add(pic_income_search);
            pnl_in_search.Controls.Add(btn_income_search);
            pnl_in_search.Location = new Point(23, 267);
            pnl_in_search.Margin = new Padding(4);
            pnl_in_search.Name = "pnl_in_search";
            pnl_in_search.Size = new Size(271, 60);
            pnl_in_search.TabIndex = 9;
            pnl_in_search.Click += pnl_in_search_Click;
            pnl_in_search.Paint += pnl_in_search_Paint;
            // 
            // btn_income_search
            // 
            btn_income_search.FlatStyle = FlatStyle.Flat;
            btn_income_search.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_income_search.Location = new Point(71, 5);
            btn_income_search.Margin = new Padding(4);
            btn_income_search.Name = "btn_income_search";
            btn_income_search.Size = new Size(193, 51);
            btn_income_search.TabIndex = 0;
            btn_income_search.Text = "내역 조회";
            btn_income_search.TextAlign = ContentAlignment.MiddleLeft;
            btn_income_search.UseVisualStyleBackColor = true;
            btn_income_search.Click += button4_Click;
            // 
            // pic_income_expense
            // 
            pic_income_expense.Image = (Image)resources.GetObject("pic_income_expense.Image");
            pic_income_expense.Location = new Point(4, 5);
            pic_income_expense.Margin = new Padding(4);
            pic_income_expense.Name = "pic_income_expense";
            pic_income_expense.Size = new Size(62, 49);
            pic_income_expense.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_income_expense.TabIndex = 1;
            pic_income_expense.TabStop = false;
            // 
            // btn_income_expense
            // 
            btn_income_expense.FlatStyle = FlatStyle.Flat;
            btn_income_expense.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_income_expense.Location = new Point(71, 5);
            btn_income_expense.Margin = new Padding(4);
            btn_income_expense.Name = "btn_income_expense";
            btn_income_expense.Size = new Size(193, 51);
            btn_income_expense.TabIndex = 0;
            btn_income_expense.Text = "지출 입력";
            btn_income_expense.TextAlign = ContentAlignment.MiddleLeft;
            btn_income_expense.UseVisualStyleBackColor = true;
            // 
            // pnl_in_expense
            // 
            pnl_in_expense.BackColor = Color.FromArgb(224, 224, 224);
            pnl_in_expense.Controls.Add(pic_income_expense);
            pnl_in_expense.Controls.Add(btn_income_expense);
            pnl_in_expense.Location = new Point(23, 199);
            pnl_in_expense.Margin = new Padding(4);
            pnl_in_expense.Name = "pnl_in_expense";
            pnl_in_expense.Size = new Size(271, 60);
            pnl_in_expense.TabIndex = 10;
            pnl_in_expense.Click += pnl_in_expense_Click;
            pnl_in_expense.Paint += pnl_in_expense_Paint;
            // 
            // pic_income_income
            // 
            pic_income_income.Image = (Image)resources.GetObject("pic_income_income.Image");
            pic_income_income.Location = new Point(4, 5);
            pic_income_income.Margin = new Padding(4);
            pic_income_income.Name = "pic_income_income";
            pic_income_income.Size = new Size(62, 49);
            pic_income_income.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_income_income.TabIndex = 1;
            pic_income_income.TabStop = false;
            // 
            // btn_income_income
            // 
            btn_income_income.FlatStyle = FlatStyle.Flat;
            btn_income_income.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_income_income.Location = new Point(71, 5);
            btn_income_income.Margin = new Padding(4);
            btn_income_income.Name = "btn_income_income";
            btn_income_income.Size = new Size(193, 51);
            btn_income_income.TabIndex = 0;
            btn_income_income.Text = "수입 입력";
            btn_income_income.TextAlign = ContentAlignment.MiddleLeft;
            btn_income_income.UseVisualStyleBackColor = true;
            // 
            // pnl_in_income
            // 
            pnl_in_income.BackColor = Color.FromArgb(224, 224, 224);
            pnl_in_income.Controls.Add(pic_income_income);
            pnl_in_income.Controls.Add(btn_income_income);
            pnl_in_income.Location = new Point(23, 131);
            pnl_in_income.Margin = new Padding(4);
            pnl_in_income.Name = "pnl_in_income";
            pnl_in_income.Size = new Size(271, 60);
            pnl_in_income.TabIndex = 11;
            pnl_in_income.Click += pnl_in_income_Click;
            pnl_in_income.Paint += pnl_in_income_Paint;
            // 
            // pic_income_home
            // 
            pic_income_home.Image = (Image)resources.GetObject("pic_income_home.Image");
            pic_income_home.Location = new Point(4, 5);
            pic_income_home.Margin = new Padding(4);
            pic_income_home.Name = "pic_income_home";
            pic_income_home.Size = new Size(62, 49);
            pic_income_home.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_income_home.TabIndex = 1;
            pic_income_home.TabStop = false;
            // 
            // btn_income_home
            // 
            btn_income_home.FlatStyle = FlatStyle.Flat;
            btn_income_home.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_income_home.Location = new Point(71, 5);
            btn_income_home.Margin = new Padding(4);
            btn_income_home.Name = "btn_income_home";
            btn_income_home.Size = new Size(193, 51);
            btn_income_home.TabIndex = 0;
            btn_income_home.Text = "홈";
            btn_income_home.TextAlign = ContentAlignment.MiddleLeft;
            btn_income_home.UseVisualStyleBackColor = true;
            // 
            // pnl_in_home
            // 
            pnl_in_home.BackColor = Color.FromArgb(224, 224, 224);
            pnl_in_home.Controls.Add(pic_income_home);
            pnl_in_home.Controls.Add(btn_income_home);
            pnl_in_home.Location = new Point(23, 63);
            pnl_in_home.Margin = new Padding(4);
            pnl_in_home.Name = "pnl_in_home";
            pnl_in_home.Size = new Size(271, 60);
            pnl_in_home.TabIndex = 12;
            pnl_in_home.Click += pnl_in_home_Click;
            pnl_in_home.Paint += pnl_in_home_Paint;
            // 
            // HomeForm_income
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(824, 726);
            Controls.Add(panel6);
            Controls.Add(pnl_in_management);
            Controls.Add(pnl_in_search);
            Controls.Add(pnl_in_expense);
            Controls.Add(pnl_in_income);
            Controls.Add(pnl_in_home);
            Name = "HomeForm_income";
            Text = "HomeForm_income";
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pic_income_management).EndInit();
            pnl_in_management.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_income_search).EndInit();
            pnl_in_search.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_income_expense).EndInit();
            pnl_in_expense.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_income_income).EndInit();
            pnl_in_income.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_income_home).EndInit();
            pnl_in_home.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TextBox tb_in_Memo;
        private Label label5;
        private TextBox tb_in_Categori;
        private Label label4;
        private TextBox tb_in_Money;
        private Label label3;
        private TextBox tb_in_Date;
        private Label label1;
        private Panel panel6;
        private Label label2;
        private PictureBox pic_income_management;
        private Button btn_income_management;
        private Panel pnl_in_management;
        private PictureBox pic_income_search;
        private Panel pnl_in_search;
        private Button btn_income_search;
        private PictureBox pic_income_expense;
        private Button btn_income_expense;
        private Panel pnl_in_expense;
        private PictureBox pic_income_income;
        private Button btn_income_income;
        private Panel pnl_in_income;
        private PictureBox pic_income_home;
        private Button btn_income_home;
        private Panel pnl_in_home;
        private Button btn_in_Registration;
    }
}