﻿using System;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;

namespace C__MiniProject_JTM
{
    public partial class Search_Delete : Form
    {
        public Search_Delete()
        {
            InitializeComponent();

            list_member.View = View.Details;
            list_member.FullRowSelect = true;
            list_member.GridLines = true;

            list_member.Columns.Clear();
            list_member.Columns.Add("아이디", 200);
            list_member.Columns.Add("이름", 150);

            LoadMemberList();
        }

        private void LoadMemberList()
        {
            list_member.Items.Clear();

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "SELECT LoginId, Name FROM Users";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    using (SqliteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string loginId = reader["LoginId"].ToString();
                            string name = reader["Name"].ToString();

                            ListViewItem item = new ListViewItem(loginId);
                            item.SubItems.Add(name);

                            list_member.Items.Add(item);
                        }
                    }
                }
            }
        }

        private void btn_DELETE_move_Click(object sender, EventArgs e)
        {
            DELETE form = new DELETE();

            form.Show();

            this.Hide();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            LoginForm form = new LoginForm();

            form.Show();

            this.Hide();
        }

        private void list_member_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (list_member.SelectedItems.Count == 0)
            {
                MessageBox.Show("삭제할 회원을 선택해주세요.");
                return;
            }

            string selectedId = list_member.SelectedItems[0].SubItems[0].Text;

            DialogResult result = MessageBox.Show(
                selectedId + " 회원을 삭제하시겠습니까?",
                "회원 삭제 확인",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            if (result != DialogResult.Yes)
            {
                return;
            }

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = "DELETE FROM Users WHERE LoginId = @LoginId";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@LoginId", selectedId);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("회원이 삭제되었습니다.");

            LoadMemberList();
        }
    }
}