﻿namespace C__MiniProject_JTM
{
    partial class DELETE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tb_DELETE_birth = new TextBox();
            label7 = new Label();
            tb_DELETE_email = new TextBox();
            label6 = new Label();
            tb_DELETE_pw = new TextBox();
            label3 = new Label();
            tb_DELETE_phone = new TextBox();
            label5 = new Label();
            tb_DELETE_name = new TextBox();
            label4 = new Label();
            tb_DELETE_id = new TextBox();
            label2 = new Label();
            btn_DELETE = new Button();
            btn_DELETE_back = new Button();
            SuspendLayout();
            // 
            // tb_DELETE_birth
            // 
            tb_DELETE_birth.BorderStyle = BorderStyle.FixedSingle;
            tb_DELETE_birth.Font = new Font("맑은 고딕 Semilight", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_DELETE_birth.ForeColor = SystemColors.WindowFrame;
            tb_DELETE_birth.Location = new Point(22, 437);
            tb_DELETE_birth.Margin = new Padding(4);
            tb_DELETE_birth.Name = "tb_DELETE_birth";
            tb_DELETE_birth.Size = new Size(510, 34);
            tb_DELETE_birth.TabIndex = 29;
            tb_DELETE_birth.Text = "8자리를 입력해주세요";
            tb_DELETE_birth.Enter += tb_DELETE_birth_Enter;
            tb_DELETE_birth.Leave += tb_DELETE_birth_Leave_1;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(22, 405);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(92, 28);
            label7.TabIndex = 28;
            label7.Text = "생년월일";
            // 
            // tb_DELETE_email
            // 
            tb_DELETE_email.BorderStyle = BorderStyle.FixedSingle;
            tb_DELETE_email.Font = new Font("맑은 고딕 Semilight", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_DELETE_email.ForeColor = SystemColors.WindowFrame;
            tb_DELETE_email.Location = new Point(22, 362);
            tb_DELETE_email.Margin = new Padding(4);
            tb_DELETE_email.Name = "tb_DELETE_email";
            tb_DELETE_email.Size = new Size(510, 34);
            tb_DELETE_email.TabIndex = 27;
            tb_DELETE_email.Text = "이메일을 입력해주세요";
            tb_DELETE_email.Enter += tb_DELETE_email_Enter;
            tb_DELETE_email.Leave += tb_DELETE_email_Leave;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(22, 330);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(119, 28);
            label6.TabIndex = 26;
            label6.Text = "이메일 주소";
            // 
            // tb_DELETE_pw
            // 
            tb_DELETE_pw.BorderStyle = BorderStyle.FixedSingle;
            tb_DELETE_pw.Font = new Font("맑은 고딕 Semilight", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_DELETE_pw.ForeColor = SystemColors.WindowFrame;
            tb_DELETE_pw.Location = new Point(22, 140);
            tb_DELETE_pw.Margin = new Padding(4);
            tb_DELETE_pw.Name = "tb_DELETE_pw";
            tb_DELETE_pw.Size = new Size(510, 34);
            tb_DELETE_pw.TabIndex = 23;
            tb_DELETE_pw.Text = "비밀번호 입력 (문자, 숫자, 특수문자 포함 8 ~ 20자 )";
            tb_DELETE_pw.Enter += tb_DELETE_pw_Enter;
            tb_DELETE_pw.Leave += tb_DELETE_pw_Leave;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(22, 108);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(92, 28);
            label3.TabIndex = 22;
            label3.Text = "비밀번호";
            // 
            // tb_DELETE_phone
            // 
            tb_DELETE_phone.BorderStyle = BorderStyle.FixedSingle;
            tb_DELETE_phone.Font = new Font("맑은 고딕 Semilight", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_DELETE_phone.ForeColor = SystemColors.WindowFrame;
            tb_DELETE_phone.Location = new Point(22, 288);
            tb_DELETE_phone.Margin = new Padding(4);
            tb_DELETE_phone.Name = "tb_DELETE_phone";
            tb_DELETE_phone.Size = new Size(510, 34);
            tb_DELETE_phone.TabIndex = 19;
            tb_DELETE_phone.Text = "휴대폰 번호 입력 ( '-' 제외 11자리 입력 )";
            tb_DELETE_phone.Enter += tb_DELETE_phone_Enter;
            tb_DELETE_phone.Leave += tb_DELETE_phone_Leave;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(22, 256);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(92, 28);
            label5.TabIndex = 16;
            label5.Text = "전화번호";
            // 
            // tb_DELETE_name
            // 
            tb_DELETE_name.BorderStyle = BorderStyle.FixedSingle;
            tb_DELETE_name.Font = new Font("맑은 고딕 Semilight", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_DELETE_name.ForeColor = SystemColors.WindowFrame;
            tb_DELETE_name.Location = new Point(22, 213);
            tb_DELETE_name.Margin = new Padding(4);
            tb_DELETE_name.Name = "tb_DELETE_name";
            tb_DELETE_name.Size = new Size(510, 34);
            tb_DELETE_name.TabIndex = 20;
            tb_DELETE_name.Text = "이름을 입력해주세요";
            tb_DELETE_name.Enter += tb_DELETE_name_Enter;
            tb_DELETE_name.Leave += tb_DELETE_name_Leave;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(22, 181);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(52, 28);
            label4.TabIndex = 17;
            label4.Text = "이름";
            // 
            // tb_DELETE_id
            // 
            tb_DELETE_id.BorderStyle = BorderStyle.FixedSingle;
            tb_DELETE_id.Font = new Font("맑은 고딕 Semilight", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_DELETE_id.ForeColor = SystemColors.WindowFrame;
            tb_DELETE_id.Location = new Point(22, 65);
            tb_DELETE_id.Margin = new Padding(4);
            tb_DELETE_id.Name = "tb_DELETE_id";
            tb_DELETE_id.Size = new Size(510, 34);
            tb_DELETE_id.TabIndex = 21;
            tb_DELETE_id.Text = "아이디 입력 (6 ~ 20자)";
            tb_DELETE_id.Enter += tb_DELETE_id_Enter;
            tb_DELETE_id.Leave += tb_DELETE_id_Leave;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(22, 33);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(72, 28);
            label2.TabIndex = 18;
            label2.Text = "아이디";
            // 
            // btn_DELETE
            // 
            btn_DELETE.BackColor = Color.Silver;
            btn_DELETE.BackgroundImageLayout = ImageLayout.None;
            btn_DELETE.Font = new Font("맑은 고딕", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_DELETE.ForeColor = SystemColors.ControlText;
            btn_DELETE.Location = new Point(22, 518);
            btn_DELETE.Margin = new Padding(4);
            btn_DELETE.Name = "btn_DELETE";
            btn_DELETE.Size = new Size(510, 60);
            btn_DELETE.TabIndex = 30;
            btn_DELETE.Text = "회원탈퇴";
            btn_DELETE.UseVisualStyleBackColor = false;
            btn_DELETE.Click += btn_DELETE_Click_1;
            // 
            // btn_DELETE_back
            // 
            btn_DELETE_back.BackColor = Color.Silver;
            btn_DELETE_back.BackgroundImageLayout = ImageLayout.None;
            btn_DELETE_back.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_DELETE_back.ForeColor = SystemColors.ControlText;
            btn_DELETE_back.Location = new Point(22, 680);
            btn_DELETE_back.Margin = new Padding(4);
            btn_DELETE_back.Name = "btn_DELETE_back";
            btn_DELETE_back.Size = new Size(126, 47);
            btn_DELETE_back.TabIndex = 31;
            btn_DELETE_back.Text = "이전으로 ";
            btn_DELETE_back.UseVisualStyleBackColor = false;
            btn_DELETE_back.Click += btn_DELETE_back_Click;
            // 
            // DELETE
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(563, 792);
            Controls.Add(btn_DELETE_back);
            Controls.Add(btn_DELETE);
            Controls.Add(tb_DELETE_birth);
            Controls.Add(label7);
            Controls.Add(tb_DELETE_email);
            Controls.Add(label6);
            Controls.Add(tb_DELETE_pw);
            Controls.Add(label3);
            Controls.Add(tb_DELETE_phone);
            Controls.Add(label5);
            Controls.Add(tb_DELETE_name);
            Controls.Add(label4);
            Controls.Add(tb_DELETE_id);
            Controls.Add(label2);
            Name = "DELETE";
            Text = "DELETE";
            Load += DELETE_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tb_DELETE_birth;
        private Label label7;
        private TextBox tb_DELETE_email;
        private Label label6;
        private TextBox tb_DELETE_pw;
        private Label label3;
        private TextBox tb_DELETE_phone;
        private Label label5;
        private TextBox tb_DELETE_name;
        private Label label4;
        private TextBox tb_DELETE_id;
        private Label label2;
        private Button btn_DELETE;
        private Button btn_DELETE_back;
    }
}