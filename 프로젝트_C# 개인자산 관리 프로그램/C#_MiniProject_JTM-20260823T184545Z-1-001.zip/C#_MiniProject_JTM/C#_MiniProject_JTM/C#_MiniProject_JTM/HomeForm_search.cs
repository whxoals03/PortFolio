﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using System.IO;

namespace C__MiniProject_JTM
{
    public partial class HomeForm_search : Form
    {
        public HomeForm_search()
        {
            InitializeComponent();

            pnl_se_home.Click += pnl_se_home_Click;
            pnl_se_income.Click += pnl_se_income_Click;
            pnl_se_expense.Click += pnl_se_expense_Click;
            pnl_se_search.Click += pnl_se_search_Click;
            pnl_se_management.Click += pnl_se_management_Click;

            btn_search_home.Click += pnl_se_home_Click;
            btn_search_income.Click += pnl_se_income_Click;
            btn_search_expense.Click += pnl_se_expense_Click;
            btn_search_search.Click += pnl_se_search_Click;
            btn_search_management.Click += pnl_se_management_Click;

            pic_search_home.Click += pnl_se_home_Click;
            pic_search_income.Click += pnl_se_income_Click;
            pic_search_expense.Click += pnl_se_expense_Click;
            pic_search_search.Click += pnl_se_search_Click;
            pic_search_management.Click += pnl_se_management_Click;

            pic_search_management.Click += pnl_se_management_Click;

            try
            {
                LoadSearchData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void LoadSearchData()
        {
            DGV_se_search.Rows.Clear();
            DGV_se_search.Columns.Clear();

            DGV_se_search.Columns.Add("삭제키", "삭제키");
            DGV_se_search.Columns.Add("원본ID", "원본ID");
            DGV_se_search.Columns.Add("구분", "구분");
            DGV_se_search.Columns.Add("날짜", "날짜");
            DGV_se_search.Columns.Add("금액", "금액");
            DGV_se_search.Columns.Add("카테고리", "카테고리");
            DGV_se_search.Columns.Add("메모", "메모");

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = @"
                SELECT 
                    'I' || Id AS 삭제키,
                    Id AS 원본ID,
                    '수입' AS 구분,
                    Date AS 날짜,
                    Amount AS 금액,
                    Category AS 카테고리,
                    Memo AS 메모
                FROM Income

                UNION ALL

                SELECT 
                    'E' || Id AS 삭제키,
                    Id AS 원본ID,
                    '지출' AS 구분,
                    Date AS 날짜,
                    Amount AS 금액,
                    Category AS 카테고리,
                    Memo AS 메모
                FROM Expense

                ORDER BY 날짜 ASC, 카테고리 ASC, 구분 ASC;
                ";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    using (SqliteDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            DGV_se_search.Rows.Add(
                                reader["삭제키"].ToString(),
                                reader["원본ID"].ToString(),
                                reader["구분"].ToString(),
                                reader["날짜"].ToString(),
                                reader["금액"].ToString(),
                                reader["카테고리"].ToString(),
                                reader["메모"].ToString()
                            );
                        }
                    }
                }
            }

            DGV_se_search.Columns["삭제키"].Visible = false;
            DGV_se_search.Columns["원본ID"].Visible = false;

            DGV_se_search.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            DGV_se_search.RowHeadersVisible = false;
            DGV_se_search.AllowUserToAddRows = false;
            DGV_se_search.ReadOnly = true;
            DGV_se_search.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void HomeForm_search_Load(object sender, EventArgs e)
        {

        }

        private void pnl_se_home_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_se_income_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_se_management_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_se_expense_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_se_search_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_se_home_Click(object sender, EventArgs e)
        {
            HomeForm form = new HomeForm("사용자");

            form.Show();

            this.Hide();
        }

        private void pnl_se_income_Click(object sender, EventArgs e)
        {
            HomeForm_income form = new HomeForm_income();

            form.Show();

            this.Hide();
        }

        private void pnl_se_expense_Click(object sender, EventArgs e)
        {
            HomeForm_expense form = new HomeForm_expense();

            form.Show();

            this.Hide();
        }

        private void pnl_se_search_Click(object sender, EventArgs e)
        {

        }

        private void pnl_se_management_Click(object sender, EventArgs e)
        {
            HomeForm_management form = new HomeForm_management();

            form.Show();

            this.Hide();
        }

        private void btn_se_DELETE_Click(object sender, EventArgs e)
        {
            if (DGV_se_search.CurrentRow == null)
            {
                MessageBox.Show("삭제할 항목을 선택하세요.");
                return;
            }

            int id = Convert.ToInt32(DGV_se_search.CurrentRow.Cells["원본ID"].Value);
            string type = DGV_se_search.CurrentRow.Cells["구분"].Value.ToString();

            string tableName = "";

            if (type == "수입")
            {
                tableName = "Income";
            }
            else if (type == "지출")
            {
                tableName = "Expense";
            }
            else
            {
                MessageBox.Show("구분 값을 확인할 수 없습니다.");
                return;
            }

            DialogResult result = MessageBox.Show(
                "선택한 항목을 삭제하시겠습니까?",
                "삭제 확인",
                MessageBoxButtons.YesNo
            );

            if (result == DialogResult.No)
            {
                return;
            }

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = $"DELETE FROM {tableName} WHERE Id = @Id";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("삭제되었습니다.");

            LoadSearchData();
        }

        private void btn_se_ALLDELETE_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "수입과 지출 내역을 전체 삭제하시겠습니까?",
                "전체 삭제 확인",
                MessageBoxButtons.YesNo
            );

            if (result == DialogResult.No)
            {
                return;
            }

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = @"
                DELETE FROM Income;
                DELETE FROM Expense;
                ";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("전체 내역이 삭제되었습니다.");

            LoadSearchData();
        }

        private void btn_search_PDF_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();

            save.Filter = "PDF 파일|*.pdf";
            save.FileName = "개인지출관리_보고서.pdf";

            if (save.ShowDialog() != DialogResult.OK)
                return;

            int totalIncome = 0;
            int totalExpense = 0;

            foreach (DataGridViewRow row in DGV_se_search.Rows)
            {
                if (row.IsNewRow)
                    continue;

                string type = row.Cells["구분"].Value.ToString();
                int money = Convert.ToInt32(row.Cells["금액"].Value);

                if (type == "수입")
                    totalIncome += money;
                else if (type == "지출")
                    totalExpense += money;
            }

            int remainMoney = totalIncome - totalExpense;

            PdfDocument document = new PdfDocument();
            document.Info.Title = "개인 지출 관리 보고서";

            PdfPage page = document.AddPage();
            XGraphics gfx = XGraphics.FromPdfPage(page);

            XFont titleFont = new XFont("Malgun Gothic", 20);
            XFont headerFont = new XFont("Malgun Gothic", 12);
            XFont textFont = new XFont("Malgun Gothic", 10);

            int y = 50;

            gfx.DrawString("개인 지출 관리 보고서", titleFont, XBrushes.Black, new XPoint(170, y));
            y += 40;

            gfx.DrawString("생성일 : " + DateTime.Now.ToString("yyyy-MM-dd"), textFont, XBrushes.Black, new XPoint(40, y));
            y += 30;

            gfx.DrawString("총 수입 : " + totalIncome.ToString("N0") + "원", headerFont, XBrushes.Black, new XPoint(40, y));
            y += 25;

            gfx.DrawString("총 지출 : " + totalExpense.ToString("N0") + "원", headerFont, XBrushes.Black, new XPoint(40, y));
            y += 25;

            gfx.DrawString("현재 잔액 : " + remainMoney.ToString("N0") + "원", headerFont, XBrushes.Black, new XPoint(40, y));
            y += 40;

            gfx.DrawString("거래 내역", headerFont, XBrushes.Black, new XPoint(40, y));
            y += 25;

            gfx.DrawString("구분", textFont, XBrushes.Black, new XPoint(40, y));
            gfx.DrawString("날짜", textFont, XBrushes.Black, new XPoint(100, y));
            gfx.DrawString("금액", textFont, XBrushes.Black, new XPoint(190, y));
            gfx.DrawString("카테고리", textFont, XBrushes.Black, new XPoint(290, y));
            gfx.DrawString("메모", textFont, XBrushes.Black, new XPoint(400, y));

            y += 15;
            gfx.DrawLine(XPens.Black, 40, y, 550, y);
            y += 20;

            int count = 0;

            foreach (DataGridViewRow row in DGV_se_search.Rows)
            {
                if (row.IsNewRow)
                    continue;

                if (y > 780)
                {
                    page = document.AddPage();
                    gfx = XGraphics.FromPdfPage(page);
                    y = 50;
                }

                string type = row.Cells["구분"].Value.ToString();
                string date = row.Cells["날짜"].Value.ToString();
                string money = Convert.ToInt32(row.Cells["금액"].Value).ToString("N0");
                string category = row.Cells["카테고리"].Value.ToString();
                string memo = row.Cells["메모"].Value.ToString();

                gfx.DrawString(type, textFont, XBrushes.Black, new XPoint(40, y));
                gfx.DrawString(date, textFont, XBrushes.Black, new XPoint(100, y));
                gfx.DrawString(money, textFont, XBrushes.Black, new XPoint(190, y));
                gfx.DrawString(category, textFont, XBrushes.Black, new XPoint(290, y));
                gfx.DrawString(memo, textFont, XBrushes.Black, new XPoint(400, y));

                y += 22;
                count++;
            }

            y += 20;
            gfx.DrawString("총 거래 건수 : " + count + "건", headerFont, XBrushes.Black, new XPoint(40, y));

            document.Save(save.FileName);
            document.Close();

            MessageBox.Show("PDF 저장 완료");
        }
    }
}
