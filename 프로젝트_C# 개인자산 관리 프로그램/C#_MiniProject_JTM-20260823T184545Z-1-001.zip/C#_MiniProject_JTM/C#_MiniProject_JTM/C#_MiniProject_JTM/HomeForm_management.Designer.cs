﻿namespace C__MiniProject_JTM
{
    partial class HomeForm_management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeForm_management));
            pnl_man_management = new Panel();
            pic_man_management = new PictureBox();
            btn_man_management = new Button();
            pic_man_home = new PictureBox();
            pnl_man_income = new Panel();
            pic_man_income = new PictureBox();
            btn_man_income = new Button();
            pnl_man_expense = new Panel();
            pic_man_expense = new PictureBox();
            btn_man_expense = new Button();
            panel6 = new Panel();
            tb_man_RemainMoney = new TextBox();
            label5 = new Label();
            tb_man_TotalExpense = new TextBox();
            label4 = new Label();
            tb_man_TotalIncome = new TextBox();
            label3 = new Label();
            btn_man_AddMoney = new Button();
            btn_man_SetMoney = new Button();
            btn_man_ResetMoney = new Button();
            tb_man_CurrentMoney = new TextBox();
            label2 = new Label();
            label1 = new Label();
            btn_man_search = new Button();
            pnl_man_search = new Panel();
            pic_man_search = new PictureBox();
            pnl_man_home = new Panel();
            btn_man_home = new Button();
            pnl_man_management.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_man_management).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pic_man_home).BeginInit();
            pnl_man_income.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_man_income).BeginInit();
            pnl_man_expense.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_man_expense).BeginInit();
            panel6.SuspendLayout();
            pnl_man_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_man_search).BeginInit();
            pnl_man_home.SuspendLayout();
            SuspendLayout();
            // 
            // pnl_man_management
            // 
            pnl_man_management.BackColor = Color.FromArgb(224, 224, 224);
            pnl_man_management.Controls.Add(pic_man_management);
            pnl_man_management.Controls.Add(btn_man_management);
            pnl_man_management.Location = new Point(23, 335);
            pnl_man_management.Margin = new Padding(4);
            pnl_man_management.Name = "pnl_man_management";
            pnl_man_management.Size = new Size(271, 60);
            pnl_man_management.TabIndex = 14;
            pnl_man_management.Click += pnl_man_management_Click;
            pnl_man_management.Paint += pnl_man_management_Paint;
            // 
            // pic_man_management
            // 
            pic_man_management.Image = (Image)resources.GetObject("pic_man_management.Image");
            pic_man_management.Location = new Point(4, 5);
            pic_man_management.Margin = new Padding(4);
            pic_man_management.Name = "pic_man_management";
            pic_man_management.Size = new Size(62, 49);
            pic_man_management.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_man_management.TabIndex = 1;
            pic_man_management.TabStop = false;
            // 
            // btn_man_management
            // 
            btn_man_management.FlatStyle = FlatStyle.Flat;
            btn_man_management.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_man_management.Location = new Point(71, 5);
            btn_man_management.Margin = new Padding(4);
            btn_man_management.Name = "btn_man_management";
            btn_man_management.Size = new Size(193, 51);
            btn_man_management.TabIndex = 0;
            btn_man_management.Text = "예산 관리";
            btn_man_management.TextAlign = ContentAlignment.MiddleLeft;
            btn_man_management.UseVisualStyleBackColor = true;
            // 
            // pic_man_home
            // 
            pic_man_home.Image = (Image)resources.GetObject("pic_man_home.Image");
            pic_man_home.Location = new Point(4, 5);
            pic_man_home.Margin = new Padding(4);
            pic_man_home.Name = "pic_man_home";
            pic_man_home.Size = new Size(62, 49);
            pic_man_home.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_man_home.TabIndex = 1;
            pic_man_home.TabStop = false;
            // 
            // pnl_man_income
            // 
            pnl_man_income.BackColor = Color.FromArgb(224, 224, 224);
            pnl_man_income.Controls.Add(pic_man_income);
            pnl_man_income.Controls.Add(btn_man_income);
            pnl_man_income.Location = new Point(23, 131);
            pnl_man_income.Margin = new Padding(4);
            pnl_man_income.Name = "pnl_man_income";
            pnl_man_income.Size = new Size(271, 60);
            pnl_man_income.TabIndex = 17;
            pnl_man_income.Click += pnl_man_income_Click;
            pnl_man_income.Paint += pnl_man_income_Paint;
            // 
            // pic_man_income
            // 
            pic_man_income.Image = (Image)resources.GetObject("pic_man_income.Image");
            pic_man_income.Location = new Point(4, 5);
            pic_man_income.Margin = new Padding(4);
            pic_man_income.Name = "pic_man_income";
            pic_man_income.Size = new Size(62, 49);
            pic_man_income.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_man_income.TabIndex = 1;
            pic_man_income.TabStop = false;
            // 
            // btn_man_income
            // 
            btn_man_income.FlatStyle = FlatStyle.Flat;
            btn_man_income.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_man_income.Location = new Point(71, 5);
            btn_man_income.Margin = new Padding(4);
            btn_man_income.Name = "btn_man_income";
            btn_man_income.Size = new Size(193, 51);
            btn_man_income.TabIndex = 0;
            btn_man_income.Text = "수입 입력";
            btn_man_income.TextAlign = ContentAlignment.MiddleLeft;
            btn_man_income.UseVisualStyleBackColor = true;
            // 
            // pnl_man_expense
            // 
            pnl_man_expense.BackColor = Color.FromArgb(224, 224, 224);
            pnl_man_expense.Controls.Add(pic_man_expense);
            pnl_man_expense.Controls.Add(btn_man_expense);
            pnl_man_expense.Location = new Point(23, 199);
            pnl_man_expense.Margin = new Padding(4);
            pnl_man_expense.Name = "pnl_man_expense";
            pnl_man_expense.Size = new Size(271, 60);
            pnl_man_expense.TabIndex = 16;
            pnl_man_expense.Click += pnl_man_expense_Click;
            pnl_man_expense.Paint += pnl_man_expense_Paint;
            // 
            // pic_man_expense
            // 
            pic_man_expense.Image = (Image)resources.GetObject("pic_man_expense.Image");
            pic_man_expense.Location = new Point(4, 5);
            pic_man_expense.Margin = new Padding(4);
            pic_man_expense.Name = "pic_man_expense";
            pic_man_expense.Size = new Size(62, 49);
            pic_man_expense.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_man_expense.TabIndex = 1;
            pic_man_expense.TabStop = false;
            // 
            // btn_man_expense
            // 
            btn_man_expense.FlatStyle = FlatStyle.Flat;
            btn_man_expense.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_man_expense.Location = new Point(71, 5);
            btn_man_expense.Margin = new Padding(4);
            btn_man_expense.Name = "btn_man_expense";
            btn_man_expense.Size = new Size(193, 51);
            btn_man_expense.TabIndex = 0;
            btn_man_expense.Text = "지출 입력";
            btn_man_expense.TextAlign = ContentAlignment.MiddleLeft;
            btn_man_expense.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(tb_man_RemainMoney);
            panel6.Controls.Add(label5);
            panel6.Controls.Add(tb_man_TotalExpense);
            panel6.Controls.Add(label4);
            panel6.Controls.Add(tb_man_TotalIncome);
            panel6.Controls.Add(label3);
            panel6.Controls.Add(btn_man_AddMoney);
            panel6.Controls.Add(btn_man_SetMoney);
            panel6.Controls.Add(btn_man_ResetMoney);
            panel6.Controls.Add(tb_man_CurrentMoney);
            panel6.Controls.Add(label2);
            panel6.Controls.Add(label1);
            panel6.Location = new Point(301, 63);
            panel6.Name = "panel6";
            panel6.Size = new Size(500, 600);
            panel6.TabIndex = 19;
            // 
            // tb_man_RemainMoney
            // 
            tb_man_RemainMoney.BorderStyle = BorderStyle.None;
            tb_man_RemainMoney.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_man_RemainMoney.Location = new Point(184, 308);
            tb_man_RemainMoney.Name = "tb_man_RemainMoney";
            tb_man_RemainMoney.ReadOnly = true;
            tb_man_RemainMoney.Size = new Size(240, 27);
            tb_man_RemainMoney.TabIndex = 41;
            tb_man_RemainMoney.TextAlign = HorizontalAlignment.Right;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(49, 311);
            label5.Name = "label5";
            label5.Size = new Size(99, 28);
            label5.TabIndex = 40;
            label5.Text = "현재 잔액";
            // 
            // tb_man_TotalExpense
            // 
            tb_man_TotalExpense.BorderStyle = BorderStyle.None;
            tb_man_TotalExpense.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_man_TotalExpense.Location = new Point(184, 259);
            tb_man_TotalExpense.Name = "tb_man_TotalExpense";
            tb_man_TotalExpense.ReadOnly = true;
            tb_man_TotalExpense.Size = new Size(240, 27);
            tb_man_TotalExpense.TabIndex = 39;
            tb_man_TotalExpense.TextAlign = HorizontalAlignment.Right;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(59, 262);
            label4.Name = "label4";
            label4.Size = new Size(79, 28);
            label4.TabIndex = 38;
            label4.Text = "총 지출";
            // 
            // tb_man_TotalIncome
            // 
            tb_man_TotalIncome.BorderStyle = BorderStyle.None;
            tb_man_TotalIncome.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_man_TotalIncome.Location = new Point(184, 209);
            tb_man_TotalIncome.Name = "tb_man_TotalIncome";
            tb_man_TotalIncome.ReadOnly = true;
            tb_man_TotalIncome.Size = new Size(240, 27);
            tb_man_TotalIncome.TabIndex = 37;
            tb_man_TotalIncome.TextAlign = HorizontalAlignment.Right;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(59, 212);
            label3.Name = "label3";
            label3.Size = new Size(79, 28);
            label3.TabIndex = 36;
            label3.Text = "총 수입";
            // 
            // btn_man_AddMoney
            // 
            btn_man_AddMoney.BackColor = Color.Silver;
            btn_man_AddMoney.BackgroundImageLayout = ImageLayout.None;
            btn_man_AddMoney.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_man_AddMoney.ForeColor = SystemColors.ControlText;
            btn_man_AddMoney.Location = new Point(173, 81);
            btn_man_AddMoney.Margin = new Padding(4);
            btn_man_AddMoney.Name = "btn_man_AddMoney";
            btn_man_AddMoney.Size = new Size(151, 47);
            btn_man_AddMoney.TabIndex = 35;
            btn_man_AddMoney.Text = "보유금 추가";
            btn_man_AddMoney.UseVisualStyleBackColor = false;
            btn_man_AddMoney.Click += btn_man_AddMoney_Click;
            // 
            // btn_man_SetMoney
            // 
            btn_man_SetMoney.BackColor = Color.Silver;
            btn_man_SetMoney.BackgroundImageLayout = ImageLayout.None;
            btn_man_SetMoney.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_man_SetMoney.ForeColor = SystemColors.ControlText;
            btn_man_SetMoney.Location = new Point(18, 81);
            btn_man_SetMoney.Margin = new Padding(4);
            btn_man_SetMoney.Name = "btn_man_SetMoney";
            btn_man_SetMoney.Size = new Size(151, 47);
            btn_man_SetMoney.TabIndex = 34;
            btn_man_SetMoney.Text = "보유금 설정";
            btn_man_SetMoney.UseVisualStyleBackColor = false;
            btn_man_SetMoney.Click += btn_man_SetMoney_Click;
            // 
            // btn_man_ResetMoney
            // 
            btn_man_ResetMoney.BackColor = Color.Silver;
            btn_man_ResetMoney.BackgroundImageLayout = ImageLayout.None;
            btn_man_ResetMoney.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_man_ResetMoney.ForeColor = SystemColors.ControlText;
            btn_man_ResetMoney.Location = new Point(332, 81);
            btn_man_ResetMoney.Margin = new Padding(4);
            btn_man_ResetMoney.Name = "btn_man_ResetMoney";
            btn_man_ResetMoney.Size = new Size(151, 47);
            btn_man_ResetMoney.TabIndex = 33;
            btn_man_ResetMoney.Text = "보유금 초기화";
            btn_man_ResetMoney.UseVisualStyleBackColor = false;
            btn_man_ResetMoney.Click += btn_man_ResetMoney_Click;
            // 
            // tb_man_CurrentMoney
            // 
            tb_man_CurrentMoney.BorderStyle = BorderStyle.None;
            tb_man_CurrentMoney.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_man_CurrentMoney.Location = new Point(184, 162);
            tb_man_CurrentMoney.Name = "tb_man_CurrentMoney";
            tb_man_CurrentMoney.ReadOnly = true;
            tb_man_CurrentMoney.Size = new Size(240, 27);
            tb_man_CurrentMoney.TabIndex = 10;
            tb_man_CurrentMoney.TextAlign = HorizontalAlignment.Right;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(39, 165);
            label2.Name = "label2";
            label2.Size = new Size(119, 28);
            label2.TabIndex = 9;
            label2.Text = "현재 보유금";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("맑은 고딕", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(18, 16);
            label1.Name = "label1";
            label1.Size = new Size(141, 40);
            label1.TabIndex = 8;
            label1.Text = "예산 관리";
            // 
            // btn_man_search
            // 
            btn_man_search.FlatStyle = FlatStyle.Flat;
            btn_man_search.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_man_search.Location = new Point(71, 5);
            btn_man_search.Margin = new Padding(4);
            btn_man_search.Name = "btn_man_search";
            btn_man_search.Size = new Size(193, 51);
            btn_man_search.TabIndex = 0;
            btn_man_search.Text = "내역 조회";
            btn_man_search.TextAlign = ContentAlignment.MiddleLeft;
            btn_man_search.UseVisualStyleBackColor = true;
            // 
            // pnl_man_search
            // 
            pnl_man_search.BackColor = Color.FromArgb(224, 224, 224);
            pnl_man_search.Controls.Add(pic_man_search);
            pnl_man_search.Controls.Add(btn_man_search);
            pnl_man_search.Location = new Point(23, 267);
            pnl_man_search.Margin = new Padding(4);
            pnl_man_search.Name = "pnl_man_search";
            pnl_man_search.Size = new Size(271, 60);
            pnl_man_search.TabIndex = 15;
            pnl_man_search.Click += pnl_man_search_Click;
            pnl_man_search.Paint += pnl_man_search_Paint;
            // 
            // pic_man_search
            // 
            pic_man_search.Image = (Image)resources.GetObject("pic_man_search.Image");
            pic_man_search.Location = new Point(4, 5);
            pic_man_search.Margin = new Padding(4);
            pic_man_search.Name = "pic_man_search";
            pic_man_search.Size = new Size(62, 49);
            pic_man_search.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_man_search.TabIndex = 1;
            pic_man_search.TabStop = false;
            // 
            // pnl_man_home
            // 
            pnl_man_home.BackColor = Color.FromArgb(224, 224, 224);
            pnl_man_home.Controls.Add(pic_man_home);
            pnl_man_home.Controls.Add(btn_man_home);
            pnl_man_home.Location = new Point(23, 63);
            pnl_man_home.Margin = new Padding(4);
            pnl_man_home.Name = "pnl_man_home";
            pnl_man_home.Size = new Size(271, 60);
            pnl_man_home.TabIndex = 18;
            pnl_man_home.Click += pnl_man_home_Click;
            pnl_man_home.Paint += pnl_man_home_Paint;
            // 
            // btn_man_home
            // 
            btn_man_home.FlatStyle = FlatStyle.Flat;
            btn_man_home.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_man_home.Location = new Point(71, 5);
            btn_man_home.Margin = new Padding(4);
            btn_man_home.Name = "btn_man_home";
            btn_man_home.Size = new Size(193, 51);
            btn_man_home.TabIndex = 0;
            btn_man_home.Text = "홈";
            btn_man_home.TextAlign = ContentAlignment.MiddleLeft;
            btn_man_home.UseVisualStyleBackColor = true;
            // 
            // HomeForm_management
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(824, 726);
            Controls.Add(pnl_man_management);
            Controls.Add(pnl_man_income);
            Controls.Add(pnl_man_expense);
            Controls.Add(panel6);
            Controls.Add(pnl_man_search);
            Controls.Add(pnl_man_home);
            Name = "HomeForm_management";
            Text = "HomeForm_management";
            pnl_man_management.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_man_management).EndInit();
            ((System.ComponentModel.ISupportInitialize)pic_man_home).EndInit();
            pnl_man_income.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_man_income).EndInit();
            pnl_man_expense.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_man_expense).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            pnl_man_search.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_man_search).EndInit();
            pnl_man_home.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel pnl_man_management;
        private PictureBox pic_man_management;
        private Button btn_man_management;
        private PictureBox pic_man_home;
        private Panel pnl_man_income;
        private PictureBox pic_man_income;
        private Button btn_man_income;
        private Panel pnl_man_expense;
        private PictureBox pic_man_expense;
        private Button btn_man_expense;
        private Panel panel6;
        private TextBox tb_man_Date;
        private Label label2;
        private Label label1;
        private Button btn_man_search;
        private Panel pnl_man_search;
        private PictureBox pic_man_search;
        private Panel pnl_man_home;
        private Button btn_man_home;
        private Button btn_man_ResetMoney;
        private Button btn_man_AddMoney;
        private Button btn_man_SetMoney;
        private TextBox tb_man_CurrentMoney;
        private TextBox tb_man_RemainMoney;
        private Label label5;
        private TextBox tb_man_TotalExpense;
        private Label label4;
        private TextBox tb_man_TotalIncome;
        private Label label3;
    }
}