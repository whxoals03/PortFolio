﻿namespace C__MiniProject_JTM
{
    partial class HomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeForm));
            pnl_home = new Panel();
            pic_home_home = new PictureBox();
            btn_HomeForm_home = new Button();
            pnl_income = new Panel();
            pic_home_income = new PictureBox();
            btn_HomeForm_income = new Button();
            pnl_expense = new Panel();
            pic_home_expense = new PictureBox();
            btn_HomeForm_expense = new Button();
            pnl_search = new Panel();
            pic_home_search = new PictureBox();
            btn_HomeForm_search = new Button();
            pnl_Management = new Panel();
            pic_home_management = new PictureBox();
            btn_HomeForm_Management = new Button();
            pnl_main = new Panel();
            panel7 = new Panel();
            list_home_Category = new ListBox();
            label6 = new Label();
            panel6 = new Panel();
            DGV_home_search = new DataGridView();
            label7 = new Label();
            panel5 = new Panel();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            progressBar_bar = new ProgressBar();
            label5 = new Label();
            pnl_up_money = new Panel();
            tb_up_money = new TextBox();
            pictureBox8 = new PictureBox();
            label4 = new Label();
            pnl_up_expense = new Panel();
            tb_up_expense = new TextBox();
            pictureBox9 = new PictureBox();
            label3 = new Label();
            pnl_up_income = new Panel();
            tb_up_income = new TextBox();
            pictureBox7 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            pic_user = new PictureBox();
            toolTip1 = new ToolTip(components);
            btn_home_logout = new Button();
            pnl_home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_home_home).BeginInit();
            pnl_income.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_home_income).BeginInit();
            pnl_expense.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_home_expense).BeginInit();
            pnl_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_home_search).BeginInit();
            pnl_Management.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_home_management).BeginInit();
            pnl_main.SuspendLayout();
            panel7.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DGV_home_search).BeginInit();
            panel5.SuspendLayout();
            pnl_up_money.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            pnl_up_expense.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            pnl_up_income.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pic_user).BeginInit();
            SuspendLayout();
            // 
            // pnl_home
            // 
            pnl_home.BackColor = Color.FromArgb(224, 224, 224);
            pnl_home.Controls.Add(pic_home_home);
            pnl_home.Controls.Add(btn_HomeForm_home);
            pnl_home.Location = new Point(16, 110);
            pnl_home.Margin = new Padding(4);
            pnl_home.Name = "pnl_home";
            pnl_home.Size = new Size(271, 60);
            pnl_home.TabIndex = 1;
            pnl_home.Click += pnl_home_Click;
            pnl_home.Paint += pnl_home_Paint;
            // 
            // pic_home_home
            // 
            pic_home_home.Image = (Image)resources.GetObject("pic_home_home.Image");
            pic_home_home.Location = new Point(4, 5);
            pic_home_home.Margin = new Padding(4);
            pic_home_home.Name = "pic_home_home";
            pic_home_home.Size = new Size(62, 49);
            pic_home_home.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_home_home.TabIndex = 1;
            pic_home_home.TabStop = false;
            // 
            // btn_HomeForm_home
            // 
            btn_HomeForm_home.FlatStyle = FlatStyle.Flat;
            btn_HomeForm_home.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_HomeForm_home.Location = new Point(71, 5);
            btn_HomeForm_home.Margin = new Padding(4);
            btn_HomeForm_home.Name = "btn_HomeForm_home";
            btn_HomeForm_home.Size = new Size(193, 51);
            btn_HomeForm_home.TabIndex = 0;
            btn_HomeForm_home.Text = "홈";
            btn_HomeForm_home.TextAlign = ContentAlignment.MiddleLeft;
            btn_HomeForm_home.UseVisualStyleBackColor = true;
            // 
            // pnl_income
            // 
            pnl_income.BackColor = Color.FromArgb(224, 224, 224);
            pnl_income.Controls.Add(pic_home_income);
            pnl_income.Controls.Add(btn_HomeForm_income);
            pnl_income.Location = new Point(16, 178);
            pnl_income.Margin = new Padding(4);
            pnl_income.Name = "pnl_income";
            pnl_income.Size = new Size(271, 60);
            pnl_income.TabIndex = 1;
            pnl_income.Click += pnl_income_Click;
            pnl_income.Paint += pnl_income_Paint;
            // 
            // pic_home_income
            // 
            pic_home_income.Image = (Image)resources.GetObject("pic_home_income.Image");
            pic_home_income.Location = new Point(4, 5);
            pic_home_income.Margin = new Padding(4);
            pic_home_income.Name = "pic_home_income";
            pic_home_income.Size = new Size(62, 49);
            pic_home_income.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_home_income.TabIndex = 1;
            pic_home_income.TabStop = false;
            // 
            // btn_HomeForm_income
            // 
            btn_HomeForm_income.FlatStyle = FlatStyle.Flat;
            btn_HomeForm_income.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_HomeForm_income.Location = new Point(71, 5);
            btn_HomeForm_income.Margin = new Padding(4);
            btn_HomeForm_income.Name = "btn_HomeForm_income";
            btn_HomeForm_income.Size = new Size(193, 51);
            btn_HomeForm_income.TabIndex = 0;
            btn_HomeForm_income.Text = "수입 입력";
            btn_HomeForm_income.TextAlign = ContentAlignment.MiddleLeft;
            btn_HomeForm_income.UseVisualStyleBackColor = true;
            // 
            // pnl_expense
            // 
            pnl_expense.BackColor = Color.FromArgb(224, 224, 224);
            pnl_expense.Controls.Add(pic_home_expense);
            pnl_expense.Controls.Add(btn_HomeForm_expense);
            pnl_expense.Location = new Point(16, 246);
            pnl_expense.Margin = new Padding(4);
            pnl_expense.Name = "pnl_expense";
            pnl_expense.Size = new Size(271, 60);
            pnl_expense.TabIndex = 1;
            pnl_expense.Click += pnl_expense_Click;
            pnl_expense.Paint += pnl_expense_Paint;
            // 
            // pic_home_expense
            // 
            pic_home_expense.Image = (Image)resources.GetObject("pic_home_expense.Image");
            pic_home_expense.Location = new Point(4, 5);
            pic_home_expense.Margin = new Padding(4);
            pic_home_expense.Name = "pic_home_expense";
            pic_home_expense.Size = new Size(62, 49);
            pic_home_expense.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_home_expense.TabIndex = 1;
            pic_home_expense.TabStop = false;
            // 
            // btn_HomeForm_expense
            // 
            btn_HomeForm_expense.FlatStyle = FlatStyle.Flat;
            btn_HomeForm_expense.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_HomeForm_expense.Location = new Point(71, 5);
            btn_HomeForm_expense.Margin = new Padding(4);
            btn_HomeForm_expense.Name = "btn_HomeForm_expense";
            btn_HomeForm_expense.Size = new Size(193, 51);
            btn_HomeForm_expense.TabIndex = 0;
            btn_HomeForm_expense.Text = "지출 입력";
            btn_HomeForm_expense.TextAlign = ContentAlignment.MiddleLeft;
            btn_HomeForm_expense.UseVisualStyleBackColor = true;
            // 
            // pnl_search
            // 
            pnl_search.BackColor = Color.FromArgb(224, 224, 224);
            pnl_search.Controls.Add(pic_home_search);
            pnl_search.Controls.Add(btn_HomeForm_search);
            pnl_search.Location = new Point(16, 314);
            pnl_search.Margin = new Padding(4);
            pnl_search.Name = "pnl_search";
            pnl_search.Size = new Size(271, 60);
            pnl_search.TabIndex = 1;
            pnl_search.Click += pnl_search_Click;
            pnl_search.Paint += pnl_search_Paint;
            // 
            // pic_home_search
            // 
            pic_home_search.Image = (Image)resources.GetObject("pic_home_search.Image");
            pic_home_search.Location = new Point(4, 5);
            pic_home_search.Margin = new Padding(4);
            pic_home_search.Name = "pic_home_search";
            pic_home_search.Size = new Size(62, 49);
            pic_home_search.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_home_search.TabIndex = 1;
            pic_home_search.TabStop = false;
            // 
            // btn_HomeForm_search
            // 
            btn_HomeForm_search.FlatStyle = FlatStyle.Flat;
            btn_HomeForm_search.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_HomeForm_search.Location = new Point(71, 5);
            btn_HomeForm_search.Margin = new Padding(4);
            btn_HomeForm_search.Name = "btn_HomeForm_search";
            btn_HomeForm_search.Size = new Size(193, 51);
            btn_HomeForm_search.TabIndex = 0;
            btn_HomeForm_search.Text = "내역 조회";
            btn_HomeForm_search.TextAlign = ContentAlignment.MiddleLeft;
            btn_HomeForm_search.UseVisualStyleBackColor = true;
            btn_HomeForm_search.Click += button4_Click;
            // 
            // pnl_Management
            // 
            pnl_Management.BackColor = Color.FromArgb(224, 224, 224);
            pnl_Management.Controls.Add(pic_home_management);
            pnl_Management.Controls.Add(btn_HomeForm_Management);
            pnl_Management.Location = new Point(16, 382);
            pnl_Management.Margin = new Padding(4);
            pnl_Management.Name = "pnl_Management";
            pnl_Management.Size = new Size(271, 60);
            pnl_Management.TabIndex = 1;
            pnl_Management.Click += pnl_Management_Click;
            pnl_Management.Paint += pnl_Management_Paint;
            // 
            // pic_home_management
            // 
            pic_home_management.Image = (Image)resources.GetObject("pic_home_management.Image");
            pic_home_management.Location = new Point(4, 5);
            pic_home_management.Margin = new Padding(4);
            pic_home_management.Name = "pic_home_management";
            pic_home_management.Size = new Size(62, 49);
            pic_home_management.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_home_management.TabIndex = 1;
            pic_home_management.TabStop = false;
            // 
            // btn_HomeForm_Management
            // 
            btn_HomeForm_Management.FlatStyle = FlatStyle.Flat;
            btn_HomeForm_Management.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_HomeForm_Management.Location = new Point(71, 5);
            btn_HomeForm_Management.Margin = new Padding(4);
            btn_HomeForm_Management.Name = "btn_HomeForm_Management";
            btn_HomeForm_Management.Size = new Size(193, 51);
            btn_HomeForm_Management.TabIndex = 0;
            btn_HomeForm_Management.Text = "예산 관리";
            btn_HomeForm_Management.TextAlign = ContentAlignment.MiddleLeft;
            btn_HomeForm_Management.UseVisualStyleBackColor = true;
            // 
            // pnl_main
            // 
            pnl_main.BackColor = Color.White;
            pnl_main.Controls.Add(panel7);
            pnl_main.Controls.Add(panel6);
            pnl_main.Controls.Add(panel5);
            pnl_main.Controls.Add(pnl_up_money);
            pnl_main.Controls.Add(pnl_up_expense);
            pnl_main.Controls.Add(pnl_up_income);
            pnl_main.Controls.Add(label1);
            pnl_main.Location = new Point(293, 105);
            pnl_main.Name = "pnl_main";
            pnl_main.Size = new Size(1230, 623);
            pnl_main.TabIndex = 2;
            pnl_main.Paint += pnl_main_Paint;
            // 
            // panel7
            // 
            panel7.BorderStyle = BorderStyle.FixedSingle;
            panel7.Controls.Add(list_home_Category);
            panel7.Controls.Add(label6);
            panel7.ForeColor = SystemColors.ControlText;
            panel7.Location = new Point(818, 189);
            panel7.Name = "panel7";
            panel7.Size = new Size(382, 405);
            panel7.TabIndex = 4;
            // 
            // list_home_Category
            // 
            list_home_Category.BorderStyle = BorderStyle.None;
            list_home_Category.Font = new Font("맑은 고딕", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            list_home_Category.FormattingEnabled = true;
            list_home_Category.Location = new Point(15, 46);
            list_home_Category.Name = "list_home_Category";
            list_home_Category.Size = new Size(347, 325);
            list_home_Category.TabIndex = 5;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(1, 1);
            label6.Name = "label6";
            label6.Size = new Size(186, 28);
            label6.TabIndex = 4;
            label6.Text = "지출 카테고리 분포";
            // 
            // panel6
            // 
            panel6.BorderStyle = BorderStyle.FixedSingle;
            panel6.Controls.Add(DGV_home_search);
            panel6.Controls.Add(label7);
            panel6.ForeColor = SystemColors.ControlText;
            panel6.Location = new Point(22, 189);
            panel6.Name = "panel6";
            panel6.Size = new Size(776, 405);
            panel6.TabIndex = 3;
            panel6.Paint += Panel6_Paint;
            // 
            // DGV_home_search
            // 
            DGV_home_search.AllowUserToOrderColumns = true;
            DGV_home_search.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV_home_search.Location = new Point(14, 46);
            DGV_home_search.Name = "DGV_home_search";
            DGV_home_search.RowHeadersWidth = 51;
            DGV_home_search.Size = new Size(740, 344);
            DGV_home_search.TabIndex = 6;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(1, 1);
            label7.Name = "label7";
            label7.Size = new Size(146, 28);
            label7.TabIndex = 5;
            label7.Text = "최근 거래 내역";
            // 
            // panel5
            // 
            panel5.BorderStyle = BorderStyle.FixedSingle;
            panel5.Controls.Add(label12);
            panel5.Controls.Add(label11);
            panel5.Controls.Add(label10);
            panel5.Controls.Add(label9);
            panel5.Controls.Add(label8);
            panel5.Controls.Add(progressBar_bar);
            panel5.Controls.Add(label5);
            panel5.ForeColor = SystemColors.ControlText;
            panel5.Location = new Point(931, 51);
            panel5.Name = "panel5";
            panel5.Size = new Size(269, 118);
            panel5.TabIndex = 2;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(169, 85);
            label12.Name = "label12";
            label12.Size = new Size(38, 20);
            label12.TabIndex = 12;
            label12.Text = "75%";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(63, 85);
            label11.Name = "label11";
            label11.Size = new Size(38, 20);
            label11.TabIndex = 11;
            label11.Text = "25%";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(116, 85);
            label10.Name = "label10";
            label10.Size = new Size(38, 20);
            label10.TabIndex = 10;
            label10.Text = "50%";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(222, 85);
            label9.Name = "label9";
            label9.Size = new Size(46, 20);
            label9.TabIndex = 9;
            label9.Text = "100%";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(10, 85);
            label8.Name = "label8";
            label8.Size = new Size(30, 20);
            label8.TabIndex = 8;
            label8.Text = "0%";
            // 
            // progressBar_bar
            // 
            progressBar_bar.Location = new Point(20, 49);
            progressBar_bar.Name = "progressBar_bar";
            progressBar_bar.Size = new Size(229, 33);
            progressBar_bar.TabIndex = 7;
            progressBar_bar.Click += progressBar_bar_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(3, 1);
            label5.Name = "label5";
            label5.Size = new Size(119, 28);
            label5.TabIndex = 6;
            label5.Text = "예산 사용률";
            // 
            // pnl_up_money
            // 
            pnl_up_money.BorderStyle = BorderStyle.FixedSingle;
            pnl_up_money.Controls.Add(tb_up_money);
            pnl_up_money.Controls.Add(pictureBox8);
            pnl_up_money.Controls.Add(label4);
            pnl_up_money.ForeColor = SystemColors.ControlText;
            pnl_up_money.Location = new Point(628, 51);
            pnl_up_money.Name = "pnl_up_money";
            pnl_up_money.Size = new Size(269, 118);
            pnl_up_money.TabIndex = 2;
            // 
            // tb_up_money
            // 
            tb_up_money.BorderStyle = BorderStyle.None;
            tb_up_money.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_up_money.Location = new Point(15, 56);
            tb_up_money.Name = "tb_up_money";
            tb_up_money.ReadOnly = true;
            tb_up_money.Size = new Size(240, 27);
            tb_up_money.TabIndex = 12;
            tb_up_money.TextAlign = HorizontalAlignment.Center;
            // 
            // pictureBox8
            // 
            pictureBox8.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(169, 0);
            pictureBox8.Margin = new Padding(4);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(62, 49);
            pictureBox8.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox8.TabIndex = 5;
            pictureBox8.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(1, 2);
            label4.Name = "label4";
            label4.Size = new Size(119, 28);
            label4.TabIndex = 5;
            label4.Text = "현재 보유금";
            // 
            // pnl_up_expense
            // 
            pnl_up_expense.BorderStyle = BorderStyle.FixedSingle;
            pnl_up_expense.Controls.Add(tb_up_expense);
            pnl_up_expense.Controls.Add(pictureBox9);
            pnl_up_expense.Controls.Add(label3);
            pnl_up_expense.ForeColor = SystemColors.ControlText;
            pnl_up_expense.Location = new Point(325, 51);
            pnl_up_expense.Name = "pnl_up_expense";
            pnl_up_expense.Size = new Size(269, 118);
            pnl_up_expense.TabIndex = 2;
            // 
            // tb_up_expense
            // 
            tb_up_expense.BorderStyle = BorderStyle.None;
            tb_up_expense.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_up_expense.Location = new Point(14, 56);
            tb_up_expense.Name = "tb_up_expense";
            tb_up_expense.ReadOnly = true;
            tb_up_expense.Size = new Size(240, 27);
            tb_up_expense.TabIndex = 12;
            tb_up_expense.TextAlign = HorizontalAlignment.Center;
            // 
            // pictureBox9
            // 
            pictureBox9.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(178, 0);
            pictureBox9.Margin = new Padding(4);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(62, 49);
            pictureBox9.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox9.TabIndex = 6;
            pictureBox9.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(1, 1);
            label3.Name = "label3";
            label3.Size = new Size(153, 28);
            label3.TabIndex = 4;
            label3.Text = "이번 달 총 지출";
            // 
            // pnl_up_income
            // 
            pnl_up_income.BorderStyle = BorderStyle.FixedSingle;
            pnl_up_income.Controls.Add(tb_up_income);
            pnl_up_income.Controls.Add(pictureBox7);
            pnl_up_income.Controls.Add(label2);
            pnl_up_income.ForeColor = SystemColors.ControlText;
            pnl_up_income.Location = new Point(22, 51);
            pnl_up_income.Name = "pnl_up_income";
            pnl_up_income.Size = new Size(269, 118);
            pnl_up_income.TabIndex = 1;
            // 
            // tb_up_income
            // 
            tb_up_income.BorderStyle = BorderStyle.None;
            tb_up_income.Font = new Font("맑은 고딕", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tb_up_income.Location = new Point(14, 56);
            tb_up_income.Name = "tb_up_income";
            tb_up_income.ReadOnly = true;
            tb_up_income.Size = new Size(240, 27);
            tb_up_income.TabIndex = 11;
            tb_up_income.TextAlign = HorizontalAlignment.Center;
            // 
            // pictureBox7
            // 
            pictureBox7.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(179, 0);
            pictureBox7.Margin = new Padding(4);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(62, 49);
            pictureBox7.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(3, 2);
            label2.Name = "label2";
            label2.Size = new Size(160, 28);
            label2.TabIndex = 3;
            label2.Text = "이번 달 총 수입 ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(13, 10);
            label1.Name = "label1";
            label1.Size = new Size(45, 38);
            label1.TabIndex = 0;
            label1.Text = "홈";
            label1.Click += label1_Click;
            // 
            // pic_user
            // 
            pic_user.Image = (Image)resources.GetObject("pic_user.Image");
            pic_user.Location = new Point(1421, 13);
            pic_user.Margin = new Padding(4);
            pic_user.Name = "pic_user";
            pic_user.Size = new Size(72, 72);
            pic_user.SizeMode = PictureBoxSizeMode.StretchImage;
            pic_user.TabIndex = 2;
            pic_user.TabStop = false;
            toolTip1.SetToolTip(pic_user, "사용자 : ");
            pic_user.Click += pic_user_Click;
            // 
            // toolTip1
            // 
            toolTip1.Popup += toolTip1_Popup;
            // 
            // btn_home_logout
            // 
            btn_home_logout.BackColor = Color.Silver;
            btn_home_logout.BackgroundImageLayout = ImageLayout.None;
            btn_home_logout.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            btn_home_logout.ForeColor = SystemColors.ControlText;
            btn_home_logout.Location = new Point(1315, 56);
            btn_home_logout.Margin = new Padding(4);
            btn_home_logout.Name = "btn_home_logout";
            btn_home_logout.Size = new Size(88, 29);
            btn_home_logout.TabIndex = 33;
            btn_home_logout.Text = "로그아웃";
            btn_home_logout.UseVisualStyleBackColor = false;
            btn_home_logout.Click += btn_home_logout_Click;
            // 
            // HomeForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(1524, 726);
            Controls.Add(btn_home_logout);
            Controls.Add(pic_user);
            Controls.Add(pnl_main);
            Controls.Add(pnl_Management);
            Controls.Add(pnl_search);
            Controls.Add(pnl_expense);
            Controls.Add(pnl_income);
            Controls.Add(pnl_home);
            Margin = new Padding(4);
            Name = "HomeForm";
            Text = "HomeForm";
            Load += HomeForm_Load;
            pnl_home.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_home_home).EndInit();
            pnl_income.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_home_income).EndInit();
            pnl_expense.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_home_expense).EndInit();
            pnl_search.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_home_search).EndInit();
            pnl_Management.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_home_management).EndInit();
            pnl_main.ResumeLayout(false);
            pnl_main.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DGV_home_search).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            pnl_up_money.ResumeLayout(false);
            pnl_up_money.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            pnl_up_expense.ResumeLayout(false);
            pnl_up_expense.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            pnl_up_income.ResumeLayout(false);
            pnl_up_income.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pic_user).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel pnl_home;
        private Button btn_HomeForm_home;
        private Panel pnl_income;
        private PictureBox pic_home_income;
        private Button btn_HomeForm_income;
        private Panel pnl_expense;
        private PictureBox pic_home_expense;
        private Button btn_HomeForm_expense;
        private Panel pnl_search;
        private PictureBox pic_home_search;
        private Button btn_HomeForm_search;
        private Panel pnl_Management;
        private PictureBox pic_home_management;
        private Button btn_HomeForm_Management;
        private Panel pnl_main;
        private Label label1;
        private Panel panel5;
        private Label label5;
        private Panel pnl_up_money;
        private Label label4;
        private Panel pnl_up_expense;
        private Label label3;
        private Panel pnl_up_income;
        private Label label2;
        private PictureBox pic_user;
        private Panel panel7;
        private Label label6;
        private Panel panel6;
        private Label label7;
        private DataGridView DGV_home_search;
        private ProgressBar progressBar_bar;
        private Label label8;
        private PictureBox pic_home_home;
        private PictureBox pictureBox7;
        private Label label9;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private ToolTip toolTip1;
        private TextBox tb_up_money;
        private TextBox tb_up_expense;
        private TextBox tb_up_income;
        private ListBox list_home_Category;
        private Label label12;
        private Label label11;
        private Label label10;
        private Button btn_home_logout;
    }
}