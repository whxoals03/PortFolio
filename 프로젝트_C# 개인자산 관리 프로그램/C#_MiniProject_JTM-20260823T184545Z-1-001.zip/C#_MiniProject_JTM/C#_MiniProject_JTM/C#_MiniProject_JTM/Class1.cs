﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C__MiniProject_JTM
{
    internal class Class1
    {
    }
}
