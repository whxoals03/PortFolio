﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;

namespace C__MiniProject_JTM
{
    public partial class HomeForm_income : Form
    {
        public HomeForm_income()
        {
            InitializeComponent();

            tb_in_Date.TabIndex = 0;
            tb_in_Money.TabIndex = 1;
            tb_in_Categori.TabIndex = 2;
            tb_in_Memo.TabIndex = 3;
            btn_in_Registration.TabIndex = 4;

            pnl_in_home.Click += pnl_in_home_Click;
            pnl_in_income.Click += pnl_in_income_Click;
            pnl_in_expense.Click += pnl_in_expense_Click;
            pnl_in_search.Click += pnl_in_search_Click;
            pnl_in_management.Click += pnl_in_management_Click;

            btn_income_home.Click += pnl_in_home_Click;
            btn_income_income.Click += pnl_in_income_Click;
            btn_income_expense.Click += pnl_in_expense_Click;
            btn_income_search.Click += pnl_in_search_Click;
            btn_income_management.Click += pnl_in_management_Click;

            pic_income_home.Click += pnl_in_home_Click;
            pic_income_income.Click += pnl_in_income_Click;
            pic_income_expense.Click += pnl_in_expense_Click;
            pic_income_search.Click += pnl_in_search_Click;
            pic_income_management.Click += pnl_in_management_Click;

            tb_in_Date.Enter += tb_in_Date_Enter;
            tb_in_Date.Leave += tb_in_Date_Leave;

            tb_in_Money.Enter += tb_in_Money_Enter;
            tb_in_Money.Leave += tb_in_Money_Leave;

            tb_in_Categori.Enter += tb_in_Categori_Enter;
            tb_in_Categori.Leave += tb_in_Categori_Leave;

            tb_in_Memo.Enter += tb_in_Memo_Enter;
            tb_in_Memo.Leave += tb_in_Memo_Leave;
        }

        private void pnl_in_home_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_in_income_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_in_expense_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_in_search_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_in_management_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void pnl_in_home_Click(object sender, EventArgs e)
        {
            HomeForm form = new HomeForm("사용자");

            form.Show();

            this.Hide();
        }

        private void pnl_in_income_Click(object sender, EventArgs e)
        {
            HomeForm_income form = new HomeForm_income();

            form.Show();

            this.Hide();
        }

        private void pnl_in_expense_Click(object sender, EventArgs e)
        {
            HomeForm_expense form = new HomeForm_expense();

            form.Show();

            this.Hide();
        }

        private void pnl_in_search_Click(object sender, EventArgs e)
        {
            HomeForm_search form = new HomeForm_search();

            form.Show();

            this.Hide();
        }

        private void pnl_in_management_Click(object sender, EventArgs e)
        {
            HomeForm_management form = new HomeForm_management();

            form.Show();

            this.Hide();
        }

        private void btn_in_Registration_Click(object sender, EventArgs e)
        {
            DB.Init();

            string date = tb_in_Date.Text;
            string amountText = tb_in_Money.Text;
            string category = tb_in_Categori.Text;
            string memo = tb_in_Memo.Text;

            if (date == "'년월일' 을 숫자 6개 입력" || amountText == "금액만 입력 \"10,000\"" || category == "\"식비, 교통비, 생활용품\"")
            {
                MessageBox.Show("날짜, 금액, 카테고리를 입력하세요.");
                return;
            }

            if (date == "" || amountText == "" || category == "")
            {
                MessageBox.Show("날짜, 금액, 카테고리는 반드시 입력해야 합니다.");
                return;
            }

            amountText = amountText.Replace(",", "");

            int amount;

            if (int.TryParse(amountText, out amount) == false)
            {
                MessageBox.Show("금액은 숫자만 입력해야 합니다.");
                return;
            }

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = @"
                INSERT INTO Income(Date, Amount, Category, Memo)
                VALUES(@Date, @Amount, @Category, @Memo);";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Date", date);
                    cmd.Parameters.AddWithValue("@Amount", amount);
                    cmd.Parameters.AddWithValue("@Category", category);
                    cmd.Parameters.AddWithValue("@Memo", memo);

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("수입이 등록되었습니다.");

            tb_in_Date.Clear();
            tb_in_Money.Clear();
            tb_in_Categori.Clear();
            tb_in_Memo.Clear();
        }

        private void tb_in_Date_Enter(object sender, EventArgs e)
        {
            if (tb_in_Date.Text == "'년월일' 을 숫자 6개 입력")
            {
                tb_in_Date.Text = "";
                tb_in_Date.ForeColor = Color.Black;
            }
        }

        private void tb_in_Date_Leave(object sender, EventArgs e)
        {
            if (tb_in_Date.Text == "")
            {
                tb_in_Date.Text = "'년월일' 을 숫자 6개 입력";
                tb_in_Date.ForeColor = Color.Gray;
            }
        }

        private void tb_in_Money_Enter(object sender, EventArgs e)
        {
            if (tb_in_Money.Text == "금액만 입력 \"10,000\"")
            {
                tb_in_Money.Text = "";
                tb_in_Money.ForeColor = Color.Black;
            }
        }

        private void tb_in_Money_Leave(object sender, EventArgs e)
        {
            if (tb_in_Money.Text == "")
            {
                tb_in_Money.Text = "금액만 입력 \"10,000\"";
                tb_in_Money.ForeColor = Color.Gray;
            }
        }

        private void tb_in_Categori_Enter(object sender, EventArgs e)
        {
            if (tb_in_Categori.Text == "용돈, 월급 등")
            {
                tb_in_Categori.Text = "";
                tb_in_Categori.ForeColor = Color.Black;
            }
        }

        private void tb_in_Categori_Leave(object sender, EventArgs e)
        {
            if (tb_in_Categori.Text == "")
            {
                tb_in_Categori.Text = "용돈, 월급 등";
                tb_in_Categori.ForeColor = Color.Gray;
            }
        }

        private void tb_in_Memo_Enter(object sender, EventArgs e)
        {
            if (tb_in_Memo.Text == "메모 입력")
            {
                tb_in_Memo.Text = "";
                tb_in_Memo.ForeColor = Color.Black;
            }
        }

        private void tb_in_Memo_Leave(object sender, EventArgs e)
        {
            if (tb_in_Memo.Text == "")
            {
                tb_in_Memo.Text = "메모 입력";
                tb_in_Memo.ForeColor = Color.Gray;
            }
        }
    }
}
