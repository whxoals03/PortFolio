﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;

namespace C__MiniProject_JTM
{
    public partial class membershipForm : Form
    {
        private bool isChanging = false;
        public membershipForm()
        {
            InitializeComponent();

            tb_id.TabIndex = 0;
            tb_pw.TabIndex = 1;
            tb_pwcheck.TabIndex = 2;
            tb_name.TabIndex = 3;
            tb_phone.TabIndex = 4;
            tb_email.TabIndex = 5;
            tb_birth.TabIndex = 6;

            tb_id.ForeColor = Color.Gray;
            tb_pw.ForeColor = Color.Gray;
            tb_pwcheck.ForeColor = Color.Gray;
            tb_name.ForeColor = Color.Gray;
            tb_phone.ForeColor = Color.Gray;
            tb_email.ForeColor = Color.Gray;
            tb_birth.ForeColor = Color.Gray;
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (tb_id.Text == "아이디 입력 (6 ~ 20자)" || tb_id.Text.Length < 6 || tb_id.Text.Length > 20)
            {
                MessageBox.Show("아이디는 6~20자로 입력해야 합니다.");
                return;
            }

            if (tb_pw.Text == "비밀번호 입력 (문자, 숫자, 특수문자 포함 8 ~ 20자 )" || tb_pw.Text.Length < 8 || tb_pw.Text.Length > 20)
            {
                MessageBox.Show("비밀번호는 8~20자로 입력해야 합니다.");
                return;
            }

            if (tb_pwcheck.Text == "비밀번호 확인 입력 ( 문자, 숫자, 특수문자 포함 8 ~ 20자 )")
            {
                MessageBox.Show("비밀번호 확인을 입력해주세요.");
                return;
            }

            if (tb_pw.Text != tb_pwcheck.Text)
            {
                MessageBox.Show("비밀번호가 일치하지 않습니다.");
                return;
            }

            if (tb_name.Text == "이름을 입력해주세요" || string.IsNullOrWhiteSpace(tb_name.Text))
            {
                MessageBox.Show("이름을 입력해주세요.");
                return;
            }

            if (tb_phone.Text == "휴대폰 번호 입력 ( '-' 제외 11자리 입력 )" || tb_phone.Text.Length != 11)
            {
                MessageBox.Show("전화번호는 '-' 없이 11자리로 입력해야 합니다.");
                return;
            }

            if (!long.TryParse(tb_phone.Text, out _))
            {
                MessageBox.Show("전화번호는 숫자만 입력 가능합니다.");
                return;
            }

            if (tb_email.Text == "이메일을 입력해주세요" || !tb_email.Text.Contains("@") || !tb_email.Text.Contains("."))
            {
                MessageBox.Show("올바른 이메일 형식이 아닙니다.");
                return;
            }

            if (tb_birth.Text == "8자리를 입력해주세요" || tb_birth.Text.Length != 8)
            {
                MessageBox.Show("생년월일은 8자리로 입력해야 합니다.");
                return;
            }

            if (!long.TryParse(tb_birth.Text, out _))
            {
                MessageBox.Show("생년월일은 숫자만 입력 가능합니다.");
                return;
            }

            if (!cb_age.Checked)
            {
                MessageBox.Show("만 14세 이상 확인이 필요합니다.");
                return;
            }

            if (!cb_privacy.Checked)
            {
                MessageBox.Show("개인정보 취급 방침 동의가 필요합니다.");
                return;
            }

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = @"
                INSERT INTO Users
                (LoginId, Password, Name, Phone, Email, Birth)
                VALUES
                (@LoginId, @Password, @Name, @Phone, @Email, @Birth)";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@LoginId", tb_id.Text);
                    cmd.Parameters.AddWithValue("@Password", tb_pw.Text);
                    cmd.Parameters.AddWithValue("@Name", tb_name.Text);
                    cmd.Parameters.AddWithValue("@Phone", tb_phone.Text);
                    cmd.Parameters.AddWithValue("@Email", tb_email.Text);
                    cmd.Parameters.AddWithValue("@Birth", tb_birth.Text);

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("회원가입 완료");

            LoginForm login = new LoginForm();
            login.Show();

            this.Hide();
        }

        private void tb_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_id_MouseEnter(object sender, EventArgs e)
        {
            if (tb_id.Text == "아이디 입력 (6 ~ 20자)")
            {
                tb_id.Text = "";
                tb_id.ForeColor = Color.Black;
            }
        }

        private void tb_id_MouseLeave(object sender, EventArgs e)
        {
            if (tb_id.Text == "")
            {
                tb_id.Text = "아이디 입력 (6 ~ 20자)";
                tb_id.ForeColor = Color.Gray;
            }
        }

        private void tb_pw_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_pw_MouseEnter(object sender, EventArgs e)
        {
            if (tb_pw.Text == "비밀번호 입력 (문자, 숫자, 특수문자 포함 8 ~ 20자 )")
            {
                tb_pw.Text = "";
                tb_pw.ForeColor = Color.Black;
            }
        }

        private void tb_pw_MouseLeave(object sender, EventArgs e)
        {
            if (tb_pw.Text == "")
            {
                tb_pw.Text = "비밀번호 입력 (문자, 숫자, 특수문자 포함 8 ~ 20자 )";
                tb_pw.ForeColor = Color.Gray;
            }
        }

        private void tb_pwcheck_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_pwcheck_MouseEnter(object sender, EventArgs e)
        {
            if (tb_pwcheck.Text == "비밀번호 확인 입력 ( 문자, 숫자, 특수문자 포함 8 ~ 20자 )")
            {
                tb_pwcheck.Text = "";
                tb_pwcheck.ForeColor = Color.Black;
            }
        }

        private void tb_pwcheck_MouseLeave(object sender, EventArgs e)
        {
            if (tb_pwcheck.Text == "")
            {
                tb_pwcheck.Text = "비밀번호 확인 입력 ( 문자, 숫자, 특수문자 포함 8 ~ 20자 )";
                tb_pwcheck.ForeColor = Color.Gray;
            }
        }

        private void tb_name_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_name_MouseEnter(object sender, EventArgs e)
        {
            if (tb_name.Text == "이름을 입력해주세요")
            {
                tb_name.Text = "";
                tb_name.ForeColor = Color.Black;
            }
        }

        private void tb_name_MouseLeave(object sender, EventArgs e)
        {
            if (tb_name.Text == "")
            {
                tb_name.Text = "이름을 입력해주세요";
                tb_name.ForeColor = Color.Gray;
            }
        }

        private void tb_phone_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb_phone_MouseEnter(object sender, EventArgs e)
        {
            if (tb_phone.Text == "휴대폰 번호 입력 ( '-' 제외 11자리 입력 )")
            {
                tb_phone.Text = "";
                tb_phone.ForeColor = Color.Black;
            }
        }

        private void tb_phone_MouseLeave(object sender, EventArgs e)
        {
            if (tb_phone.Text == "")
            {
                tb_phone.Text = "휴대폰 번호 입력 ( '-' 제외 11자리 입력 )";
                tb_phone.ForeColor = Color.Gray;
            }
        }

        private void tb_email_MouseEnter(object sender, EventArgs e)
        {
            if (tb_email.Text == "이메일을 입력해주세요")
            {
                tb_email.Text = "";
                tb_email.ForeColor = Color.Black;
            }
        }

        private void tb_email_MouseLeave(object sender, EventArgs e)
        {
            if (tb_email.Text == "")
            {
                tb_email.Text = "이메일을 입력해주세요";
                tb_email.ForeColor = Color.Gray;
            }
        }

        private void tb_birth_MouseEnter(object sender, EventArgs e)
        {
            if (tb_birth.Text == "8자리를 입력해주세요")
            {
                tb_birth.Text = "";
                tb_birth.ForeColor = Color.Black;
            }
        }

        private void tb_birth_MouseLeave(object sender, EventArgs e)
        {
            if (tb_birth.Text == "")
            {
                tb_birth.Text = "8자리를 입력해주세요";
                tb_birth.ForeColor = Color.Gray;
            }
        }

        private void cb_allAgree_CheckedChanged(object sender, EventArgs e)
        {
            if (isChanging == true)
            {
                return;
            }

            isChanging = true;

            cb_age.Checked = cb_allAgree.Checked;
            cb_privacy.Checked = cb_allAgree.Checked;

            isChanging = false;
        }

        private void cb_age_CheckedChanged(object sender, EventArgs e)
        {
            if (isChanging == true)
            {
                return;
            }

            isChanging = true;

            cb_allAgree.Checked = cb_age.Checked && cb_privacy.Checked;

            isChanging = false;
        }

        private void cb_privacy_CheckedChanged(object sender, EventArgs e)
        {
            if (isChanging == true)
            {
                return;
            }

            isChanging = true;

            cb_allAgree.Checked = cb_age.Checked && cb_privacy.Checked;

            isChanging = false;
        }

        private void btn_membership_back_Click(object sender, EventArgs e)
        {
            LoginForm form = new LoginForm();

            form.Show();

            this.Hide();
        }
    }
}