﻿namespace C__MiniProject_JTM
{
    partial class HomeForm_expense
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeForm_expense));
            pnl_ex_home = new Panel();
            pic_expense_home = new PictureBox();
            btn_expense_home = new Button();
            pnl_ex_income = new Panel();
            pic_expense_income = new PictureBox();
            btn_expense_income = new Button();
            pnl_ex_expense = new Panel();
            pic_expense_expense = new PictureBox();
            btn_expense_expense = new Button();
            pnl_ex_search = new Panel();
            pic_expense_search = new PictureBox();
            btn_expense_search = new Button();
            pnl_ex_management = new Panel();
            pic_expense_management = new PictureBox();
            btn_expense_management = new Button();
            panel6 = new Panel();
            btn_ex_Registration = new Button();
            tb_ex_Memo = new TextBox();
            label5 = new Label();
            tb_ex_Categori = new TextBox();
            label4 = new Label();
            tb_ex_Money = new TextBox();
            label3 = new Label();
            tb_ex_Date = new TextBox();
            label2 = new Label();
            label1 = new Label();
            pnl_ex_home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_expense_home).BeginInit();
            pnl_ex_income.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_expense_income).BeginInit();
            pnl_ex_expense.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_expense_expense).BeginInit();
            pnl_ex_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_expense_search).BeginInit();
            pnl_ex_management.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_expense_management).BeginInit();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // pnl_ex_home
            // 
            pnl_ex_home.BackColor = Color.FromArgb(224, 224, 224);
            pnl_ex_home.Controls.Add(pic_expense_home);
            pnl_ex_home.Controls.Add(btn_expense_home);
            pnl_ex_home.Location = new Point(25, 86);
            pnl_ex_home.Margin = new Padding(4);
            pnl_ex_home.Name = "pnl_ex_home";
            pnl_ex_home.Size = new Size(271, 60);
            pnl_ex_home.TabIndex = 6;
            pnl_ex_home.Click += pnl_ex_home_Click;
            pnl_ex_home.Paint += pnl_ex_home_Paint;
            // 
            // pic_expense_home
            // 
            pic_expense_home.Image = (Image)resources.GetObject("pic_expense_home.Image");
            pic_expense_home.Location = new Point(4, 5);
            pic_expense_home.Margin = new Padding(4);
            pic_expense_home.Name = "pic_expense_home";
            pic_expense_home.Size = new Size(62, 49);
            pic_expense_home.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_expense_home.TabIndex = 1;
            pic_expense_home.TabStop = false;
            // 
            // btn_expense_home
            // 
            btn_expense_home.FlatStyle = FlatStyle.Flat;
            btn_expense_home.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_expense_home.Location = new Point(71, 5);
            btn_expense_home.Margin = new Padding(4);
            btn_expense_home.Name = "btn_expense_home";
            btn_expense_home.Size = new Size(193, 51);
            btn_expense_home.TabIndex = 0;
            btn_expense_home.Text = "홈";
            btn_expense_home.TextAlign = ContentAlignment.MiddleLeft;
            btn_expense_home.UseVisualStyleBackColor = true;
            // 
            // pnl_ex_income
            // 
            pnl_ex_income.BackColor = Color.FromArgb(224, 224, 224);
            pnl_ex_income.Controls.Add(pic_expense_income);
            pnl_ex_income.Controls.Add(btn_expense_income);
            pnl_ex_income.Location = new Point(25, 154);
            pnl_ex_income.Margin = new Padding(4);
            pnl_ex_income.Name = "pnl_ex_income";
            pnl_ex_income.Size = new Size(271, 60);
            pnl_ex_income.TabIndex = 5;
            pnl_ex_income.Click += pnl_ex_income_Click;
            pnl_ex_income.Paint += pnl_ex_income_Paint;
            // 
            // pic_expense_income
            // 
            pic_expense_income.Image = (Image)resources.GetObject("pic_expense_income.Image");
            pic_expense_income.Location = new Point(4, 5);
            pic_expense_income.Margin = new Padding(4);
            pic_expense_income.Name = "pic_expense_income";
            pic_expense_income.Size = new Size(62, 49);
            pic_expense_income.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_expense_income.TabIndex = 1;
            pic_expense_income.TabStop = false;
            // 
            // btn_expense_income
            // 
            btn_expense_income.FlatStyle = FlatStyle.Flat;
            btn_expense_income.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_expense_income.Location = new Point(71, 5);
            btn_expense_income.Margin = new Padding(4);
            btn_expense_income.Name = "btn_expense_income";
            btn_expense_income.Size = new Size(193, 51);
            btn_expense_income.TabIndex = 0;
            btn_expense_income.Text = "수입 입력";
            btn_expense_income.TextAlign = ContentAlignment.MiddleLeft;
            btn_expense_income.UseVisualStyleBackColor = true;
            // 
            // pnl_ex_expense
            // 
            pnl_ex_expense.BackColor = Color.FromArgb(224, 224, 224);
            pnl_ex_expense.Controls.Add(pic_expense_expense);
            pnl_ex_expense.Controls.Add(btn_expense_expense);
            pnl_ex_expense.Location = new Point(25, 222);
            pnl_ex_expense.Margin = new Padding(4);
            pnl_ex_expense.Name = "pnl_ex_expense";
            pnl_ex_expense.Size = new Size(271, 60);
            pnl_ex_expense.TabIndex = 4;
            pnl_ex_expense.Click += pnl_ex_expense_Click;
            pnl_ex_expense.Paint += pnl_ex_expense_Paint;
            // 
            // pic_expense_expense
            // 
            pic_expense_expense.Image = (Image)resources.GetObject("pic_expense_expense.Image");
            pic_expense_expense.Location = new Point(4, 5);
            pic_expense_expense.Margin = new Padding(4);
            pic_expense_expense.Name = "pic_expense_expense";
            pic_expense_expense.Size = new Size(62, 49);
            pic_expense_expense.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_expense_expense.TabIndex = 1;
            pic_expense_expense.TabStop = false;
            // 
            // btn_expense_expense
            // 
            btn_expense_expense.FlatStyle = FlatStyle.Flat;
            btn_expense_expense.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_expense_expense.Location = new Point(71, 5);
            btn_expense_expense.Margin = new Padding(4);
            btn_expense_expense.Name = "btn_expense_expense";
            btn_expense_expense.Size = new Size(193, 51);
            btn_expense_expense.TabIndex = 0;
            btn_expense_expense.Text = "지출 입력";
            btn_expense_expense.TextAlign = ContentAlignment.MiddleLeft;
            btn_expense_expense.UseVisualStyleBackColor = true;
            // 
            // pnl_ex_search
            // 
            pnl_ex_search.BackColor = Color.FromArgb(224, 224, 224);
            pnl_ex_search.Controls.Add(pic_expense_search);
            pnl_ex_search.Controls.Add(btn_expense_search);
            pnl_ex_search.Location = new Point(25, 290);
            pnl_ex_search.Margin = new Padding(4);
            pnl_ex_search.Name = "pnl_ex_search";
            pnl_ex_search.Size = new Size(271, 60);
            pnl_ex_search.TabIndex = 3;
            pnl_ex_search.Click += pnl_ex_search_Click;
            pnl_ex_search.Paint += pnl_ex_search_Paint;
            // 
            // pic_expense_search
            // 
            pic_expense_search.Image = (Image)resources.GetObject("pic_expense_search.Image");
            pic_expense_search.Location = new Point(4, 5);
            pic_expense_search.Margin = new Padding(4);
            pic_expense_search.Name = "pic_expense_search";
            pic_expense_search.Size = new Size(62, 49);
            pic_expense_search.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_expense_search.TabIndex = 1;
            pic_expense_search.TabStop = false;
            // 
            // btn_expense_search
            // 
            btn_expense_search.FlatStyle = FlatStyle.Flat;
            btn_expense_search.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_expense_search.Location = new Point(71, 5);
            btn_expense_search.Margin = new Padding(4);
            btn_expense_search.Name = "btn_expense_search";
            btn_expense_search.Size = new Size(193, 51);
            btn_expense_search.TabIndex = 0;
            btn_expense_search.Text = "내역 조회";
            btn_expense_search.TextAlign = ContentAlignment.MiddleLeft;
            btn_expense_search.UseVisualStyleBackColor = true;
            // 
            // pnl_ex_management
            // 
            pnl_ex_management.BackColor = Color.FromArgb(224, 224, 224);
            pnl_ex_management.Controls.Add(pic_expense_management);
            pnl_ex_management.Controls.Add(btn_expense_management);
            pnl_ex_management.Location = new Point(25, 358);
            pnl_ex_management.Margin = new Padding(4);
            pnl_ex_management.Name = "pnl_ex_management";
            pnl_ex_management.Size = new Size(271, 60);
            pnl_ex_management.TabIndex = 2;
            pnl_ex_management.Click += pnl_ex_management_Click;
            pnl_ex_management.Paint += pnl_ex_management_Paint;
            // 
            // pic_expense_management
            // 
            pic_expense_management.Image = (Image)resources.GetObject("pic_expense_management.Image");
            pic_expense_management.Location = new Point(4, 5);
            pic_expense_management.Margin = new Padding(4);
            pic_expense_management.Name = "pic_expense_management";
            pic_expense_management.Size = new Size(62, 49);
            pic_expense_management.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_expense_management.TabIndex = 1;
            pic_expense_management.TabStop = false;
            // 
            // btn_expense_management
            // 
            btn_expense_management.FlatStyle = FlatStyle.Flat;
            btn_expense_management.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_expense_management.Location = new Point(71, 5);
            btn_expense_management.Margin = new Padding(4);
            btn_expense_management.Name = "btn_expense_management";
            btn_expense_management.Size = new Size(193, 51);
            btn_expense_management.TabIndex = 0;
            btn_expense_management.Text = "예산 관리";
            btn_expense_management.TextAlign = ContentAlignment.MiddleLeft;
            btn_expense_management.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(btn_ex_Registration);
            panel6.Controls.Add(tb_ex_Memo);
            panel6.Controls.Add(label5);
            panel6.Controls.Add(tb_ex_Categori);
            panel6.Controls.Add(label4);
            panel6.Controls.Add(tb_ex_Money);
            panel6.Controls.Add(label3);
            panel6.Controls.Add(tb_ex_Date);
            panel6.Controls.Add(label2);
            panel6.Controls.Add(label1);
            panel6.Location = new Point(303, 86);
            panel6.Name = "panel6";
            panel6.Size = new Size(500, 600);
            panel6.TabIndex = 7;
            // 
            // btn_ex_Registration
            // 
            btn_ex_Registration.BackColor = Color.FromArgb(192, 192, 255);
            btn_ex_Registration.BackgroundImageLayout = ImageLayout.None;
            btn_ex_Registration.Font = new Font("맑은 고딕", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_ex_Registration.ForeColor = SystemColors.ControlText;
            btn_ex_Registration.Location = new Point(18, 508);
            btn_ex_Registration.Margin = new Padding(4);
            btn_ex_Registration.Name = "btn_ex_Registration";
            btn_ex_Registration.Size = new Size(465, 60);
            btn_ex_Registration.TabIndex = 18;
            btn_ex_Registration.Text = "등록";
            btn_ex_Registration.UseVisualStyleBackColor = false;
            btn_ex_Registration.Click += btn_ex_Registration_Click;
            // 
            // tb_ex_Memo
            // 
            tb_ex_Memo.Font = new Font("맑은 고딕 Semilight", 12F);
            tb_ex_Memo.ForeColor = SystemColors.WindowFrame;
            tb_ex_Memo.Location = new Point(147, 292);
            tb_ex_Memo.Name = "tb_ex_Memo";
            tb_ex_Memo.Size = new Size(240, 34);
            tb_ex_Memo.TabIndex = 10;
            tb_ex_Memo.Text = "메모 입력";
            tb_ex_Memo.Enter += tb_ex_Memo_Enter;
            tb_ex_Memo.Leave += tb_ex_Memo_Leave;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(63, 295);
            label5.Name = "label5";
            label5.Size = new Size(52, 28);
            label5.TabIndex = 9;
            label5.Text = "메모";
            // 
            // tb_ex_Categori
            // 
            tb_ex_Categori.Font = new Font("맑은 고딕 Semilight", 12F);
            tb_ex_Categori.ForeColor = SystemColors.WindowFrame;
            tb_ex_Categori.Location = new Point(147, 230);
            tb_ex_Categori.Name = "tb_ex_Categori";
            tb_ex_Categori.Size = new Size(240, 34);
            tb_ex_Categori.TabIndex = 10;
            tb_ex_Categori.Text = "\"식비, 교통비, 생활용품\"";
            tb_ex_Categori.Enter += tb_ex_Categori_Enter;
            tb_ex_Categori.Leave += tb_ex_Categori_Leave;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(45, 233);
            label4.Name = "label4";
            label4.Size = new Size(92, 28);
            label4.TabIndex = 9;
            label4.Text = "카테고리";
            // 
            // tb_ex_Money
            // 
            tb_ex_Money.Font = new Font("맑은 고딕 Semilight", 12F);
            tb_ex_Money.ForeColor = SystemColors.WindowFrame;
            tb_ex_Money.Location = new Point(147, 168);
            tb_ex_Money.Name = "tb_ex_Money";
            tb_ex_Money.Size = new Size(240, 34);
            tb_ex_Money.TabIndex = 10;
            tb_ex_Money.Text = "금액만 입력 \"10,000\"";
            tb_ex_Money.Enter += tb_ex_Money_Enter;
            tb_ex_Money.Leave += tb_ex_Money_Leave;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(63, 171);
            label3.Name = "label3";
            label3.Size = new Size(52, 28);
            label3.TabIndex = 9;
            label3.Text = "금액";
            // 
            // tb_ex_Date
            // 
            tb_ex_Date.Font = new Font("맑은 고딕 Semilight", 12F);
            tb_ex_Date.ForeColor = SystemColors.WindowFrame;
            tb_ex_Date.Location = new Point(147, 106);
            tb_ex_Date.Name = "tb_ex_Date";
            tb_ex_Date.Size = new Size(240, 34);
            tb_ex_Date.TabIndex = 10;
            tb_ex_Date.Text = "\"년월일\"을 숫자 6개 입력";
            tb_ex_Date.Enter += tb_ex_Date_Enter;
            tb_ex_Date.Leave += tb_ex_Date_Leave;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(63, 109);
            label2.Name = "label2";
            label2.Size = new Size(52, 28);
            label2.TabIndex = 9;
            label2.Text = "날짜";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("맑은 고딕", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(18, 16);
            label1.Name = "label1";
            label1.Size = new Size(141, 40);
            label1.TabIndex = 8;
            label1.Text = "지출 입력";
            // 
            // HomeForm_expense
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(824, 726);
            Controls.Add(panel6);
            Controls.Add(pnl_ex_management);
            Controls.Add(pnl_ex_search);
            Controls.Add(pnl_ex_expense);
            Controls.Add(pnl_ex_income);
            Controls.Add(pnl_ex_home);
            Name = "HomeForm_expense";
            Text = "HomeForm_expense";
            pnl_ex_home.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_expense_home).EndInit();
            pnl_ex_income.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_expense_income).EndInit();
            pnl_ex_expense.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_expense_expense).EndInit();
            pnl_ex_search.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_expense_search).EndInit();
            pnl_ex_management.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_expense_management).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnl_ex_home;
        private PictureBox pic_expense_home;
        private Button btn_expense_home;
        private Panel pnl_ex_income;
        private PictureBox pic_expense_income;
        private Button btn_expense_income;
        private Panel pnl_ex_expense;
        private PictureBox pic_expense_expense;
        private Button btn_expense_expense;
        private Panel pnl_ex_search;
        private PictureBox pic_expense_search;
        private Button btn_expense_search;
        private Panel pnl_ex_management;
        private PictureBox pic_expense_management;
        private Button btn_expense_management;
        private Panel panel6;
        private Label label1;
        private Label label2;
        private TextBox tb_ex_Memo;
        private Label label5;
        private TextBox tb_ex_Categori;
        private Label label4;
        private TextBox tb_ex_Money;
        private Label label3;
        private TextBox tb_ex_Date;
        private Button btn_ex_Registration;
    }
}