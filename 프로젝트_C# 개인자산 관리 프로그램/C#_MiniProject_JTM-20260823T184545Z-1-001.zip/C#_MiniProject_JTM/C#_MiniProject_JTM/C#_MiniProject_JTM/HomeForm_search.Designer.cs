﻿namespace C__MiniProject_JTM
{
    partial class HomeForm_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeForm_search));
            pnl_se_home = new Panel();
            pic_search_home = new PictureBox();
            btn_search_home = new Button();
            pnl_se_income = new Panel();
            pic_search_income = new PictureBox();
            btn_search_income = new Button();
            pnl_se_expense = new Panel();
            pic_search_expense = new PictureBox();
            btn_search_expense = new Button();
            pnl_se_search = new Panel();
            pic_search_search = new PictureBox();
            btn_search_search = new Button();
            pnl_se_management = new Panel();
            pic_search_management = new PictureBox();
            btn_search_management = new Button();
            label1 = new Label();
            panel6 = new Panel();
            btn_se_ALLDELETE = new Button();
            btn_se_DELETE = new Button();
            DGV_se_search = new DataGridView();
            btn_search_PDF = new Button();
            pnl_se_home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_search_home).BeginInit();
            pnl_se_income.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_search_income).BeginInit();
            pnl_se_expense.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_search_expense).BeginInit();
            pnl_se_search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_search_search).BeginInit();
            pnl_se_management.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pic_search_management).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)DGV_se_search).BeginInit();
            SuspendLayout();
            // 
            // pnl_se_home
            // 
            pnl_se_home.BackColor = Color.FromArgb(224, 224, 224);
            pnl_se_home.Controls.Add(pic_search_home);
            pnl_se_home.Controls.Add(btn_search_home);
            pnl_se_home.Location = new Point(10, 50);
            pnl_se_home.Name = "pnl_se_home";
            pnl_se_home.Size = new Size(211, 45);
            pnl_se_home.TabIndex = 6;
            pnl_se_home.Click += pnl_se_home_Click;
            pnl_se_home.Paint += pnl_se_home_Paint;
            // 
            // pic_search_home
            // 
            pic_search_home.Image = (Image)resources.GetObject("pic_search_home.Image");
            pic_search_home.Location = new Point(3, 4);
            pic_search_home.Name = "pic_search_home";
            pic_search_home.Size = new Size(48, 37);
            pic_search_home.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_search_home.TabIndex = 1;
            pic_search_home.TabStop = false;
            // 
            // btn_search_home
            // 
            btn_search_home.FlatStyle = FlatStyle.Flat;
            btn_search_home.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_search_home.Location = new Point(55, 4);
            btn_search_home.Name = "btn_search_home";
            btn_search_home.Size = new Size(150, 38);
            btn_search_home.TabIndex = 0;
            btn_search_home.Text = "홈";
            btn_search_home.TextAlign = ContentAlignment.MiddleLeft;
            btn_search_home.UseVisualStyleBackColor = true;
            // 
            // pnl_se_income
            // 
            pnl_se_income.BackColor = Color.FromArgb(224, 224, 224);
            pnl_se_income.Controls.Add(pic_search_income);
            pnl_se_income.Controls.Add(btn_search_income);
            pnl_se_income.Location = new Point(10, 100);
            pnl_se_income.Name = "pnl_se_income";
            pnl_se_income.Size = new Size(211, 45);
            pnl_se_income.TabIndex = 5;
            pnl_se_income.Click += pnl_se_income_Click;
            pnl_se_income.Paint += pnl_se_income_Paint;
            // 
            // pic_search_income
            // 
            pic_search_income.Image = (Image)resources.GetObject("pic_search_income.Image");
            pic_search_income.Location = new Point(3, 4);
            pic_search_income.Name = "pic_search_income";
            pic_search_income.Size = new Size(48, 37);
            pic_search_income.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_search_income.TabIndex = 1;
            pic_search_income.TabStop = false;
            // 
            // btn_search_income
            // 
            btn_search_income.FlatStyle = FlatStyle.Flat;
            btn_search_income.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_search_income.Location = new Point(55, 4);
            btn_search_income.Name = "btn_search_income";
            btn_search_income.Size = new Size(150, 38);
            btn_search_income.TabIndex = 0;
            btn_search_income.Text = "수입 입력";
            btn_search_income.TextAlign = ContentAlignment.MiddleLeft;
            btn_search_income.UseVisualStyleBackColor = true;
            // 
            // pnl_se_expense
            // 
            pnl_se_expense.BackColor = Color.FromArgb(224, 224, 224);
            pnl_se_expense.Controls.Add(pic_search_expense);
            pnl_se_expense.Controls.Add(btn_search_expense);
            pnl_se_expense.Location = new Point(10, 152);
            pnl_se_expense.Name = "pnl_se_expense";
            pnl_se_expense.Size = new Size(211, 45);
            pnl_se_expense.TabIndex = 4;
            pnl_se_expense.Click += pnl_se_expense_Click;
            pnl_se_expense.Paint += pnl_se_expense_Paint;
            // 
            // pic_search_expense
            // 
            pic_search_expense.Image = (Image)resources.GetObject("pic_search_expense.Image");
            pic_search_expense.Location = new Point(3, 4);
            pic_search_expense.Name = "pic_search_expense";
            pic_search_expense.Size = new Size(48, 37);
            pic_search_expense.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_search_expense.TabIndex = 1;
            pic_search_expense.TabStop = false;
            // 
            // btn_search_expense
            // 
            btn_search_expense.FlatStyle = FlatStyle.Flat;
            btn_search_expense.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_search_expense.Location = new Point(55, 4);
            btn_search_expense.Name = "btn_search_expense";
            btn_search_expense.Size = new Size(150, 38);
            btn_search_expense.TabIndex = 0;
            btn_search_expense.Text = "지출 입력";
            btn_search_expense.TextAlign = ContentAlignment.MiddleLeft;
            btn_search_expense.UseVisualStyleBackColor = true;
            // 
            // pnl_se_search
            // 
            pnl_se_search.BackColor = Color.FromArgb(224, 224, 224);
            pnl_se_search.Controls.Add(pic_search_search);
            pnl_se_search.Controls.Add(btn_search_search);
            pnl_se_search.Location = new Point(10, 202);
            pnl_se_search.Name = "pnl_se_search";
            pnl_se_search.Size = new Size(211, 45);
            pnl_se_search.TabIndex = 3;
            pnl_se_search.Click += pnl_se_search_Click;
            pnl_se_search.Paint += pnl_se_search_Paint;
            // 
            // pic_search_search
            // 
            pic_search_search.Image = (Image)resources.GetObject("pic_search_search.Image");
            pic_search_search.Location = new Point(3, 4);
            pic_search_search.Name = "pic_search_search";
            pic_search_search.Size = new Size(48, 37);
            pic_search_search.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_search_search.TabIndex = 1;
            pic_search_search.TabStop = false;
            // 
            // btn_search_search
            // 
            btn_search_search.FlatStyle = FlatStyle.Flat;
            btn_search_search.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_search_search.Location = new Point(55, 4);
            btn_search_search.Name = "btn_search_search";
            btn_search_search.Size = new Size(150, 38);
            btn_search_search.TabIndex = 0;
            btn_search_search.Text = "내역 조회";
            btn_search_search.TextAlign = ContentAlignment.MiddleLeft;
            btn_search_search.UseVisualStyleBackColor = true;
            // 
            // pnl_se_management
            // 
            pnl_se_management.BackColor = Color.FromArgb(224, 224, 224);
            pnl_se_management.Controls.Add(pic_search_management);
            pnl_se_management.Controls.Add(btn_search_management);
            pnl_se_management.Location = new Point(10, 254);
            pnl_se_management.Name = "pnl_se_management";
            pnl_se_management.Size = new Size(211, 45);
            pnl_se_management.TabIndex = 2;
            pnl_se_management.Click += pnl_se_management_Click;
            pnl_se_management.Paint += pnl_se_management_Paint;
            // 
            // pic_search_management
            // 
            pic_search_management.Image = (Image)resources.GetObject("pic_search_management.Image");
            pic_search_management.Location = new Point(3, 4);
            pic_search_management.Name = "pic_search_management";
            pic_search_management.Size = new Size(48, 37);
            pic_search_management.SizeMode = PictureBoxSizeMode.CenterImage;
            pic_search_management.TabIndex = 1;
            pic_search_management.TabStop = false;
            // 
            // btn_search_management
            // 
            btn_search_management.FlatStyle = FlatStyle.Flat;
            btn_search_management.Font = new Font("맑은 고딕", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_search_management.Location = new Point(55, 4);
            btn_search_management.Name = "btn_search_management";
            btn_search_management.Size = new Size(150, 38);
            btn_search_management.TabIndex = 0;
            btn_search_management.Text = "예산 관리";
            btn_search_management.TextAlign = ContentAlignment.MiddleLeft;
            btn_search_management.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("맑은 고딕", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(14, 12);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(109, 30);
            label1.TabIndex = 8;
            label1.Text = "내역 조회";
            // 
            // panel6
            // 
            panel6.BackColor = Color.White;
            panel6.Controls.Add(btn_search_PDF);
            panel6.Controls.Add(btn_se_ALLDELETE);
            panel6.Controls.Add(btn_se_DELETE);
            panel6.Controls.Add(DGV_se_search);
            panel6.Controls.Add(label1);
            panel6.Location = new Point(228, 50);
            panel6.Margin = new Padding(2, 2, 2, 2);
            panel6.Name = "panel6";
            panel6.Size = new Size(948, 450);
            panel6.TabIndex = 8;
            // 
            // btn_se_ALLDELETE
            // 
            btn_se_ALLDELETE.BackColor = Color.Silver;
            btn_se_ALLDELETE.BackgroundImageLayout = ImageLayout.None;
            btn_se_ALLDELETE.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_se_ALLDELETE.ForeColor = SystemColors.ControlText;
            btn_se_ALLDELETE.Location = new Point(540, 12);
            btn_se_ALLDELETE.Name = "btn_se_ALLDELETE";
            btn_se_ALLDELETE.Size = new Size(191, 35);
            btn_se_ALLDELETE.TabIndex = 33;
            btn_se_ALLDELETE.Text = "내용 전체 삭제 버튼";
            btn_se_ALLDELETE.UseVisualStyleBackColor = false;
            btn_se_ALLDELETE.Click += btn_se_ALLDELETE_Click;
            // 
            // btn_se_DELETE
            // 
            btn_se_DELETE.BackColor = Color.Silver;
            btn_se_DELETE.BackgroundImageLayout = ImageLayout.None;
            btn_se_DELETE.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_se_DELETE.ForeColor = SystemColors.ControlText;
            btn_se_DELETE.Location = new Point(737, 11);
            btn_se_DELETE.Name = "btn_se_DELETE";
            btn_se_DELETE.Size = new Size(194, 35);
            btn_se_DELETE.TabIndex = 32;
            btn_se_DELETE.Text = "해당 내용 삭제 버튼";
            btn_se_DELETE.UseVisualStyleBackColor = false;
            btn_se_DELETE.Click += btn_se_DELETE_Click;
            // 
            // DGV_se_search
            // 
            DGV_se_search.AllowUserToAddRows = false;
            DGV_se_search.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGV_se_search.Location = new Point(14, 55);
            DGV_se_search.Margin = new Padding(2, 2, 2, 2);
            DGV_se_search.Name = "DGV_se_search";
            DGV_se_search.RowHeadersWidth = 51;
            DGV_se_search.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            DGV_se_search.Size = new Size(918, 378);
            DGV_se_search.TabIndex = 9;
            // 
            // btn_search_PDF
            // 
            btn_search_PDF.BackColor = Color.Silver;
            btn_search_PDF.BackgroundImageLayout = ImageLayout.None;
            btn_search_PDF.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_search_PDF.ForeColor = SystemColors.ControlText;
            btn_search_PDF.Location = new Point(403, 12);
            btn_search_PDF.Name = "btn_search_PDF";
            btn_search_PDF.Size = new Size(131, 35);
            btn_search_PDF.TabIndex = 34;
            btn_search_PDF.Text = "PDF 저장";
            btn_search_PDF.UseVisualStyleBackColor = false;
            btn_search_PDF.Click += btn_search_PDF_Click;
            // 
            // HomeForm_search
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 224, 192);
            ClientSize = new Size(1185, 544);
            Controls.Add(panel6);
            Controls.Add(pnl_se_management);
            Controls.Add(pnl_se_search);
            Controls.Add(pnl_se_expense);
            Controls.Add(pnl_se_income);
            Controls.Add(pnl_se_home);
            Margin = new Padding(2, 2, 2, 2);
            Name = "HomeForm_search";
            Text = "HomeForm_search";
            Load += HomeForm_search_Load;
            pnl_se_home.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_search_home).EndInit();
            pnl_se_income.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_search_income).EndInit();
            pnl_se_expense.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_search_expense).EndInit();
            pnl_se_search.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_search_search).EndInit();
            pnl_se_management.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pic_search_management).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)DGV_se_search).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnl_se_home;
        private PictureBox pic_search_home;
        private Button btn_search_home;
        private Panel pnl_se_income;
        private PictureBox pic_search_income;
        private Button btn_search_income;
        private Panel pnl_se_expense;
        private PictureBox pic_search_expense;
        private Button btn_search_expense;
        private Panel pnl_se_search;
        private PictureBox pic_search_search;
        private Button btn_search_search;
        private Panel pnl_se_management;
        private PictureBox pic_search_;
        private Button btn_search_management;
        private Label label1;
        private Panel panel6;
        private PictureBox pic_search_management;
        private DataGridView DGV_se_search;
        private Button btn_se_DELETE;
        private Button btn_se_ALLDELETE;
        private Button btn_search_PDF;
    }
}