﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.Sqlite;

namespace C__MiniProject_JTM
{
    public partial class HomeForm_expense : Form
    {
        public HomeForm_expense()
        {
            InitializeComponent();

            tb_ex_Date.TabIndex = 0;
            tb_ex_Money.TabIndex = 1;
            tb_ex_Categori.TabIndex = 2;
            tb_ex_Memo.TabIndex = 3;
            btn_ex_Registration.TabIndex = 4;

            pnl_ex_home.Click += pnl_ex_home_Click;
            pnl_ex_income.Click += pnl_ex_income_Click;
            pnl_ex_expense.Click += pnl_ex_expense_Click;
            pnl_ex_search.Click += pnl_ex_search_Click;
            pnl_ex_management.Click += pnl_ex_management_Click;

            btn_expense_home.Click += pnl_ex_home_Click;
            btn_expense_income.Click += pnl_ex_income_Click;
            btn_expense_expense.Click += pnl_ex_expense_Click;
            btn_expense_search.Click += pnl_ex_search_Click;
            btn_expense_management.Click += pnl_ex_management_Click;

            pic_expense_home.Click += pnl_ex_home_Click;
            pic_expense_income.Click += pnl_ex_income_Click;
            pic_expense_expense.Click += pnl_ex_expense_Click;
            pic_expense_search.Click += pnl_ex_search_Click;
            pic_expense_management.Click += pnl_ex_management_Click;
        }

        private void pnl_ex_home_Click(object sender, EventArgs e)
        {
            HomeForm form = new HomeForm("사용자");
            form.Show();
            this.Hide();
        }

        private void pnl_ex_income_Click(object sender, EventArgs e)
        {
            HomeForm_income form = new HomeForm_income();
            form.Show();
            this.Hide();
        }

        private void pnl_ex_expense_Click(object sender, EventArgs e)
        {

        }

        private void pnl_ex_search_Click(object sender, EventArgs e)
        {
            HomeForm_search form = new HomeForm_search();
            form.Show();
            this.Hide();
        }

        private void pnl_ex_management_Click(object sender, EventArgs e)
        {
            HomeForm_management form = new HomeForm_management();
            form.Show();
            this.Hide();
        }

        private void btn_ex_Registration_Click(object sender, EventArgs e)
        {
            string date = tb_ex_Date.Text;
            string amountText = tb_ex_Money.Text;
            string category = tb_ex_Categori.Text;
            string memo = tb_ex_Memo.Text;

            if (date == "\"년월일\"을 숫자 6개 입력" || amountText == "금액만 입력 \"10,000\"" || category == "\"식비, 교통비, 생활용품\"")
            {
                MessageBox.Show("날짜, 금액, 카테고리를 입력하세요.");
                return;
            }

            if (date == "" || amountText == "" || category == "")
            {
                MessageBox.Show("날짜, 금액, 카테고리는 반드시 입력해야 합니다.");
                return;
            }

            amountText = amountText.Replace(",", "");

            int amount;

            if (int.TryParse(amountText, out amount) == false)
            {
                MessageBox.Show("금액은 숫자만 입력해야 합니다.");
                return;
            }

            using (SqliteConnection conn = new SqliteConnection(DB.ConnStr))
            {
                conn.Open();

                string sql = @"
                INSERT INTO Expense(Date, Amount, Category, Memo)
                VALUES(@Date, @Amount, @Category, @Memo);";

                using (SqliteCommand cmd = new SqliteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Date", date);
                    cmd.Parameters.AddWithValue("@Amount", amount);
                    cmd.Parameters.AddWithValue("@Category", category);
                    cmd.Parameters.AddWithValue("@Memo", memo);

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("지출이 등록되었습니다.");

            tb_ex_Date.Clear();
            tb_ex_Money.Clear();
            tb_ex_Categori.Clear();
            tb_ex_Memo.Clear();
        }

        private void pnl_ex_management_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_ex_home_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_ex_income_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_ex_expense_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_ex_search_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tb_ex_Date_Enter(object sender, EventArgs e)
        {
            if (tb_ex_Date.Text == "\"년월일\"을 숫자 6개 입력")
            {
                tb_ex_Date.Text = "";
                tb_ex_Date.ForeColor = Color.Black;
            }
        }

        private void tb_ex_Date_Leave(object sender, EventArgs e)
        {
            if (tb_ex_Date.Text == "")
            {
                tb_ex_Date.Text = "\"년월일\"을 숫자 6개 입력";
                tb_ex_Date.ForeColor = Color.Gray;
            }
        }

        private void tb_ex_Money_Enter(object sender, EventArgs e)
        {
            if (tb_ex_Money.Text == "금액만 입력 \"10,000\"")
            {
                tb_ex_Money.Text = "";
                tb_ex_Money.ForeColor = Color.Black;
            }
        }

        private void tb_ex_Money_Leave(object sender, EventArgs e)
        {
            if (tb_ex_Money.Text == "")
            {
                tb_ex_Money.Text = "금액만 입력 \"10,000\"";
                tb_ex_Money.ForeColor = Color.Gray;
            }
        }

        private void tb_ex_Categori_Enter(object sender, EventArgs e)
        {
            if (tb_ex_Categori.Text == "\"식비, 교통비, 생활용품\"")
            {
                tb_ex_Categori.Text = "";
                tb_ex_Categori.ForeColor = Color.Black;
            }
        }

        private void tb_ex_Categori_Leave(object sender, EventArgs e)
        {
            if (tb_ex_Categori.Text == "")
            {
                tb_ex_Categori.Text = "\"식비, 교통비, 생활용품\"";
                tb_ex_Categori.ForeColor = Color.Gray;
            }
        }

        private void tb_ex_Memo_Enter(object sender, EventArgs e)
        {
            if (tb_ex_Memo.Text == "메모 입력")
            {
                tb_ex_Memo.Text = "";
                tb_ex_Memo.ForeColor = Color.Black;
            }
        }

        private void tb_ex_Memo_Leave(object sender, EventArgs e)
        {
            if (tb_ex_Memo.Text == "")
            {
                tb_ex_Memo.Text = "메모 입력";
                tb_ex_Memo.ForeColor = Color.Gray;
            }
        }
    }
}