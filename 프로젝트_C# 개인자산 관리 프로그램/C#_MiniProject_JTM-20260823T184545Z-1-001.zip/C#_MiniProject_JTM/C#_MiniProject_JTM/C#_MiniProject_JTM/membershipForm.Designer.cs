﻿namespace C__MiniProject_JTM
{
    partial class membershipForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tb_pw = new TextBox();
            label3 = new Label();
            tb_id = new TextBox();
            label2 = new Label();
            tb_pwcheck = new TextBox();
            label1 = new Label();
            label4 = new Label();
            tb_name = new TextBox();
            label5 = new Label();
            tb_phone = new TextBox();
            tb_email = new TextBox();
            label6 = new Label();
            tb_birth = new TextBox();
            label7 = new Label();
            btn_login = new Button();
            cb_allAgree = new CheckBox();
            cb_age = new CheckBox();
            cb_privacy = new CheckBox();
            btn_membership_back = new Button();
            SuspendLayout();
            // 
            // tb_pw
            // 
            tb_pw.BorderStyle = BorderStyle.FixedSingle;
            tb_pw.Font = new Font("맑은 고딕 Semilight", 11F);
            tb_pw.ForeColor = SystemColors.WindowFrame;
            tb_pw.Location = new Point(17, 104);
            tb_pw.Name = "tb_pw";
            tb_pw.Size = new Size(397, 27);
            tb_pw.TabIndex = 9;
            tb_pw.Text = "비밀번호 입력 (문자, 숫자, 특수문자 포함 8 ~ 20자 )";
            tb_pw.Enter += tb_pw_MouseEnter;
            tb_pw.Leave += tb_pw_MouseLeave;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(17, 80);
            label3.Name = "label3";
            label3.Size = new Size(74, 21);
            label3.TabIndex = 8;
            label3.Text = "비밀번호";
            // 
            // tb_id
            // 
            tb_id.BorderStyle = BorderStyle.FixedSingle;
            tb_id.Font = new Font("맑은 고딕 Semilight", 11F);
            tb_id.ForeColor = SystemColors.WindowFrame;
            tb_id.Location = new Point(17, 48);
            tb_id.Name = "tb_id";
            tb_id.Size = new Size(397, 27);
            tb_id.TabIndex = 7;
            tb_id.Text = "아이디 입력 (6 ~ 20자)";
            tb_id.Enter += tb_id_MouseEnter;
            tb_id.Leave += tb_id_MouseLeave;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(17, 24);
            label2.Name = "label2";
            label2.Size = new Size(58, 21);
            label2.TabIndex = 6;
            label2.Text = "아이디";
            // 
            // tb_pwcheck
            // 
            tb_pwcheck.BorderStyle = BorderStyle.FixedSingle;
            tb_pwcheck.Font = new Font("맑은 고딕 Semilight", 11F);
            tb_pwcheck.ForeColor = SystemColors.WindowFrame;
            tb_pwcheck.Location = new Point(17, 160);
            tb_pwcheck.Name = "tb_pwcheck";
            tb_pwcheck.Size = new Size(397, 27);
            tb_pwcheck.TabIndex = 11;
            tb_pwcheck.Text = "비밀번호 확인 입력 ( 문자, 숫자, 특수문자 포함 8 ~ 20자 )";
            tb_pwcheck.Enter += tb_pwcheck_MouseEnter;
            tb_pwcheck.Leave += tb_pwcheck_MouseLeave;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(17, 136);
            label1.Name = "label1";
            label1.Size = new Size(112, 21);
            label1.TabIndex = 10;
            label1.Text = "비밀번호 확인";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(17, 192);
            label4.Name = "label4";
            label4.Size = new Size(42, 21);
            label4.TabIndex = 6;
            label4.Text = "이름";
            // 
            // tb_name
            // 
            tb_name.BorderStyle = BorderStyle.FixedSingle;
            tb_name.Font = new Font("맑은 고딕 Semilight", 11F);
            tb_name.ForeColor = SystemColors.WindowFrame;
            tb_name.Location = new Point(17, 216);
            tb_name.Name = "tb_name";
            tb_name.Size = new Size(397, 27);
            tb_name.TabIndex = 7;
            tb_name.Text = "이름을 입력해주세요";
            tb_name.Enter += tb_name_MouseEnter;
            tb_name.Leave += tb_name_MouseLeave;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(17, 248);
            label5.Name = "label5";
            label5.Size = new Size(74, 21);
            label5.TabIndex = 6;
            label5.Text = "전화번호";
            // 
            // tb_phone
            // 
            tb_phone.BorderStyle = BorderStyle.FixedSingle;
            tb_phone.Font = new Font("맑은 고딕 Semilight", 11F);
            tb_phone.ForeColor = SystemColors.WindowFrame;
            tb_phone.Location = new Point(17, 272);
            tb_phone.Name = "tb_phone";
            tb_phone.Size = new Size(397, 27);
            tb_phone.TabIndex = 7;
            tb_phone.Text = "휴대폰 번호 입력 ( '-' 제외 11자리 입력 )";
            tb_phone.Enter += tb_phone_MouseEnter;
            tb_phone.Leave += tb_phone_MouseLeave;
            // 
            // tb_email
            // 
            tb_email.BorderStyle = BorderStyle.FixedSingle;
            tb_email.Font = new Font("맑은 고딕 Semilight", 11F);
            tb_email.ForeColor = SystemColors.WindowFrame;
            tb_email.Location = new Point(17, 328);
            tb_email.Name = "tb_email";
            tb_email.Size = new Size(397, 27);
            tb_email.TabIndex = 13;
            tb_email.Text = "이메일을 입력해주세요";
            tb_email.Enter += tb_email_MouseEnter;
            tb_email.Leave += tb_email_MouseLeave;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(17, 304);
            label6.Name = "label6";
            label6.Size = new Size(96, 21);
            label6.TabIndex = 12;
            label6.Text = "이메일 주소";
            // 
            // tb_birth
            // 
            tb_birth.BorderStyle = BorderStyle.FixedSingle;
            tb_birth.Font = new Font("맑은 고딕 Semilight", 11F);
            tb_birth.ForeColor = SystemColors.WindowFrame;
            tb_birth.Location = new Point(17, 384);
            tb_birth.Name = "tb_birth";
            tb_birth.Size = new Size(397, 27);
            tb_birth.TabIndex = 15;
            tb_birth.Text = "8자리를 입력해주세요";
            tb_birth.Enter += tb_birth_MouseEnter;
            tb_birth.Leave += tb_birth_MouseLeave;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("맑은 고딕", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(17, 360);
            label7.Name = "label7";
            label7.Size = new Size(74, 21);
            label7.TabIndex = 14;
            label7.Text = "생년월일";
            // 
            // btn_login
            // 
            btn_login.BackColor = Color.FromArgb(192, 192, 255);
            btn_login.BackgroundImageLayout = ImageLayout.None;
            btn_login.Font = new Font("맑은 고딕", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btn_login.ForeColor = SystemColors.ControlText;
            btn_login.Location = new Point(17, 510);
            btn_login.Name = "btn_login";
            btn_login.Size = new Size(397, 45);
            btn_login.TabIndex = 17;
            btn_login.Text = "회원가입";
            btn_login.UseVisualStyleBackColor = false;
            btn_login.Click += btn_login_Click;
            // 
            // cb_allAgree
            // 
            cb_allAgree.AutoSize = true;
            cb_allAgree.Location = new Point(17, 433);
            cb_allAgree.Margin = new Padding(2);
            cb_allAgree.Name = "cb_allAgree";
            cb_allAgree.Size = new Size(117, 19);
            cb_allAgree.TabIndex = 18;
            cb_allAgree.Text = "전체 동의합니다.";
            cb_allAgree.UseVisualStyleBackColor = true;
            cb_allAgree.CheckedChanged += cb_allAgree_CheckedChanged;
            // 
            // cb_age
            // 
            cb_age.AutoSize = true;
            cb_age.Location = new Point(17, 455);
            cb_age.Margin = new Padding(2);
            cb_age.Name = "cb_age";
            cb_age.Size = new Size(135, 19);
            cb_age.TabIndex = 19;
            cb_age.Text = "만 14세 이상입니다.";
            cb_age.UseVisualStyleBackColor = true;
            cb_age.CheckedChanged += cb_age_CheckedChanged;
            // 
            // cb_privacy
            // 
            cb_privacy.AutoSize = true;
            cb_privacy.Location = new Point(17, 478);
            cb_privacy.Margin = new Padding(2);
            cb_privacy.Name = "cb_privacy";
            cb_privacy.Size = new Size(158, 19);
            cb_privacy.TabIndex = 20;
            cb_privacy.Text = "개인정보 취급 방침 동의";
            cb_privacy.UseVisualStyleBackColor = true;
            cb_privacy.CheckedChanged += cb_privacy_CheckedChanged;
            // 
            // btn_membership_back
            // 
            btn_membership_back.BackColor = Color.Silver;
            btn_membership_back.BackgroundImageLayout = ImageLayout.None;
            btn_membership_back.Font = new Font("맑은 고딕", 9F, FontStyle.Bold);
            btn_membership_back.ForeColor = SystemColors.ControlText;
            btn_membership_back.Location = new Point(17, 560);
            btn_membership_back.Name = "btn_membership_back";
            btn_membership_back.Size = new Size(74, 24);
            btn_membership_back.TabIndex = 32;
            btn_membership_back.Text = "이전으로 ";
            btn_membership_back.UseVisualStyleBackColor = false;
            btn_membership_back.Click += btn_membership_back_Click;
            // 
            // membershipForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(438, 594);
            Controls.Add(btn_membership_back);
            Controls.Add(cb_privacy);
            Controls.Add(cb_age);
            Controls.Add(cb_allAgree);
            Controls.Add(btn_login);
            Controls.Add(tb_birth);
            Controls.Add(label7);
            Controls.Add(tb_email);
            Controls.Add(label6);
            Controls.Add(tb_pwcheck);
            Controls.Add(label1);
            Controls.Add(tb_pw);
            Controls.Add(label3);
            Controls.Add(tb_phone);
            Controls.Add(label5);
            Controls.Add(tb_name);
            Controls.Add(label4);
            Controls.Add(tb_id);
            Controls.Add(label2);
            Name = "membershipForm";
            Text = "회원가입";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tb_pw;
        private Label label3;
        private TextBox tb_id;
        private Label label2;
        private TextBox tb_pwcheck;
        private Label label1;
        private Label label4;
        private TextBox tb_name;
        private Label label5;
        private TextBox tb_phone;
        private TextBox tb_email;
        private Label label6;
        private TextBox tb_birth;
        private Label label7;
        private Button btn_login;
        private CheckBox cb_allAgree;
        private CheckBox cb_age;
        private CheckBox cb_privacy;
        private Button btn_membership_back;
    }
}