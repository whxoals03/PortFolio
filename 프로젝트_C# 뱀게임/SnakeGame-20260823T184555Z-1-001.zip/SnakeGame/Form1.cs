using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace SnakeGame
{
    public partial class Form1 : Form
    {
        private PictureBox gameBoard;
        private Label lblStatus;

        private System.Windows.Forms.Timer mainTimer;
        private System.Windows.Forms.Timer timeTimer;

        private int boardSize = 500;
        private int gridSize = 25;
        private int cellCount;

        private int headX;
        private int headY;

        private string direction;

        private List<Point> snakeBody;
        private int snakeLength;

        private int foodX;
        private int foodY;

        private int foodCount;
        private int elapsedSeconds;

        private Random rnd;

        void Form1_Load(object sender, EventArgs e)
        {
        }

        public Form1()
        {
            InitializeComponent();

            this.Text = "뱀 게임";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.KeyPreview = true;

            cellCount = boardSize / gridSize;

            snakeBody = new List<Point>();
            rnd = new Random();

            BuildUI();
            InitGame();

            this.KeyDown += Form1_KeyDown;
            this.Focus();
        }

        private void BuildUI()
        {
            lblStatus = new Label();
            lblStatus.Size = new Size(boardSize, 70);
            lblStatus.Location = new Point(25, 5);
            lblStatus.BackColor = Color.LightGray;
            lblStatus.ForeColor = Color.Black;
            lblStatus.TextAlign = ContentAlignment.MiddleCenter;
            lblStatus.Font = new Font("맑은 고딕", 11, FontStyle.Bold);

            gameBoard = new PictureBox();
            gameBoard.Size = new Size(boardSize, boardSize);
            gameBoard.Location = new Point(25, 85);
            gameBoard.BackColor = Color.Black;
            gameBoard.BorderStyle = BorderStyle.FixedSingle;
            gameBoard.Paint += GameBoard_Paint;

            this.Controls.Add(lblStatus);
            this.Controls.Add(gameBoard);

            this.ClientSize = new Size(gameBoard.Right + 25, gameBoard.Bottom + 25);

            mainTimer = new System.Windows.Forms.Timer();
            mainTimer.Interval = 200;
            mainTimer.Tick += MainTimer_Tick;

            timeTimer = new System.Windows.Forms.Timer();
            timeTimer.Interval = 1000;
            timeTimer.Tick += TimeTimer_Tick;
        }

        private void InitGame()
        {
            mainTimer.Stop();
            timeTimer.Stop();

            headX = 5;
            headY = 5;
            direction = "RIGHT";

            snakeBody.Clear();
            snakeLength = 0;
            foodCount = 0;
            elapsedSeconds = 0;

            SpawnFood();
            UpdateStatus();
            gameBoard.Invalidate();

            mainTimer.Start();
            timeTimer.Start();
        }

        // 먹이 랜덤 생성
        private void SpawnFood()
        {
            bool isOnSnake;

            do
            {
                isOnSnake = false;

                foodX = rnd.Next(0, cellCount);
                foodY = rnd.Next(0, cellCount);

                if (foodX == headX && foodY == headY)
                    isOnSnake = true;

                for (int i = 0; i < snakeBody.Count; i++)
                {
                    if (snakeBody[i].X == foodX && snakeBody[i].Y == foodY)
                    {
                        isOnSnake = true;
                        break;
                    }
                }
            }
            while (isOnSnake);
        }
        
        // 타이머
        private void TimeTimer_Tick(object sender, EventArgs e)
        {
            elapsedSeconds++;
            UpdateStatus();
        }
        // 뱀의 이동 타이머
        private void MainTimer_Tick(object sender, EventArgs e)
        {
            snakeBody.Insert(0, new Point(headX, headY));

            if (snakeBody.Count > snakeLength)
                snakeBody.RemoveAt(snakeBody.Count - 1);

            if (direction == "RIGHT")
                headX++;
            else if (direction == "LEFT")
                headX--;
            else if (direction == "UP")
                headY--;
            else if (direction == "DOWN")
                headY++;
            
            // 벽 충돌 게임 오버
            if (headX < 0 || headX >= cellCount || headY < 0 || headY >= cellCount)
            {
                EndGame("벽에 부딪혀 게임 오버");
                return;
            }

            // 몸 충돌 게임 오버
            for (int i = 0; i < snakeBody.Count; i++)
            {
                if (headX == snakeBody[i].X && headY == snakeBody[i].Y)
                {
                    EndGame("몸에 닿아서 게임 오버");
                    return;
                }
            }

            // 게임 룰
            if (headX == foodX && headY == foodY)
            {
                if(snakeLength >= 5)
                {
                    snakeLength += 2;
                    foodCount++;
                }
                else
                {
                    snakeLength++;
                    foodCount++;
                }

                if (foodCount >= 10)
                {
                    UpdateStatus();
                    gameBoard.Invalidate();
                    EndGame("먹이 10개를 먹어서 게임 종료");
                    return;
                }

                SpawnFood();
            }

            UpdateStatus();
            gameBoard.Invalidate();
        }

        // 게임 종료 함수
        private void EndGame(string message)
        {
            mainTimer.Stop();
            timeTimer.Stop();
            MessageBox.Show(message);
        }
        
        // 실시간 수정
        private void UpdateStatus()
        {
            lblStatus.Text =
                "방향: " + direction +
                "   좌표: (" + headX + ", " + headY + ")" +
                "   먹은 개수: " + foodCount +
                "   길이: " + snakeLength +
                "\n시간: " + elapsedSeconds + "초";
        }

        // 게임 판
        private void GameBoard_Paint(object sender, PaintEventArgs e)
        {
            for (int x = 0; x <= boardSize; x += gridSize)
            {
                e.Graphics.DrawLine(Pens.DimGray, x, 0, x, boardSize);
            }

            for (int y = 0; y <= boardSize; y += gridSize)
            {
                e.Graphics.DrawLine(Pens.DimGray, 0, y, boardSize, y);
            }

            for (int i = 0; i < snakeBody.Count; i++)
            {
                // 몸통
                e.Graphics.FillRectangle(
                    Brushes.Green,
                    snakeBody[i].X * gridSize,
                    snakeBody[i].Y * gridSize,
                    gridSize,
                    gridSize
                );
            }

            // 머리
            e.Graphics.FillRectangle(
                Brushes.Lime,
                headX * gridSize,
                headY * gridSize,
                gridSize,
                gridSize
            );

            // 먹이
            e.Graphics.FillRectangle(
                Brushes.Red,
                foodX * gridSize,
                foodY * gridSize,
                gridSize,
                gridSize
            );
        }

        // 키 입력
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right && direction != "LEFT")
                direction = "RIGHT";
            else if (e.KeyCode == Keys.Left && direction != "RIGHT")
                direction = "LEFT";
            else if (e.KeyCode == Keys.Up && direction != "DOWN")
                direction = "UP";
            else if (e.KeyCode == Keys.Down && direction != "UP")
                direction = "DOWN";
        }
    }
}